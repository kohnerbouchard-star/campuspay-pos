# Offline fixtures ONLY. No real docker, Vercel, curl, git, or database operation.
import hashlib,json,os,pathlib,shutil,subprocess,tempfile,time
import pexpect
if os.name=='nt': raise SystemExit('LINUX_CONTAINER_REQUIRED')
src=pathlib.Path(__file__).resolve().parent
root=pathlib.Path(tempfile.mkdtemp(prefix='campuspay-cutover-shell-'))
real_node=shutil.which('node')
mock=r'''#!/usr/bin/env python3
import os,sys,pathlib,json,hashlib,time
name=pathlib.Path(sys.argv[0]).name;a=sys.argv[1:];s=pathlib.Path(os.environ['FIXTURE_STATE']);scenario=os.environ['FIXTURE_CASE'];prefix='C:/CampusPay fixture'
def native(p):return prefix+p if p.startswith('/') else p
def local(p):return p[len(prefix):] if p.startswith(prefix) else p
def die(m='MOCK_UNEXPECTED_OPERATION',code=71):print(m,file=sys.stderr);sys.exit(code)
def event(x):
 with (s/'events.jsonl').open('a') as f:f.write(json.dumps(x)+'\n')
def count(n):
 p=s/(n+'-count');v=int(p.read_text())+1 if p.exists() else 1;p.write_text(str(v));return v
if any(k in os.environ for k in ['owner_password','backup_key','approval_input']):die('SECRET_EXPORTED_TO_'+name)
if any('synthetic-owner-%@#' in v or 'AwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwM=' in v for v in a):die('SECRET_IN_ARGV')
if name=='cygpath':print(native(a[-1]));sys.exit()
if name=='git':die()
if name=='node':
 if a[:2]==['-','C:/Users/user/campuspay-stage.p1RrSnsE/source']:
  sys.stdin.read();n=count('source');event('source-check')
  if scenario=='source-changed' or scenario=='source-changed-late' and n==2:die('SOURCE_CHANGED')
  if scenario=='download-changed-late' and n==2:
   f=json.loads((s/'fixture.json').read_text());pathlib.Path(f['download']).write_bytes(b'changed')
  sys.exit()
 os.execv(os.environ['REAL_NODE'],[os.environ['REAL_NODE']]+[local(x) for x in a])
if name=='curl':
 assert '--head' in a and '--location' not in a and '--insecure' not in a and '--cookie' not in a and '--header' not in a
 assert a[a.index('--output')+1]=='-'
 phase=int((s/'waf-count').read_text());url=a[-1];event({'http':url})
 if scenario=='curl-exit23':die('synthetic write failure',23)
 host=url.split('/')[2];public=host in ['mica-pos.vercel.app','mica-store.vercel.app']
 if scenario=='hold-lost-after' and phase==3 or scenario=='hold-not-blocked':print('HTTP/2 200\r\nserver: Vercel\r\nx-vercel-id: synthetic\r\n\r\n',end='');sys.exit()
 if public:print('HTTP/2 403\r\nserver: Vercel\r\nx-vercel-id: synthetic\r\n\r\n',end='');sys.exit()
 target=url
 if scenario=='sso-bad-target':target='https://campuspay-8j1gmttl6-econovaria.vercel.app/not-the-request'
 location='https://evil.example/sso?url='+target if scenario=='sso-bad-host' else 'https://vercel.com/sso-api?url='+__import__('urllib.parse').parse.quote(target,safe='')+'&nonce=synthetic'
 print('HTTP/2 302\r\nserver: Vercel\r\nx-vercel-id: synthetic\r\nlocation: '+location+'\r\n\r\n',end='');sys.exit()
if name=='npx':
 assert a[:3]==['--registry=https://registry.npmjs.org','--yes','vercel@62.4.0']
 assert '--scope' in a and a[a.index('--scope')+1]=='team_PRsNkw4DHrGsUHl6ikKw2XyJ'
 project='prj_wXkpTGGYjL6emMhAX6RSwxkafkME';team='team_PRsNkw4DHrGsUHl6ikKw2XyJ';live='dpl_3brN53nacbuaDiT1JMLtYzAKGhKQ';staged='dpl_TUjLdvRW2DTuBAyoAmqUKQSoyWzy'
 if a[3:5]==['firewall','overview']:
  n=count('waf');event('hold-read');rule={'id':'rule_campus_pay_maintenance_9bJUPi','name':'CampusPay maintenance','active':True,'conditionGroup':[{'conditions':[{'type':'path','op':'pre','value':'/'}]}],'action':{'mitigate':{'action':'deny'}}}
  if scenario=='log-only':rule['action']['mitigate']['action']='log'
  if scenario=='rule-changed-late' and n==2:rule['id']='different-rule'
  d={'active':{'firewallEnabled':True,'rules':[rule],'version':3},'draft':{'changes':[]}}
 elif a[3]=='api':
  assert '--method' in a and a[a.index('--method')+1]=='GET';route=a[4];event({'read':route})
  if route=='/v13/deployments/'+staged:d={'id':staged,'projectId':project,'name':'campuspay-pos','target':'production','readyState':'READY','team':{'id':team},'url':'campuspay-8j1gmttl6-econovaria.vercel.app','meta':{'campuspaySourceCommit':'4e55ece88cb0afcc3e85c8f0436f8d346f5c40a1','campuspaySourceTree':'25041b33225b68a95b8f54d8e59e23b0cd624e3e'},'alias':['campuspay-pos-econovaria.vercel.app'],'env':{'SYNTHETIC_SECRET_NEVER_PRINT':'SYNTHETIC_SECRET_NEVER_PRINT'}}
  elif route in ['/v13/deployments/mica-pos.vercel.app','/v13/deployments/mica-store.vercel.app']:d={'id':'wrong' if scenario=='live-moved' else live,'projectId':project,'alias':[route.rsplit('/',1)[1]]}
  elif route=='/v13/deployments/campuspay-pos-econovaria.vercel.app':d={'id':staged,'projectId':project,'name':'campuspay-pos','target':'production','readyState':'READY','team':{'id':team},'url':'campuspay-8j1gmttl6-econovaria.vercel.app','meta':{'campuspaySourceCommit':'4e55ece88cb0afcc3e85c8f0436f8d346f5c40a1','campuspaySourceTree':'25041b33225b68a95b8f54d8e59e23b0cd624e3e'},'alias':['campuspay-pos-econovaria.vercel.app']}
  elif route in ['/v13/deployments/campuspay-pos-git-feat-effective-access-works-536c6a-econovaria.vercel.app','/v13/deployments/campuspay-h8smqq83v-econovaria.vercel.app']:
   domain=route.rsplit('/',1)[1];d={'id':'dpl_preview_'+domain[:8],'projectId':project,'name':'campuspay-pos','target':None,'readyState':'READY','team':{'id':team},'url':domain,'alias':[]}
  elif route=='/v9/projects/'+project:d={'id':project,'name':'campuspay-pos','accountId':team,'targets':{'production':{'id':live,'readyState':'READY','aliasError':None}},'lastAliasRequest':{'jobStatus':'pending','toDeploymentId':staged} if scenario=='pending-promotion' else None,'rollingRelease':None,'ssoProtection':{'deploymentType':'all_except_custom_domains'},'passwordProtection':None,'trustedIps':None}
  elif route=='/v9/projects/'+project+'/domains?limit=100':
   names=['mica-pos.vercel.app','mica-store.vercel.app']+(['unexpected.example'] if scenario=='extra-domain' else [])
   d={'domains':[{'name':n,'projectId':project,'verified':True} for n in names],'pagination':{'count':len(names),'next':None,'prev':None}}
  elif route=='/v1/projects/'+project+'/rolling-release':
   if scenario=='rolling-read-denied':die('FORBIDDEN',1)
   d={'rollingRelease':{'state':'ACTIVE'} if scenario=='rolling-active' else None}
  elif route=='/v7/deployments?projectId='+project+'&state=BUILDING,INITIALIZING,QUEUED&limit=100':d={'deployments':[{'state':'QUEUED'}] if scenario=='concurrent-deployment' else [],'pagination':{'next':None}}
  else:die('UNEXPECTED_VERCEL_READ')
 else:die('VERCEL_WRITE_OR_BYPASS_ATTEMPT')
 print(json.dumps(d));sys.exit()
if name!='docker':die()
def cfile(n):return s/('container-'+n)
if a[:1]==['info']:print('linux');sys.exit()
if a[:2]==['volume','inspect']:print('manual-backup-preparation');sys.exit()
if a[:2]==['image','inspect']:sys.exit()
if a[:2]==['container','inspect']:
 p=cfile(a[-1]);
 if not p.exists():sys.exit(1)
 if '--format' in a:print(p.read_text())
 sys.exit()
if a[:2]==['rm','-f']:
 assert a[-1].startswith('campuspay-apply-');p=cfile(a[-1]);p.unlink(missing_ok=True);event('owned-container-removed');sys.exit()
if a[:1]!=['run']:die()
assert '--pull' in a and a[a.index('--pull')+1]=='never' and '--log-driver' in a and a[a.index('--log-driver')+1]=='none'
assert not any(x in a for x in ['-p','--publish','--privileged'])
joined=' '.join(a)
if 'tls.rootCertificates' in joined:
 assert '--network' in a and a[a.index('--network')+1]=='none';event('node-ca-pinned');sys.exit()
if 'verified-backup.json' in joined and 'BACKUP_PROOF_INVALID' in joined:
 assert '--network' in a and a[a.index('--network')+1]=='none'
 assert any('dst=/work,readonly' in x for x in a)
 f=json.loads((s/'fixture.json').read_text());print((pathlib.Path(f['evidence'])/'verified-backup.json').read_text());event('original-backup-proof-read');sys.exit()
if 'payload=JSON.parse' in joined:
 assert '--network' in a and a[a.index('--network')+1]=='none'
 p=json.load(sys.stdin);actual=hashlib.sha256((json.dumps(p['manifest'],indent=2)+'\n').encode()).hexdigest();assert a[-1]==actual
 import base64
 for n,h in p['manifest'].items():assert hashlib.sha256(base64.b64decode(p['files'][n])).hexdigest()==h
 event('package-materialized');sys.exit()
if a[-1].endswith('/package/tools.mjs'):
 assert '--network' in a and a[a.index('--network')+1]=='none';event('qualified-tools-checked')
 if scenario=='tools-changed':die('QUALIFIED_TOOLS_CHANGED')
 sys.exit()
if 'package/driver.mjs' in joined:
 assert '--network' not in a and '--workdir' in a and a[a.index('--workdir')+1]=='/work'
 raw=sys.stdin.read()
 try:p=json.loads(raw)
 except:die('NO_VALID_SECRET_INPUT',1)
 assert p['key']=='AwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwM=' and p['ownerPassword']=='synthetic-owner-%@#' and p['approval']=='APPLY ONLY THE FIVE CAMPUSPAY MIGRATIONS'
 assert p['hold']['otherWritersStopped'] is True and p['hold']['publicMicaDenied']==4 and p['hold']['generatedSsoBeforeWaf']==8 and p['hold']['generatedDenied']==0 and p['hold']['protectionScope']=='all_except_custom_domains' and p['evidence']['backup']['run']==a[-2]
 event('apply-request');run=a[-1];backup=a[-2]
 if scenario=='linux-draft-lock':die('STOP: DRAFT_NOT_RELEASED_FOR_EXECUTION',1)
 records={'apply-started.json':{'applyRun':run,'backupRun':backup}}
 if scenario=='migration-prefix-failure':records['apply-needs-review.json']={'stage':'KEEP_FULL_HOLD_INSPECT_HISTORY_BEFORE_RETRY','syntheticHistoryCount':33}
 else:records['database-postflight.json']={'status':'DATABASE_37_VERIFIED_PROMOTION_PENDING','candidate':'4e55ece88cb0afcc3e85c8f0436f8d346f5c40a1','applyRun':run,'backupRun':backup,'migrationCount':37,'appliedCount':5,'promotionPerformed':False}
 (s/'database-records.json').write_text(json.dumps(records))
 if scenario=='interrupted-apply':
  cfile(a[a.index('--name')+1]).write_text(run);event('waiting-for-interrupt');time.sleep(30);die('UNINTERRUPTED_FIXTURE')
 if scenario=='migration-prefix-failure':die('STOP: RUNNER_OR_POSTFLIGHT_INCOMPLETE',1)
 print('Synthetic runner finished.');sys.exit()
if 'database-postflight.json' in joined:
 assert '--network' in a and a[a.index('--network')+1]=='none';event('proof-export')
 if scenario=='evidence-export-failure':die('EXPORT_FAILURE')
 print((s/'database-records.json').read_text() if (s/'database-records.json').exists() else '{}');sys.exit()
die()'''
bin_dir=root/'bin';bin_dir.mkdir()
for name in ['node','npx','docker','curl','cygpath','git']:
 p=bin_dir/name;p.write_text(mock);p.chmod(0o700)
cases=[('release-disabled',False),('check-only',True),('success',True),('inherited-export',True),('inherited-allexport',True),('inherited-both',True),('source-changed',False),('source-changed-late',False),('tools-changed',False),('policy-disabled',False),('evidence-substituted',False),('download-changed-late',False),('log-only',False),('hold-not-blocked',False),('live-moved',False),('pending-promotion',False),('extra-domain',False),('rolling-read-denied',False),('rolling-active',False),('concurrent-deployment',False),('rule-changed-late',False),('sso-bad-target',False),('sso-bad-host',False),('curl-exit23',False),('decline',False),('wrong-key',False),('linux-draft-lock',False),('migration-prefix-failure',False),('evidence-export-failure',False),('hold-lost-after',False),('interrupted-apply',False)]
requested=os.environ.get('CAMPUSPAY_SHELL_CASES','').strip()
if requested:
 wanted={x for x in requested.split(',') if x}
 known={name for name,_ in cases}
 if not wanted or not wanted<=known:raise AssertionError(('unknown shell scenarios',sorted(wanted-known)))
 cases=[x for x in cases if x[0] in wanted]
results=[]
for scenario,success in cases:
 case=root/scenario;case.mkdir();(case/'auth').mkdir()
 bundle=case/'review package with spaces';bundle.mkdir()
 for p in src.iterdir():
  if p.is_file():shutil.copyfile(p,bundle/p.name)
 subprocess.run([real_node,str(bundle/'migration-fixtures.mjs'),'--make-fixture',str(case/'data')],check=True)
 f=json.loads((case/'data/fixture.json').read_text());(case/'fixture.json').write_text(json.dumps(f))
 if scenario=='policy-disabled':f['policy']['status']='DRAFT'
 (bundle/'migration-policy.json').write_text(json.dumps(f['policy'],indent=2)+'\n')
 if scenario=='evidence-substituted':
  p=pathlib.Path(f['evidence'])/'verified-backup.json';d=json.loads(p.read_text());d['sha256']='b'*64;p.write_text(json.dumps(d))
 # Independent release is synthetic and confined to temporary fixture copies.
 release=json.loads((bundle/'execution-release.json').read_text());release.update({'status':'PENDING_INDEPENDENT_REVIEW' if scenario=='release-disabled' else 'REVIEWED_FOR_EXECUTION','reviewReference':'SYNTHETIC OFFLINE TEST ONLY','reviewedAt':'2026-10-07T00:00:00Z'})
 (bundle/'execution-release.json').write_text(json.dumps(release)+'\n')
 # The production wrapper itself is unmodified.
 subprocess.run(['python3',str(bundle/'build-review.py')],check=True,stdout=subprocess.DEVNULL)
 env={**os.environ,'HOME':str(case),'CAMPUSPAY_VERCEL_CONFIG_DIR':str(case/'auth'),'FIXTURE_STATE':str(case),'FIXTURE_CASE':scenario,'REAL_NODE':real_node,'FIXTURE_BUNDLE':str(bundle),'PATH':str(bin_dir)+':'+os.environ['PATH']}
 if scenario in ['inherited-export','inherited-both']:env.update({'owner_password':'inherited-owner','backup_key':'inherited-key','approval_input':'inherited-approval'})
 if scenario in ['inherited-allexport','inherited-both']:env['SHELLOPTS']='allexport:braceexpand:hashall:interactive-comments'
 child=pexpect.spawn('/bin/bash',[str(bundle/'campuspay-migrate-only.sh'),'--check-only' if scenario=='check-only' else '--apply',f['original'],f['download']],env=env,encoding='utf-8',timeout=.2,echo=False)
 out='';started=time.monotonic();interrupted=False
 while True:
  i=child.expect([pexpect.EOF,pexpect.TIMEOUT,'Type APPLY ONLY THE FIVE CAMPUSPAY MIGRATIONS.*: ','Paste the retained backup key.*: ','Paste the campuspay_owner password only.*: '])
  if i==1:
   if time.monotonic()-started>120:raise AssertionError((scenario,'timeout',child.before))
   if scenario=='interrupted-apply' and not interrupted and (case/'events.jsonl').exists() and 'waiting-for-interrupt' in (case/'events.jsonl').read_text():child.sendcontrol('c');interrupted=True
   continue
  out+=child.before
  if i==0:break
  if i==2:child.sendline('NO' if scenario=='decline' else 'APPLY ONLY THE FIVE CAMPUSPAY MIGRATIONS')
  elif i==3:child.sendline('bad' if scenario=='wrong-key' else 'AwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwM=')
  elif i==4:child.sendline('synthetic-owner-%@#')
 child.close();code=child.exitstatus;(case/'output.txt').write_text(out)
 assert (code==0)==success,(scenario,code,out)
 events=[json.loads(x) for x in (case/'events.jsonl').read_text().splitlines()] if (case/'events.jsonl').exists() else []
 assert not list(case.glob('container-*')),(scenario,'owned container not cleaned')
 assert not list(case.glob('campuspay-cutover-checks.*/*-http-response.tmp')),(scenario,'HTTP sink retained')
 for secret in ['synthetic-owner-%@#','AwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwM=','SYNTHETIC_SECRET_NEVER_PRINT']:
  assert secret not in out,(scenario,'secret in terminal')
  for p in case.glob('campuspay-cutover-checks.*/*'):
   if p.is_file():assert secret not in p.read_text(),(scenario,'secret persisted',p.name)
 applied=scenario in ['success','inherited-export','inherited-allexport','inherited-both','linux-draft-lock','migration-prefix-failure','evidence-export-failure','hold-lost-after','interrupted-apply']
 assert ('apply-request' in events)==applied,(scenario,events,out)
 if scenario=='check-only':assert 'DB_UNCHECKED' in out and 'apply-request' not in events
 elif success:assert 'DATABASE_37_VERIFIED_PROMOTION_PENDING' in out and int((case/'waf-count').read_text())==3
 else:assert 'DATABASE_37_VERIFIED_PROMOTION_PENDING' not in out
 if scenario in ['migration-prefix-failure','evidence-export-failure','hold-lost-after','interrupted-apply']:assert 'Inspect exact history' in out
 if scenario=='interrupted-apply':assert interrupted and 'owned-container-removed' in events
 results.append({'scenario':scenario,'passed':True,'exit':code,'mockApplyInvoked':applied})
result={'offlineOnly':True,'productionAccessed':False,'mockedExternalTools':['docker','npx','curl','git','cygpath'],'nativeWindowsExecution':False,'productionWrapperUnmodified':True,'syntheticBackupPolicyUsedOnlyInTemporaryMockCopies':True,'fixtureRoot':str(root),'cases':results}
result_file=pathlib.Path(os.environ.get('CAMPUSPAY_SHELL_RESULTS_FILE',str(src/'shell-results.json')));result_file.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
