import fs from 'node:fs';import {validateReviewedMigration} from './migration-evidence.mjs';import {validateHold,validateKey,sourceURL} from './driver.mjs';
try{
 const evidence=JSON.parse(fs.readFileSync(process.argv[2],'utf8')),hold=JSON.parse(fs.readFileSync(process.argv[3],'utf8'));
 validateReviewedMigration(evidence);
 const lines=fs.readFileSync(0,'utf8').split('\n');if(lines.length!==4||lines[3]!==''||lines[0]!=='APPLY ONLY THE FIVE CAMPUSPAY MIGRATIONS')throw 0;
 validateKey(lines[1]);sourceURL(lines[2]);hold.otherWritersStopped=true;validateHold(hold);
 process.stdout.write(JSON.stringify({approval:lines[0],key:lines[1],ownerPassword:lines[2],hold,evidence}));
}catch{console.error('STOP: CUTOVER_INPUT_INVALID');process.exitCode=1;}
