#!/usr/bin/env bash
# Approved five-migration scope only. Maintenance remains; promotion is separate.
(
  set +x
  set +a
  set -euo pipefail
  unset owner_password backup_key approval_input
  export -n owner_password backup_key approval_input
  umask 077
  stop() { printf 'STOP: %s\n' "$1" >&2; exit 1; }
  case "${1:-}" in --check-only|--apply) mode="$1" ;; *) stop 'Invalid migration-package mode.' ;; esac
  [ "$#" -eq 3 ] || stop 'Two retained ciphertext paths are required.'
  : "${CAMPUSPAY_VERCEL_CONFIG_DIR:?Use the existing isolated Vercel-login window}"
  [ -d "$CAMPUSPAY_VERCEL_CONFIG_DIR" ] || stop 'Isolated login directory missing.'
  for binary in node npx docker curl cygpath git; do command -v "$binary" >/dev/null || stop "Missing $binary."; done
  export MSYS_NO_PATHCONV=1 VERCEL_TELEMETRY_DISABLED=1
  unset VERCEL_TOKEN VERCEL_ORG_ID VERCEL_PROJECT_ID
  bundle="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
  bundle_native="$(cygpath -m "$bundle")"
  original_native="$(cygpath -m "$2")"
  download_native="$(cygpath -m "$3")"
  auth_native="$(cygpath -m "$CAMPUSPAY_VERCEL_CONFIG_DIR")"
  source_dir='C:/Users/user/campuspay-stage.p1RrSnsE/source'
  volume='campuspay-tools-91ead009-8c77-49a7-9995-653bae46984e'
  node_image='node@sha256:43ac6c60b8f89723f746e8a92ce91abd5017e627ce1ddfe4238355d3a30b772c'
  pg_image='postgres@sha256:639ab7ceb90e13123085b741fb31ef493fba25463002f6da665352e7b534b652'
  project='prj_wXkpTGGYjL6emMhAX6RSwxkafkME'
  team='team_PRsNkw4DHrGsUHl6ikKw2XyJ'
  manifest_sha='@@MANIFEST_SHA@@'
  node - "$bundle_native" "$manifest_sha" <<'PACKAGE_CHECK'
const fs=require('fs'),path=require('path'),crypto=require('crypto');
try{
 const [root,expected]=process.argv.slice(2),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
 const bytes=fs.readFileSync(path.join(root,'bundle-sha256.json'));
 if(sha(bytes)!==expected)throw 0;
 for(const [name,digest] of Object.entries(JSON.parse(bytes))){
  if(!/^[a-z0-9.-]+$/.test(name))throw 0;const file=path.join(root,name),s=fs.lstatSync(file);
  if(!s.isFile()||s.isSymbolicLink()||s.nlink!==1||sha(fs.readFileSync(file))!==digest)throw 0;
 }
}catch{console.error('STOP: REVIEWED_PACKAGE_CHANGED');process.exit(1);}
PACKAGE_CHECK
  node "$bundle_native/execution-release.mjs"
  source_check() {
    node - "$source_dir" <<'SOURCE_CHECK'
const fs=require('fs'),path=require('path'),cp=require('child_process');
try{
 const root=process.argv[2],p=JSON.parse(fs.readFileSync(path.join(root,'.vercel/project.json')));
 if(p.projectId!=='prj_wXkpTGGYjL6emMhAX6RSwxkafkME'||p.orgId!=='team_PRsNkw4DHrGsUHl6ikKw2XyJ')throw 0;
 const git=(...args)=>cp.execFileSync('git',['-C',root,...args],{encoding:'utf8'}).trim();
 if(git('rev-parse','HEAD')!=='4e55ece88cb0afcc3e85c8f0436f8d346f5c40a1'||git('rev-parse','HEAD^{tree}')!=='25041b33225b68a95b8f54d8e59e23b0cd624e3e'||git('diff','--name-only')||git('diff','--cached','--name-only'))throw 0;
}catch{console.error('STOP: CAMPUSPAY_SOURCE_OR_PROJECT_CHANGED');process.exit(1);}
SOURCE_CHECK
  }
  source_check
  [ "$(docker info --format '{{.OSType}}')" = linux ] || stop 'Linux Docker engine required.'
  [ "$(docker volume inspect --format '{{index .Labels "campuspay.purpose"}}' "$volume")" = manual-backup-preparation ] || stop 'Qualified tools volume missing or mislabeled.'
  docker image inspect "$node_image" >/dev/null
  docker image inspect "$pg_image" >/dev/null
  docker run --rm --pull never --network none --log-driver none \
    --mount "type=volume,src=$volume,dst=/work,readonly" "$node_image" node -e '
      const fs=require("fs"),tls=require("tls");
      if(!fs.readFileSync(process.execPath).equals(fs.readFileSync("/work/.tools/node"))||fs.readFileSync("/work/.tools/root.crt","utf8")!==tls.rootCertificates.join("\n")+"\n")process.exit(1);'
  run="$(node -e 'process.stdout.write(require("crypto").randomUUID())')"
  [[ "$run" =~ ^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$ ]] || stop 'Run identifier invalid.'
  work="/work/.operator-cutover/$run"
  apply_container="campuspay-apply-$run"
  checks="$(mktemp -d "$HOME/campuspay-cutover-checks.XXXXXXXX")"
  checks_native="$(cygpath -m "$checks")"
  attempted=0
  cleanup() {
    code=$?
    trap - EXIT INT TERM
    set +e
    unset owner_password backup_key approval_input
    if docker container inspect "$apply_container" >/dev/null 2>&1; then
      if [ "$(docker container inspect --format '{{index .Config.Labels "campuspay.cutover.run"}}' "$apply_container")" = "$run" ]; then
        docker rm -f "$apply_container" >/dev/null 2>&1 || code=1
      else code=1; fi
    fi
    docker info --format '{{.OSType}}' >/dev/null 2>&1 || code=1
    if [ "$code" -ne 0 ]; then
      printf 'Keep full maintenance. Run %s. No promotion was requested. Retain evidence in %s and volume %s.\n' "$run" "$checks_native" "$volume" >&2
      if [ "$attempted" = 1 ]; then printf 'Apply may have committed a prefix. Inspect exact history under maintenance before any retry; do not restore or replay automatically.\n' >&2; fi
    fi
    exit "$code"
  }
  trap cleanup EXIT
  trap 'exit 130' INT
  trap 'exit 143' TERM
  printf 'Migration-only run: %s\nSanitized evidence: %s\n' "$run" "$checks_native"
  # Read the original sanitized restore proof from the retained qualified volume.
  # Do not rebuild it from a transcript, or require a second host-side copy.
  evidence_native="$checks_native"
  proof_run="$(node -e 'process.stdout.write(JSON.parse(require("fs").readFileSync(process.argv[1])).backup.run)' "$bundle_native/migration-policy.json")"
  [[ "$proof_run" =~ ^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$ ]] || stop 'Reviewed backup run invalid.'
  docker run --rm --pull never --network none --log-driver none \
    --mount "type=volume,src=$volume,dst=/work,readonly" --entrypoint /work/.tools/node "$pg_image" -e '
      const fs=require("fs"),run=process.argv[1];
      if(!/^[a-f0-9-]{36}$/.test(run))throw Error("BACKUP_RUN_INVALID");
      const file="/work/.operator-backup/"+run+"/verified-backup.json";
      const fd=fs.openSync(file,fs.constants.O_RDONLY|fs.constants.O_NOFOLLOW);
      try{const s=fs.fstatSync(fd);if(!s.isFile()||s.nlink!==1||s.size>1048576)throw Error("BACKUP_PROOF_INVALID");process.stdout.write(fs.readFileSync(fd));}finally{fs.closeSync(fd);}
      ' "$proof_run" > "$checks/verified-backup.json"
  node "$bundle_native/migration-evidence.mjs" verify-inputs "$evidence_native" "$original_native" "$download_native" > "$checks/gate-input.json"
  backup_run="$(node -e 'process.stdout.write(JSON.parse(require("fs").readFileSync(process.argv[1])).backup.run)' "$checks_native/gate-input.json")"
  [[ "$backup_run" =~ ^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$ ]] || stop 'Reviewed backup run invalid.'
  # Materialize only the pinned code into a NEW directory in the existing tools volume.
  node "$bundle_native/package-payload.mjs" |
    docker run --rm --pull never -i --network none --log-driver none \
      --mount "type=volume,src=$volume,dst=/work" --entrypoint /work/.tools/node "$pg_image" -e '
      const fs=require("fs"),crypto=require("crypto"),sha=b=>crypto.createHash("sha256").update(b).digest("hex");
      const [work,expected]=process.argv.slice(1),payload=JSON.parse(fs.readFileSync(0,"utf8"));
      if(!/^\/work\/\.operator-cutover\/[a-f0-9-]{36}$/.test(work)||sha(JSON.stringify(payload.manifest,null,2)+"\n")!==expected)throw Error("PACKAGE_MISMATCH");
      fs.mkdirSync("/work/.operator-cutover",{recursive:true,mode:448});
      if(fs.realpathSync("/work/.operator-cutover")!=="/work/.operator-cutover")throw Error("LINKED_RUN_PARENT");
      fs.mkdirSync(work,{mode:448});fs.mkdirSync(work+"/package",{mode:448});fs.mkdirSync(work+"/result",{mode:448});
      for(const [name,digest] of Object.entries(payload.manifest)){
       if(!/^[a-z0-9.-]+$/.test(name))throw Error("PACKAGE_FILENAME");const bytes=Buffer.from(payload.files[name],"base64");
       if(sha(bytes)!==digest)throw Error("PACKAGE_HASH");fs.writeFileSync(work+"/package/"+name,bytes,{flag:"wx",mode:384});
      }
      ' "$work" "$manifest_sha"
  docker run --rm --pull never --network none --log-driver none \
    --mount "type=volume,src=$volume,dst=/work,readonly" --entrypoint /work/.tools/node "$pg_image" "$work/package/tools.mjs"
  vc() { npx --registry=https://registry.npmjs.org --yes vercel@62.4.0 "$@" --scope "$team" --global-config "$auth_native" --cwd "$source_dir" --non-interactive; }
  hold_checks() {
    phase="$1"
    vc firewall overview --json --project "$project" | node "$bundle_native/hold-guard.mjs" waf > "$checks/$phase-waf.json"
    vc api '/v13/deployments/dpl_TUjLdvRW2DTuBAyoAmqUKQSoyWzy' --method GET | node "$bundle_native/hold-guard.mjs" deployment > "$checks/$phase-candidate.json"
    vc api "/v9/projects/$project" --method GET | node "$bundle_native/hold-guard.mjs" project > "$checks/$phase-project.json"
    vc api "/v9/projects/$project/domains?limit=100" --method GET | node "$bundle_native/hold-guard.mjs" domains > "$checks/$phase-domains.json"
    vc api "/v1/projects/$project/rolling-release" --method GET | node "$bundle_native/hold-guard.mjs" rolling > "$checks/$phase-rolling.json"
    vc api "/v7/deployments?projectId=$project&state=BUILDING,INITIALIZING,QUEUED&limit=100" --method GET | node "$bundle_native/hold-guard.mjs" active > "$checks/$phase-active.json"
    for domain in mica-pos.vercel.app mica-store.vercel.app; do
      vc api "/v13/deployments/$domain" --method GET | node "$bundle_native/hold-guard.mjs" domain "$domain" > "$checks/$phase-$domain.json"
    done
    for domain in campuspay-pos-econovaria.vercel.app campuspay-pos-git-feat-effective-access-works-536c6a-econovaria.vercel.app campuspay-h8smqq83v-econovaria.vercel.app; do
      vc api "/v13/deployments/$domain" --method GET | node "$bundle_native/hold-guard.mjs" generated "$domain" > "$checks/$phase-$domain.json"
    done
    node "$bundle_native/hold-guard.mjs" context "$checks_native" "$phase" > "$checks/$phase-context.json"
    probe=0
    for domain in mica-pos.vercel.app mica-store.vercel.app campuspay-8j1gmttl6-econovaria.vercel.app campuspay-pos-econovaria.vercel.app campuspay-pos-git-feat-effective-access-works-536c6a-econovaria.vercel.app campuspay-h8smqq83v-econovaria.vercel.app; do
      for route in / /api/health; do
        probe=$((probe+1))
        set +e
        curl --disable --silent --show-error --head --max-time 20 --connect-timeout 10 --proto '=https' --output - "https://$domain$route" |
          node "$bundle_native/hold-guard.mjs" http "https://$domain$route" "$checks_native/$phase-context.json" > "$checks/$phase-probe-$probe.json"
        probe_codes=( "${PIPESTATUS[@]}" )
        set -e
        [ "${probe_codes[0]}" -eq 0 ] || stop "Hold probe transport failed with curl exit ${probe_codes[0]} for $domain$route."
        [ "${probe_codes[1]}" -eq 0 ] || stop "Unverified hold response for $domain$route; inspect without following or bypassing protection."
      done
    done
    node "$bundle_native/hold-guard.mjs" finalize "$checks_native" "$phase" > "$checks/$phase-hold.json"
  }
  hold_checks initial
  if [ "$mode" = --check-only ]; then
    printf 'OFFLINE_EVIDENCE_AND_HOLD_PASSED_DB_UNCHECKED. No database connection opened.\n'
    exit 0
  fi
  printf 'Required now: all other writers stopped; unknown financial results recovered on their original register; affected drawers closed; full maintenance remains unchanged.\n'
  printf 'Five migrations only; promotion is separate. Type APPLY ONLY THE FIVE CAMPUSPAY MIGRATIONS to confirm the reviewed cutover and these prerequisites: ' > /dev/tty
  IFS= read -r approval_input < /dev/tty
  export -n approval_input
  [ "$approval_input" = 'APPLY ONLY THE FIVE CAMPUSPAY MIGRATIONS' ] || stop 'Apply not confirmed.'
  read_secret() {
    set +a
    export -n owner_password backup_key approval_input
    printf '%s' "$2" > /dev/tty
    IFS= read -r -s "$1" < /dev/tty || stop 'Secret input canceled.'
    export -n owner_password backup_key approval_input
    printf '\n' > /dev/tty
  }
  read_secret backup_key 'Paste the retained backup key from Apple Passwords (hidden): '
  read_secret owner_password 'Paste the campuspay_owner password only (hidden): '
  source_check
  # Rehash both physical ciphertext copies and revalidate all pinned review evidence.
  node "$bundle_native/migration-evidence.mjs" verify-inputs "$evidence_native" "$original_native" "$download_native" > "$checks/gate-input.json"
  hold_checks before-apply
  printf '{"stage":"OPERATOR_INVOCATION_STARTING","run":"%s","backupRun":"%s"}\n' "$run" "$backup_run" > "$checks/operator-attempt.json"
  attempted=1
  apply_code=0
  printf '%s\n%s\n%s\n' "$approval_input" "$backup_key" "$owner_password" |
    node "$bundle_native/pack-input.mjs" "$checks_native/gate-input.json" "$checks_native/before-apply-hold.json" |
    docker run --rm --pull never -i --log-driver none --name "$apply_container" \
      --label "campuspay.cutover.run=$run" --workdir /work \
      --mount "type=volume,src=$volume,dst=/work" --entrypoint sh "$pg_image" \
      -ceu 'mkdir -p /root/.postgresql; cp /work/.tools/root.crt /root/.postgresql/root.crt; exec /work/.tools/node "$1/package/driver.mjs" "$2" "$3"' sh "$work" "$backup_run" "$run" \
      > "$checks/runner-output.txt" 2> "$checks/runner-error.txt" || apply_code=$?
  unset owner_password backup_key approval_input
  # Export only known sanitized records. Preserve Linux evidence on failure or interruption.
  export_code=0
  docker run --rm --pull never --network none --log-driver none \
    --mount "type=volume,src=$volume,dst=/work,readonly" --entrypoint /work/.tools/node "$pg_image" -e '
      const fs=require("fs"),dir=process.argv[1]+"/result",out={};
      for(const name of ["apply-started.json","apply-needs-review.json","database-postflight.json"]){const file=dir+"/"+name;if(fs.existsSync(file)){const s=fs.lstatSync(file);if(!s.isFile()||s.isSymbolicLink()||s.size>65536)throw Error("PROOF_FILE_INVALID");out[name]=JSON.parse(fs.readFileSync(file));}}
      console.log(JSON.stringify(out,null,2));' "$work" > "$checks/database-evidence.json" || export_code=$?
  [ "$apply_code" -eq 0 ] || stop 'Apply or postflight failed; inspect retained records and exact history before retry.'
  [ "$export_code" -eq 0 ] || stop 'Postflight evidence export failed; preserve Linux records.'
  node - "$checks_native/database-evidence.json" "$run" "$backup_run" <<'RESULT_CHECK'
const fs=require('fs');try{const d=JSON.parse(fs.readFileSync(process.argv[2])),r=d['database-postflight.json'];if(d['apply-needs-review.json']||!d['apply-started.json']||r?.status!=='DATABASE_37_VERIFIED_PROMOTION_PENDING'||r.applyRun!==process.argv[3]||r.backupRun!==process.argv[4]||r.candidate!=='4e55ece88cb0afcc3e85c8f0436f8d346f5c40a1'||r.migrationCount!==37||r.appliedCount!==5||r.promotionPerformed!==false)throw 0;}catch{console.error('STOP: DATABASE_POSTFLIGHT_PROOF_INCOMPLETE');process.exit(1);}
RESULT_CHECK
  hold_checks after-apply
  printf 'DATABASE_37_VERIFIED_PROMOTION_PENDING. Full maintenance remains. No promotion or operator exception was requested. Retain all evidence.\n'
)
