import fs from 'node:fs';import assert from 'node:assert/strict';import {randomUUID} from 'node:crypto';
import pg from '/work/node_modules/pg/lib/index.js';
import {CONTRACT,inventory,beforeMigration,afterMigration,invokeQualifiedRunner,validateOwnerDefaultPrivileges} from './core.mjs';
import {reserveAttempt} from './driver.mjs';
const control=new pg.Client({connectionString:'postgresql://postgres@localhost:5432/postgres?sslmode=disable'});
const originalClient=pg.Client,originalArgv=process.argv;
const cases=[
 {name:'source changed after backup',code:/SOURCE_CHANGED_SINCE_BACKUP/,count:32,mutate:async c=>c.query("update private.system_settings set funding_enabled=not funding_enabled")},
 {name:'baseline history gap',code:/HISTORY_MISMATCH/,count:31,mutate:async c=>c.query('delete from private.schema_migrations where version=$1',[CONTRACT.baselineMigrations[3].version])},
 {name:'runtime direct table grant',code:/RUNTIME_DIRECT_DATA_ACCESS/,count:32,mutate:async c=>c.query('grant select on private.wallets to campuspay_runtime_login')},
 {name:'runtime direct column grant',code:/RUNTIME_DIRECT_DATA_ACCESS/,count:32,mutate:async c=>c.query('grant select (balance_won) on private.wallets to campuspay_runtime_login')},
 {name:'unexpected privileged membership',code:/RUNTIME_MEMBERSHIP_UNEXPECTED/,count:32,mutate:async(_c,ctl)=>ctl.query('grant pg_execute_server_program to campuspay_runtime_login'),undo:async(_c,ctl)=>ctl.query('revoke pg_execute_server_program from campuspay_runtime_login')},
 {name:'migration 046 counted anchor drift',code:/RUNNER_OR_POSTFLIGHT_INCOMPLETE/,count:33,mutate:async c=>{
  const d=(await c.query("select pg_get_functiondef('api.search_students(uuid,text)'::regprocedure) as d")).rows[0].d;
  assert.ok(d.includes("'students.manage'"));await c.query(d.replace("'students.manage'","'synthetic.anchor.changed'"));
 }}
];
const results=[];
try{
 await control.connect();
 await control.query("do $$ begin if not exists(select 1 from pg_roles where rolname='campuspay_owner') then create role campuspay_owner login inherit nosuperuser createdb createrole replication bypassrls; end if; end $$");
 const ownerRole=(await control.query("select rolcanlogin,rolsuper,rolcreatedb,rolcreaterole,rolreplication,rolbypassrls,rolinherit from pg_roles where rolname='campuspay_owner'")).rows[0];assert.deepEqual(ownerRole,{rolcanlogin:true,rolsuper:false,rolcreatedb:true,rolcreaterole:true,rolreplication:true,rolbypassrls:true,rolinherit:true});
 for(const scenario of cases){
  const db='campuspay_failure_'+randomUUID().replaceAll('-','');let c,created=false,afterCalled=false;
  try{
   await control.query('create database "'+db+'" owner campuspay_owner template template0');created=true;
   const url='postgresql://campuspay_owner@localhost:5432/'+db+'?sslmode=disable';c=new pg.Client({connectionString:url});await c.connect();
   const ownerIdentity=(await c.query("select current_user as role,(select datdba::regrole::text from pg_database where datname=current_database()) as database_owner")).rows[0];assert.deepEqual(ownerIdentity,{role:'campuspay_owner',database_owner:'campuspay_owner'});
   for(const m of CONTRACT.baselineMigrations){await c.query('begin');await c.query(fs.readFileSync('/work/database/migrations/'+m.version+'.sql','utf8'));await c.query('insert into private.schema_migrations(version) values($1) on conflict do nothing',[m.version]);await c.query('commit');}
   await validateOwnerDefaultPrivileges(c);
   await c.query("do $$ begin if not exists(select 1 from pg_roles where rolname='campuspay_runtime_login') then create role campuspay_runtime_login login;end if;end $$");await c.query('grant campuspay_runtime to campuspay_runtime_login');
   const metadata={tables:await inventory(c)};await scenario.mutate(c,control);await c.end();c=null;
   process.env.DATABASE_URL_UNPOOLED=url;process.env.EXPECTED_DATABASE_HOST='localhost';
   const attemptDir='/work/.cutover/attempt-'+randomUUID();fs.mkdirSync(attemptDir);
   const attemptRecord={candidate:CONTRACT.candidate,backupRun:'synthetic-only',applyRun:db};
   await assert.rejects(invokeQualifiedRunner({pg,root:'/work',before:async c=>beforeMigration(c,metadata),beforeFirstDDL:async()=>reserveAttempt(attemptDir,attemptRecord),after:async(c,b)=>{afterCalled=true;return afterMigration(c,b);}}),scenario.code);
   assert.equal(process.exitCode,1);process.exitCode=0;assert.equal(afterCalled,false);assert.equal(pg.Client,originalClient);assert.equal(process.argv,originalArgv);
   c=new pg.Client({connectionString:url});await c.connect();
   const rows=(await c.query('select version from private.schema_migrations order by version')).rows.map(x=>x.version);assert.equal(rows.length,scenario.count);
   assert.equal((await c.query('select pg_try_advisory_lock(84632291) as got')).rows[0].got,true);await c.query('select pg_advisory_unlock(84632291)');
   if(scenario.count===33){
    assert.deepEqual(rows,[...CONTRACT.baselineMigrations.map(m=>m.version),CONTRACT.pendingMigrations[0].version]);
    // 046 creates this helper before the counted edit fails: absence proves whole-file rollback.
    assert.equal((await c.query("select to_regprocedure('private.funding_capability(text)') as helper")).rows[0].helper,null);
    await assert.rejects(beforeMigration(c,metadata),/HISTORY_MISMATCH/);
    assert.deepEqual(JSON.parse(fs.readFileSync(attemptDir+'/cutover-attempt.json')),attemptRecord);
    assert.throws(()=>reserveAttempt(attemptDir,attemptRecord),/BACKUP_ALREADY_USED_FOR_APPLY_REVIEW_REQUIRED/);
   }else if(scenario.count===32){assert.equal((await c.query("select to_regclass('private.staff_access') as access")).rows[0].access,null);}
   results.push({scenario:scenario.name,rejected:true,migrationCount:rows.length,noPostflightSuccess:true,lockReleased:true,blindRetryBlocked:scenario.count===33});
  }finally{
   if(scenario.undo)await scenario.undo(c,control);if(c)await c.end();
   if(created)await control.query('drop database "'+db+'" with (force)');
  }
 }
 const proof={syntheticOnly:true,productionAccessed:false,databaseRole:'campuspay_owner',databaseOwner:'campuspay_owner',ownerFixtureVerified:true,ownerRoleAttributesVerified:true,ownerDefaultPrivilegesVerified:true,runnerUnmodified:true,expectedCaseCount:cases.length,passed:results.length,failed:0,skipped:0,cancelled:0,cases:results};
 fs.writeFileSync('/work/.cutover/failure-results.json',JSON.stringify(proof,null,2)+'\n');console.log(JSON.stringify(proof,null,2));
}catch(e){console.error('SYNTHETIC_FAILURE_TEST_FAILED',e.message);process.exitCode=1;}
finally{await control.end();}
