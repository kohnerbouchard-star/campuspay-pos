-- CampusPay v0.8.0 initial Neon/PostgreSQL migration
-- Generated from database/schema/*.sql.
-- Apply with a direct/unpooled connection as the database owner.

-- BEGIN 001_foundation.sql
-- CampusPay foundation for Neon or standard PostgreSQL.
create schema if not exists extensions;
create extension if not exists pgcrypto with schema extensions;

create schema if not exists private;
create schema if not exists api;

revoke all on schema private from public;
revoke all on schema api from public;
revoke create on schema public from public;

do $$
begin
  if not exists (select 1 from pg_roles where rolname = 'campuspay_runtime') then
    create role campuspay_runtime nologin noinherit;
  end if;
end;
$$;

do $$ begin execute format('grant campuspay_runtime to %I', current_user); end; $$;
grant usage on schema api to campuspay_runtime;

create type public.staff_role as enum ('cashier', 'inventory_admin', 'accountant', 'super_admin');
create type public.cost_method as enum ('FIFO', 'LIFO');
create type private.intent_state as enum ('awaiting_card', 'awaiting_pin', 'completed', 'cancelled', 'expired');
create type private.wallet_direction as enum ('CREDIT', 'DEBIT');
create type private.inventory_movement_type as enum (
  'PURCHASE_RECEIPT', 'SALE', 'SALE_REVERSAL', 'DAMAGED', 'EXPIRED', 'SUPPLIER_RETURN', 'STOCK_COUNT_LOSS'
);

create sequence if not exists private.sale_receipt_sequence;
create sequence if not exists private.stock_receipt_sequence;
create sequence if not exists private.adjustment_sequence;

create table public.staff_profiles (
  auth_user_id uuid primary key default gen_random_uuid(),
  employee_code text not null unique check (employee_code ~ '^[A-Za-z0-9_-]{2,32}$'),
  display_name text not null check (length(display_name) between 1 and 120),
  role public.staff_role not null,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table private.staff_credentials (
  staff_user_id uuid primary key references public.staff_profiles(auth_user_id) on delete cascade,
  pin_hash text not null,
  failed_attempts integer not null default 0 check (failed_attempts >= 0),
  locked_until timestamptz,
  pin_updated_at timestamptz not null default now()
);

create table public.products (
  id uuid primary key default gen_random_uuid(),
  sku text not null unique check (length(sku) between 1 and 40),
  name text not null check (length(name) between 1 and 120),
  category text not null check (length(category) between 1 and 80),
  selling_price_won bigint not null check (selling_price_won >= 0),
  reorder_level integer not null default 0 check (reorder_level >= 0),
  active boolean not null default true,
  created_by uuid not null references public.staff_profiles(auth_user_id) on delete restrict,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table private.system_settings (
  singleton boolean primary key default true check (singleton),
  negative_wallet_limit_won bigint not null default -15000 check (negative_wallet_limit_won <= 0),
  inventory_cost_method public.cost_method not null default 'FIFO',
  updated_by uuid references public.staff_profiles(auth_user_id) on delete restrict,
  updated_at timestamptz not null default now()
);
insert into private.system_settings(singleton) values (true) on conflict (singleton) do nothing;

create table private.terminals (
  id uuid primary key default gen_random_uuid(),
  terminal_fingerprint text not null unique check (length(terminal_fingerprint) = 64),
  label text,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  last_seen_at timestamptz not null default now()
);

create table private.staff_sessions (
  id uuid primary key default gen_random_uuid(),
  auth_user_id uuid not null references public.staff_profiles(auth_user_id) on delete cascade,
  employee_code_snapshot text not null,
  role_snapshot public.staff_role not null,
  terminal_id uuid not null references private.terminals(id) on delete restrict,
  session_token_hash text not null unique check (length(session_token_hash) = 64),
  last_activity_at timestamptz not null default now(),
  expires_at timestamptz not null,
  revoked_at timestamptz,
  created_at timestamptz not null default now()
);
create index staff_sessions_active_idx on private.staff_sessions(auth_user_id, expires_at) where revoked_at is null;

create table private.students (
  id uuid primary key default gen_random_uuid(),
  student_code text not null unique,
  display_name text not null,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table private.student_credentials (
  student_id uuid primary key references private.students(id) on delete cascade,
  pin_hash text not null,
  failed_attempts integer not null default 0 check (failed_attempts >= 0),
  locked_until timestamptz,
  pin_updated_at timestamptz not null default now()
);

create table private.student_cards (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references private.students(id) on delete cascade,
  card_fingerprint text not null unique check (length(card_fingerprint) = 64),
  active boolean not null default true,
  issued_by uuid references public.staff_profiles(auth_user_id) on delete restrict,
  issued_at timestamptz not null default now(),
  deactivated_at timestamptz
);
create unique index one_active_card_per_student on private.student_cards(student_id) where active;

create table private.wallets (
  student_id uuid primary key references private.students(id) on delete restrict,
  balance_won bigint not null default 0 check (balance_won >= -15000),
  updated_at timestamptz not null default now()
);

create table private.wallet_ledger (
  id uuid primary key default gen_random_uuid(),
  reference_number text not null unique,
  student_id uuid not null references private.students(id) on delete restrict,
  amount_won bigint not null check (amount_won <> 0),
  entry_type text not null,
  reason_code text not null,
  balance_before_won bigint not null,
  balance_after_won bigint not null,
  staff_user_id uuid not null references public.staff_profiles(auth_user_id) on delete restrict,
  staff_session_id uuid not null references private.staff_sessions(id) on delete restrict,
  source_type text not null,
  source_id uuid,
  idempotency_key uuid not null unique,
  notes text,
  created_at timestamptz not null default now()
);
create index wallet_ledger_student_created_idx on private.wallet_ledger(student_id, created_at desc);

create table private.product_price_history (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete restrict,
  old_price_won bigint not null,
  new_price_won bigint not null,
  reason text not null,
  changed_by uuid not null references public.staff_profiles(auth_user_id) on delete restrict,
  staff_session_id uuid not null references private.staff_sessions(id) on delete restrict,
  changed_at timestamptz not null default now()
);

create table private.stock_receipts (
  id uuid primary key default gen_random_uuid(),
  receipt_number text not null unique,
  supplier_name text not null,
  supplier_invoice text not null,
  purchase_date date not null,
  purchase_subtotal_won bigint not null check (purchase_subtotal_won >= 0),
  shipping_won bigint not null check (shipping_won >= 0),
  other_costs_won bigint not null check (other_costs_won >= 0),
  discount_won bigint not null check (discount_won >= 0),
  total_landed_cost_won bigint not null check (total_landed_cost_won >= 0),
  notes text,
  received_by uuid not null references public.staff_profiles(auth_user_id) on delete restrict,
  staff_session_id uuid not null references private.staff_sessions(id) on delete restrict,
  idempotency_key uuid not null unique,
  created_at timestamptz not null default now(),
  unique(supplier_name, supplier_invoice)
);

create table private.stock_receipt_lines (
  id uuid primary key default gen_random_uuid(),
  receipt_id uuid not null references private.stock_receipts(id) on delete restrict,
  product_id uuid not null references public.products(id) on delete restrict,
  quantity integer not null check (quantity > 0),
  purchase_unit_cost_won bigint not null check (purchase_unit_cost_won >= 0),
  base_cost_won bigint not null check (base_cost_won >= 0),
  allocated_overhead_won bigint not null check (allocated_overhead_won >= 0),
  allocated_discount_won bigint not null check (allocated_discount_won >= 0),
  total_landed_cost_won bigint not null check (total_landed_cost_won >= 0),
  supplier_lot_code text,
  expiration_date date,
  created_at timestamptz not null default now()
);

create table private.inventory_lots (
  id uuid primary key default gen_random_uuid(),
  receipt_line_id uuid not null unique references private.stock_receipt_lines(id) on delete restrict,
  product_id uuid not null references public.products(id) on delete restrict,
  received_at timestamptz not null default now(),
  expiration_date date,
  quantity_received integer not null check (quantity_received > 0),
  quantity_remaining integer not null check (quantity_remaining between 0 and quantity_received),
  landed_unit_cost_won numeric(18,6) not null check (landed_unit_cost_won >= 0),
  created_at timestamptz not null default now()
);
create index inventory_lots_allocation_idx on private.inventory_lots(product_id, received_at, id) where quantity_remaining > 0;

create table private.inventory_movements (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete restrict,
  lot_id uuid not null references private.inventory_lots(id) on delete restrict,
  movement_type private.inventory_movement_type not null,
  quantity_change integer not null check (quantity_change <> 0),
  unit_cost_won numeric(18,6) not null check (unit_cost_won >= 0),
  total_cost_won bigint not null,
  reason_code text not null,
  notes text,
  staff_user_id uuid not null references public.staff_profiles(auth_user_id) on delete restrict,
  staff_session_id uuid not null references private.staff_sessions(id) on delete restrict,
  source_type text not null,
  source_id uuid,
  idempotency_key uuid,
  created_at timestamptz not null default now()
);
create index inventory_movements_product_created_idx on private.inventory_movements(product_id, created_at desc);

create table private.payment_intents (
  id uuid primary key default gen_random_uuid(),
  idempotency_key uuid not null unique,
  staff_session_id uuid not null references private.staff_sessions(id) on delete restrict,
  student_id uuid references private.students(id) on delete restrict,
  state private.intent_state not null default 'awaiting_card',
  total_won bigint not null check (total_won > 0),
  pin_attempts integer not null default 0 check (pin_attempts between 0 and 3),
  card_scanned_at timestamptz,
  completed_sale_id uuid,
  expires_at timestamptz not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table private.payment_intent_items (
  id uuid primary key default gen_random_uuid(),
  intent_id uuid not null references private.payment_intents(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete restrict,
  quantity integer not null check (quantity > 0),
  unit_price_won bigint not null check (unit_price_won >= 0),
  line_total_won bigint not null check (line_total_won >= 0),
  unique(intent_id, product_id)
);

create table private.sales (
  id uuid primary key default gen_random_uuid(),
  receipt_number text not null unique,
  student_id uuid not null references private.students(id) on delete restrict,
  cashier_user_id uuid not null references public.staff_profiles(auth_user_id) on delete restrict,
  staff_session_id uuid not null references private.staff_sessions(id) on delete restrict,
  total_won bigint not null check (total_won > 0),
  cost_of_goods_sold_won bigint not null default 0 check (cost_of_goods_sold_won >= 0),
  wallet_ledger_id uuid,
  payment_intent_id uuid not null unique references private.payment_intents(id) on delete restrict,
  created_at timestamptz not null default now()
);

alter table private.payment_intents
  add constraint payment_intents_completed_sale_fk
  foreign key (completed_sale_id) references private.sales(id) on delete restrict;

create table private.sale_items (
  id uuid primary key default gen_random_uuid(),
  sale_id uuid not null references private.sales(id) on delete restrict,
  product_id uuid not null references public.products(id) on delete restrict,
  product_name_snapshot text not null,
  quantity integer not null check (quantity > 0),
  unit_price_won bigint not null check (unit_price_won >= 0),
  line_total_won bigint not null check (line_total_won >= 0),
  cogs_won bigint not null default 0 check (cogs_won >= 0)
);

create table private.sale_cost_allocations (
  id uuid primary key default gen_random_uuid(),
  sale_item_id uuid not null references private.sale_items(id) on delete restrict,
  inventory_lot_id uuid not null references private.inventory_lots(id) on delete restrict,
  quantity integer not null check (quantity > 0),
  unit_cost_won numeric(18,6) not null check (unit_cost_won >= 0),
  total_cost_won bigint not null check (total_cost_won >= 0),
  created_at timestamptz not null default now()
);

create table private.wallet_adjustment_intents (
  id uuid primary key default gen_random_uuid(),
  idempotency_key uuid not null unique,
  staff_session_id uuid not null references private.staff_sessions(id) on delete restrict,
  student_id uuid references private.students(id) on delete restrict,
  direction private.wallet_direction not null,
  amount_won bigint not null check (amount_won > 0),
  denominations integer[] not null,
  reason_code text not null,
  notes text not null,
  state private.intent_state not null default 'awaiting_card',
  pin_attempts integer not null default 0 check (pin_attempts between 0 and 3),
  completed_ledger_id uuid references private.wallet_ledger(id) on delete restrict,
  expires_at timestamptz not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table private.elevation_tokens (
  id uuid primary key default gen_random_uuid(),
  token_hash text not null unique check (length(token_hash) = 64),
  requested_by uuid not null references public.staff_profiles(auth_user_id) on delete restrict,
  approved_by uuid not null references public.staff_profiles(auth_user_id) on delete restrict,
  staff_session_id uuid not null references private.staff_sessions(id) on delete restrict,
  purpose text not null check (purpose in ('RESET_STUDENT_PIN', 'RESET_STUDENT_CARD')),
  student_id uuid not null references private.students(id) on delete restrict,
  expires_at timestamptz not null,
  consumed_at timestamptz,
  created_at timestamptz not null default now()
);

create table private.audit_events (
  id uuid primary key default gen_random_uuid(),
  event_type text not null,
  actor_user_id uuid references public.staff_profiles(auth_user_id) on delete restrict,
  approver_user_id uuid references public.staff_profiles(auth_user_id) on delete restrict,
  staff_session_id uuid references private.staff_sessions(id) on delete restrict,
  subject_type text,
  subject_id uuid,
  reference_number text not null unique,
  safe_payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

-- The runtime role receives no direct table or sequence access.
revoke all on all tables in schema private from public, campuspay_runtime;
revoke all on all sequences in schema private from public, campuspay_runtime;
revoke all on public.staff_profiles, public.products from public, campuspay_runtime;
-- END 001_foundation.sql

-- BEGIN 002_auth_helpers.sql
create or replace function private.permissions_for_role(p_role public.staff_role)
returns text[]
language sql
immutable
set search_path = ''
as $$
  select case p_role
    when 'cashier' then array['pos.read','pos.checkout','coupons.redeem']::text[]
    when 'inventory_admin' then array[
      'inventory.read','inventory.receive','inventory.adjust','inventory.product.manage','inventory.price.manage',
      'coupons.manage','reports.inventory','security.credentials.request'
    ]::text[]
    when 'accountant' then array[
      'wallet.read','wallet.adjust','reports.sales','reports.inventory','reports.wallets','reports.coupons',
      'security.credentials.request'
    ]::text[]
    when 'super_admin' then array[
      'pos.read','pos.checkout','coupons.redeem',
      'inventory.read','inventory.receive','inventory.adjust','inventory.product.manage','inventory.price.manage',
      'coupons.manage','wallet.read','wallet.adjust',
      'reports.sales','reports.inventory','reports.wallets','reports.coupons',
      'security.credentials.request','security.step_up','security.credentials.reset','security.staff.manage'
    ]::text[]
  end;
$$;

create or replace function private.role_has_permission(p_role public.staff_role, p_permission text)
returns boolean
language sql
immutable
set search_path = ''
as $$
  select p_permission = any(private.permissions_for_role(p_role));
$$;

create or replace function private.session_timeout(p_role public.staff_role)
returns interval
language sql
immutable
set search_path = ''
as $$
  select case when p_role = 'cashier' then interval '20 seconds' else interval '2 minutes' end;
$$;

create or replace function private.verify_staff_pin(
  p_employee_code text,
  p_pin_proof text,
  p_required_role public.staff_role default null
)
returns public.staff_profiles
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_profile public.staff_profiles;
  v_credential private.staff_credentials;
  v_now timestamptz := now();
begin
  if p_employee_code is null or p_employee_code !~ '^[A-Za-z0-9_-]{2,32}$'
     or p_pin_proof is null or p_pin_proof !~ '^[a-f0-9]{64}$' then
    raise exception 'UNAUTHENTICATED';
  end if;

  select sp.* into v_profile
  from public.staff_profiles sp
  where lower(sp.employee_code) = lower(p_employee_code) and sp.active;
  if not found then raise exception 'UNAUTHENTICATED'; end if;

  select * into v_credential
  from private.staff_credentials
  where staff_user_id = v_profile.auth_user_id
  for update;
  if not found then raise exception 'UNAUTHENTICATED'; end if;
  if v_credential.locked_until is not null and v_credential.locked_until > v_now then
    raise exception 'RATE_LIMITED';
  end if;

  if extensions.crypt(p_pin_proof, v_credential.pin_hash) <> v_credential.pin_hash then
    update private.staff_credentials
    set failed_attempts = failed_attempts + 1,
        locked_until = case when failed_attempts + 1 >= 5 then v_now + interval '5 minutes' else null end
    where staff_user_id = v_profile.auth_user_id;
    raise exception 'UNAUTHENTICATED';
  end if;

  if p_required_role is not null and v_profile.role <> p_required_role then
    raise exception 'UNAUTHENTICATED';
  end if;

  update private.staff_credentials
  set failed_attempts = 0, locked_until = null
  where staff_user_id = v_profile.auth_user_id;
  return v_profile;
end;
$$;

create or replace function private.assert_session(p_session_id uuid, p_permission text)
returns private.staff_sessions
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_session private.staff_sessions;
  v_profile public.staff_profiles;
  v_terminal private.terminals;
begin
  select * into v_session
  from private.staff_sessions
  where id = p_session_id
  for update;

  if not found or v_session.revoked_at is not null or v_session.expires_at <= now() then
    raise exception 'SESSION_EXPIRED';
  end if;

  select * into v_terminal from private.terminals where id = v_session.terminal_id;
  if not found or not v_terminal.active then raise exception 'FORBIDDEN'; end if;

  select * into v_profile
  from public.staff_profiles
  where auth_user_id = v_session.auth_user_id;

  if not found or not v_profile.active or v_profile.role <> v_session.role_snapshot then
    raise exception 'FORBIDDEN';
  end if;

  if p_permission is not null and not private.role_has_permission(v_profile.role, p_permission) then
    raise exception 'FORBIDDEN';
  end if;

  update private.staff_sessions
  set last_activity_at = now(), expires_at = now() + private.session_timeout(v_profile.role)
  where id = v_session.id
  returning * into v_session;

  update private.terminals set last_seen_at = now() where id = v_session.terminal_id;
  return v_session;
end;
$$;

create or replace function private.assert_session_any(p_session_id uuid, p_permissions text[])
returns private.staff_sessions
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_session private.staff_sessions;
  v_role public.staff_role;
  v_permission text;
begin
  select role_snapshot into v_role from private.staff_sessions where id = p_session_id;
  if not found then raise exception 'SESSION_EXPIRED'; end if;
  foreach v_permission in array p_permissions loop
    if private.role_has_permission(v_role, v_permission) then
      return private.assert_session(p_session_id, v_permission);
    end if;
  end loop;
  raise exception 'FORBIDDEN';
end;
$$;

create or replace function api.create_staff_session(
  p_employee_code text,
  p_pin_proof text,
  p_session_token_hash text,
  p_terminal_fingerprint text
)
returns table(
  session_id uuid,
  user_id uuid,
  employee_code text,
  display_name text,
  role public.staff_role,
  permissions text[],
  expires_at timestamptz
)
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_profile public.staff_profiles;
  v_terminal private.terminals;
  v_session private.staff_sessions;
begin
  if p_session_token_hash !~ '^[a-f0-9]{64}$' or p_terminal_fingerprint !~ '^[a-f0-9]{64}$' then
    raise exception 'BAD_REQUEST';
  end if;

  v_profile := private.verify_staff_pin(p_employee_code, p_pin_proof, null);

  insert into private.terminals(terminal_fingerprint)
  values (p_terminal_fingerprint)
  on conflict (terminal_fingerprint) do update set last_seen_at = now()
  returning * into v_terminal;
  if not v_terminal.active then raise exception 'FORBIDDEN'; end if;

  update private.staff_sessions set revoked_at = now()
  where terminal_id = v_terminal.id and revoked_at is null;

  insert into private.staff_sessions(
    auth_user_id, employee_code_snapshot, role_snapshot, terminal_id,
    session_token_hash, expires_at
  ) values (
    v_profile.auth_user_id, v_profile.employee_code, v_profile.role, v_terminal.id,
    p_session_token_hash, now() + private.session_timeout(v_profile.role)
  ) returning * into v_session;

  return query select
    v_session.id, v_profile.auth_user_id, v_profile.employee_code, v_profile.display_name,
    v_profile.role, private.permissions_for_role(v_profile.role), v_session.expires_at;
end;
$$;

create or replace function api.authorize_session(
  p_session_token_hash text,
  p_terminal_fingerprint text,
  p_permission text default null
)
returns table(
  session_id uuid,
  user_id uuid,
  employee_code text,
  display_name text,
  role public.staff_role,
  permissions text[],
  expires_at timestamptz
)
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_session private.staff_sessions;
  v_profile public.staff_profiles;
begin
  select ss.* into v_session
  from private.staff_sessions ss
  join private.terminals t on t.id = ss.terminal_id
  where ss.session_token_hash = p_session_token_hash
    and t.terminal_fingerprint = p_terminal_fingerprint
    and t.active
  for update of ss;

  if not found then raise exception 'SESSION_EXPIRED'; end if;
  v_session := private.assert_session(v_session.id, p_permission);

  select * into v_profile from public.staff_profiles
  where auth_user_id = v_session.auth_user_id and active;
  if not found then raise exception 'FORBIDDEN'; end if;

  return query select
    v_session.id, v_profile.auth_user_id, v_profile.employee_code, v_profile.display_name,
    v_profile.role, private.permissions_for_role(v_profile.role), v_session.expires_at;
end;
$$;

create or replace function api.revoke_staff_session(
  p_session_token_hash text,
  p_terminal_fingerprint text
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  update private.staff_sessions ss
  set revoked_at = now()
  from private.terminals t
  where ss.terminal_id = t.id
    and ss.session_token_hash = p_session_token_hash
    and t.terminal_fingerprint = p_terminal_fingerprint
    and ss.revoked_at is null;
end;
$$;
-- END 002_auth_helpers.sql

-- BEGIN 003_pos_functions.sql
create or replace function api.catalog(p_session_id uuid)
returns table(
  id uuid,
  sku text,
  name text,
  category text,
  selling_price_won bigint,
  stock_on_hand bigint,
  sold_out boolean
)
language plpgsql
security definer
set search_path = ''
as $$
begin
  perform private.assert_session_any(p_session_id, array['pos.read','inventory.read']);
  return query
  select
    p.id, p.sku, p.name, p.category, p.selling_price_won,
    coalesce(sum(l.quantity_remaining), 0)::bigint as stock_on_hand,
    coalesce(sum(l.quantity_remaining), 0) <= 0 as sold_out
  from public.products p
  left join private.inventory_lots l on l.product_id = p.id and l.quantity_remaining > 0
  where p.active
  group by p.id, p.sku, p.name, p.category, p.selling_price_won
  order by p.category, p.name;
end;
$$;

create or replace function api.create_payment_intent(
  p_session_id uuid,
  p_items jsonb,
  p_idempotency_key uuid
)
returns table(
  intent_id uuid,
  state private.intent_state,
  total_won bigint,
  expires_at timestamptz
)
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_session private.staff_sessions;
  v_existing private.payment_intents;
  v_intent private.payment_intents;
  v_item record;
  v_product public.products;
  v_total bigint := 0;
  v_stock bigint;
begin
  v_session := private.assert_session(p_session_id, 'pos.checkout');
  if jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) = 0 or jsonb_array_length(p_items) > 50 then
    raise exception 'BAD_REQUEST';
  end if;

  select * into v_existing from private.payment_intents where idempotency_key = p_idempotency_key;
  if found then
    if v_existing.staff_session_id <> v_session.id then raise exception 'CONFLICT'; end if;
    return query select v_existing.id, v_existing.state, v_existing.total_won, v_existing.expires_at;
    return;
  end if;

  for v_item in
    select
      (entry->>'productId')::uuid as product_id,
      sum((entry->>'quantity')::integer)::integer as quantity
    from jsonb_array_elements(p_items) entry
    group by (entry->>'productId')::uuid
  loop
    if v_item.quantity < 1 or v_item.quantity > 99 then raise exception 'BAD_REQUEST'; end if;
    select * into v_product from public.products where id = v_item.product_id and active;
    if not found then raise exception 'NOT_FOUND'; end if;
    select coalesce(sum(quantity_remaining),0) into v_stock
      from private.inventory_lots where product_id = v_product.id and quantity_remaining > 0;
    if v_stock < v_item.quantity then raise exception 'INVENTORY_SHORTAGE'; end if;
    v_total := v_total + v_product.selling_price_won * v_item.quantity;
  end loop;
  if v_total <= 0 then raise exception 'BAD_REQUEST'; end if;

  insert into private.payment_intents(
    idempotency_key, staff_session_id, total_won, state, expires_at
  ) values (
    p_idempotency_key, v_session.id, v_total, 'awaiting_card', now() + interval '30 seconds'
  ) returning * into v_intent;

  for v_item in
    select
      (entry->>'productId')::uuid as product_id,
      sum((entry->>'quantity')::integer)::integer as quantity
    from jsonb_array_elements(p_items) entry
    group by (entry->>'productId')::uuid
  loop
    select * into v_product from public.products where id = v_item.product_id and active;
    insert into private.payment_intent_items(intent_id, product_id, quantity, unit_price_won, line_total_won)
    values (v_intent.id, v_product.id, v_item.quantity, v_product.selling_price_won, v_product.selling_price_won * v_item.quantity);
  end loop;

  return query select v_intent.id, v_intent.state, v_intent.total_won, v_intent.expires_at;
end;
$$;

create or replace function api.scan_payment_card(
  p_session_id uuid,
  p_intent_id uuid,
  p_card_fingerprint text
)
returns table(
  intent_id uuid,
  state private.intent_state,
  student_display_name text,
  current_balance_won bigint,
  projected_balance_won bigint,
  projected_debt_won bigint,
  expires_at timestamptz
)
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_session private.staff_sessions;
  v_intent private.payment_intents;
  v_student private.students;
  v_balance bigint;
  v_projected bigint;
begin
  v_session := private.assert_session(p_session_id, 'pos.checkout');
  select * into v_intent from private.payment_intents where id = p_intent_id for update;
  if not found or v_intent.staff_session_id <> v_session.id then raise exception 'NOT_FOUND'; end if;
  if v_intent.expires_at <= now() then
    update private.payment_intents set state = 'expired', updated_at = now() where id = v_intent.id;
    raise exception 'SESSION_EXPIRED';
  end if;
  if v_intent.state <> 'awaiting_card' then raise exception 'CONFLICT'; end if;

  select s.* into v_student
  from private.student_cards c
  join private.students s on s.id = c.student_id
  where c.card_fingerprint = p_card_fingerprint and c.active and s.active;
  if not found then raise exception 'NOT_FOUND'; end if;

  select balance_won into v_balance from private.wallets where student_id = v_student.id;
  if not found then raise exception 'NOT_FOUND'; end if;
  v_projected := v_balance - v_intent.total_won;

  update private.payment_intents
  set student_id = v_student.id, state = 'awaiting_pin', card_scanned_at = now(), updated_at = now()
  where id = v_intent.id;

  return query select
    v_intent.id, 'awaiting_pin'::private.intent_state, v_student.display_name,
    v_balance, v_projected, greatest(0::bigint, -v_projected), v_intent.expires_at;
end;
$$;

create or replace function api.confirm_payment(
  p_session_id uuid,
  p_intent_id uuid,
  p_student_pin_proof text
)
returns table(
  approved boolean,
  error_code text,
  sale_id uuid,
  receipt_number text,
  total_won bigint,
  balance_before_won bigint,
  balance_after_won bigint,
  debt_after_won bigint,
  cogs_won bigint,
  created_at timestamptz
)
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_session private.staff_sessions;
  v_intent private.payment_intents;
  v_credential private.student_credentials;
  v_wallet private.wallets;
  v_settings private.system_settings;
  v_sale private.sales;
  v_item record;
  v_lot private.inventory_lots;
  v_sale_item_id uuid;
  v_needed integer;
  v_take integer;
  v_line_cogs bigint;
  v_all_cogs bigint := 0;
  v_cost bigint;
  v_projected bigint;
  v_ledger_id uuid;
  v_receipt text;
  v_now timestamptz := now();
begin
  v_session := private.assert_session(p_session_id, 'pos.checkout');
  select * into v_intent from private.payment_intents where id = p_intent_id for update;
  if not found or v_intent.staff_session_id <> v_session.id then raise exception 'NOT_FOUND'; end if;
  if v_intent.expires_at <= v_now then
    update private.payment_intents set state = 'expired', updated_at = v_now where id = v_intent.id;
    return query select false, 'SESSION_EXPIRED', null::uuid, null::text, v_intent.total_won,
      null::bigint, null::bigint, null::bigint, null::bigint, v_now;
    return;
  end if;
  if v_intent.state = 'completed' and v_intent.completed_sale_id is not null then
    return query
    select true, null::text, s.id, s.receipt_number, s.total_won,
      wl.balance_before_won, wl.balance_after_won, greatest(0::bigint, -wl.balance_after_won),
      s.cost_of_goods_sold_won, s.created_at
    from private.sales s join private.wallet_ledger wl on wl.id = s.wallet_ledger_id
    where s.id = v_intent.completed_sale_id;
    return;
  end if;
  if v_intent.state <> 'awaiting_pin' or v_intent.student_id is null then raise exception 'CONFLICT'; end if;

  select * into v_credential from private.student_credentials where student_id = v_intent.student_id for update;
  if not found then raise exception 'NOT_FOUND'; end if;
  if v_credential.locked_until is not null and v_credential.locked_until > v_now then
    return query select false, 'RATE_LIMITED', null::uuid, null::text, v_intent.total_won,
      null::bigint, null::bigint, null::bigint, null::bigint, v_now;
    return;
  end if;

  if extensions.crypt(p_student_pin_proof, v_credential.pin_hash) <> v_credential.pin_hash then
    update private.student_credentials
    set failed_attempts = failed_attempts + 1,
        locked_until = case when failed_attempts + 1 >= 3 then v_now + interval '5 minutes' else null end
    where student_id = v_intent.student_id;
    update private.payment_intents
    set pin_attempts = least(3, pin_attempts + 1),
        state = case when pin_attempts + 1 >= 3 then 'cancelled'::private.intent_state else state end,
        updated_at = v_now
    where id = v_intent.id;
    return query select false, 'INVALID_PIN', null::uuid, null::text, v_intent.total_won,
      null::bigint, null::bigint, null::bigint, null::bigint, v_now;
    return;
  end if;
  update private.student_credentials set failed_attempts = 0, locked_until = null where student_id = v_intent.student_id;

  select * into v_wallet from private.wallets where student_id = v_intent.student_id for update;
  select * into v_settings from private.system_settings where singleton;
  v_projected := v_wallet.balance_won - v_intent.total_won;
  if v_projected < v_settings.negative_wallet_limit_won then
    update private.payment_intents set state = 'cancelled', updated_at = v_now where id = v_intent.id;
    return query select false, 'WALLET_LIMIT', null::uuid, null::text, v_intent.total_won,
      v_wallet.balance_won, v_projected, greatest(0::bigint, -v_projected), null::bigint, v_now;
    return;
  end if;

  v_receipt := 'SALE-' || to_char(v_now, 'YYYYMMDD') || '-' || lpad(nextval('private.sale_receipt_sequence')::text, 6, '0');
  insert into private.sales(
    receipt_number, student_id, cashier_user_id, staff_session_id, total_won, payment_intent_id
  ) values (
    v_receipt, v_intent.student_id, v_session.auth_user_id, v_session.id, v_intent.total_won, v_intent.id
  ) returning * into v_sale;

  for v_item in
    select pii.*, p.name as product_name
    from private.payment_intent_items pii
    join public.products p on p.id = pii.product_id
    where pii.intent_id = v_intent.id
    order by pii.id
  loop
    if (select coalesce(sum(quantity_remaining),0) from private.inventory_lots where product_id = v_item.product_id and quantity_remaining > 0) < v_item.quantity then
      raise exception 'INVENTORY_SHORTAGE';
    end if;

    insert into private.sale_items(
      sale_id, product_id, product_name_snapshot, quantity, unit_price_won, line_total_won
    ) values (
      v_sale.id, v_item.product_id, v_item.product_name, v_item.quantity, v_item.unit_price_won, v_item.line_total_won
    ) returning id into v_sale_item_id;

    v_needed := v_item.quantity;
    v_line_cogs := 0;
    for v_lot in
      select l.* from private.inventory_lots l
      where l.product_id = v_item.product_id and l.quantity_remaining > 0
      order by
        case when v_settings.inventory_cost_method = 'FIFO' then l.received_at end asc,
        case when v_settings.inventory_cost_method = 'FIFO' then l.id end asc,
        case when v_settings.inventory_cost_method = 'LIFO' then l.received_at end desc,
        case when v_settings.inventory_cost_method = 'LIFO' then l.id end desc
      for update
    loop
      exit when v_needed = 0;
      v_take := least(v_needed, v_lot.quantity_remaining);
      v_cost := round(v_take * v_lot.landed_unit_cost_won)::bigint;

      update private.inventory_lots set quantity_remaining = quantity_remaining - v_take where id = v_lot.id;
      insert into private.sale_cost_allocations(sale_item_id, inventory_lot_id, quantity, unit_cost_won, total_cost_won)
      values (v_sale_item_id, v_lot.id, v_take, v_lot.landed_unit_cost_won, v_cost);
      insert into private.inventory_movements(
        product_id, lot_id, movement_type, quantity_change, unit_cost_won, total_cost_won,
        reason_code, staff_user_id, staff_session_id, source_type, source_id, idempotency_key
      ) values (
        v_item.product_id, v_lot.id, 'SALE', -v_take, v_lot.landed_unit_cost_won, -v_cost,
        'STUDENT_SALE', v_session.auth_user_id, v_session.id, 'SALE_ITEM', v_sale_item_id, v_intent.idempotency_key
      );
      v_line_cogs := v_line_cogs + v_cost;
      v_needed := v_needed - v_take;
    end loop;
    if v_needed <> 0 then raise exception 'INVENTORY_SHORTAGE'; end if;
    update private.sale_items set cogs_won = v_line_cogs where id = v_sale_item_id;
    v_all_cogs := v_all_cogs + v_line_cogs;
  end loop;

  insert into private.wallet_ledger(
    reference_number, student_id, amount_won, entry_type, reason_code,
    balance_before_won, balance_after_won, staff_user_id, staff_session_id,
    source_type, source_id, idempotency_key
  ) values (
    'PAY-' || v_receipt, v_intent.student_id, -v_intent.total_won, 'PURCHASE', 'POS_SALE',
    v_wallet.balance_won, v_projected, v_session.auth_user_id, v_session.id,
    'SALE', v_sale.id, v_intent.idempotency_key
  ) returning id into v_ledger_id;

  update private.wallets set balance_won = v_projected, updated_at = v_now where student_id = v_intent.student_id;
  update private.sales set cost_of_goods_sold_won = v_all_cogs, wallet_ledger_id = v_ledger_id where id = v_sale.id;
  update private.payment_intents set state = 'completed', completed_sale_id = v_sale.id, updated_at = v_now where id = v_intent.id;

  insert into private.audit_events(event_type, actor_user_id, staff_session_id, subject_type, subject_id, reference_number, safe_payload)
  values ('SALE_COMPLETED', v_session.auth_user_id, v_session.id, 'SALE', v_sale.id,
          'AUD-' || v_receipt, jsonb_build_object('total_won', v_intent.total_won, 'cogs_won', v_all_cogs));

  return query select true, null::text, v_sale.id, v_receipt, v_intent.total_won,
    v_wallet.balance_won, v_projected, greatest(0::bigint, -v_projected), v_all_cogs, v_now;
end;
$$;
-- END 003_pos_functions.sql

-- BEGIN 004_inventory_functions.sql
create table if not exists private.stock_adjustments (
  id uuid primary key default gen_random_uuid(),
  reference_number text not null unique,
  product_id uuid not null references public.products(id) on delete restrict,
  requested_lot_id uuid references private.inventory_lots(id) on delete restrict,
  quantity_removed integer not null check (quantity_removed > 0),
  reason_code text not null check (reason_code in ('DAMAGED','EXPIRED','SUPPLIER_RETURN','STOCK_COUNT_LOSS')),
  notes text not null,
  total_cost_won bigint not null check (total_cost_won >= 0),
  adjusted_by uuid not null references public.staff_profiles(auth_user_id) on delete restrict,
  staff_session_id uuid not null references private.staff_sessions(id) on delete restrict,
  idempotency_key uuid not null unique,
  created_at timestamptz not null default now()
);
revoke all on private.stock_adjustments from public, campuspay_runtime;

create or replace function api.create_product(
  p_session_id uuid,
  p_sku text,
  p_name text,
  p_category text,
  p_selling_price_won bigint,
  p_reorder_level integer
)
returns table(reference_id uuid, reference_number text, created_at timestamptz)
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_session private.staff_sessions;
  v_product public.products;
begin
  v_session := private.assert_session(p_session_id, 'inventory.product.manage');
  if length(trim(p_sku)) < 1 or length(trim(p_name)) < 1 or length(trim(p_category)) < 1
     or p_selling_price_won < 0 or p_reorder_level < 0 then raise exception 'BAD_REQUEST'; end if;

  insert into public.products(sku, name, category, selling_price_won, reorder_level, created_by)
  values (trim(p_sku), trim(p_name), trim(p_category), p_selling_price_won, p_reorder_level, v_session.auth_user_id)
  returning * into v_product;

  insert into private.audit_events(event_type, actor_user_id, staff_session_id, subject_type, subject_id, reference_number, safe_payload)
  values ('PRODUCT_CREATED', v_session.auth_user_id, v_session.id, 'PRODUCT', v_product.id,
    'AUD-PRODUCT-' || substr(v_product.id::text, 1, 8),
    jsonb_build_object('sku', v_product.sku, 'selling_price_won', v_product.selling_price_won));

  return query select v_product.id, 'PRODUCT-' || v_product.sku, v_product.created_at;
end;
$$;

create or replace function api.change_product_price(
  p_session_id uuid,
  p_product_id uuid,
  p_new_price_won bigint,
  p_reason text
)
returns table(reference_id uuid, reference_number text, created_at timestamptz)
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_session private.staff_sessions;
  v_product public.products;
  v_history private.product_price_history;
begin
  v_session := private.assert_session(p_session_id, 'inventory.price.manage');
  if p_new_price_won < 0 or length(trim(p_reason)) < 3 then raise exception 'BAD_REQUEST'; end if;
  select * into v_product from public.products where id = p_product_id for update;
  if not found then raise exception 'NOT_FOUND'; end if;
  if v_product.selling_price_won = p_new_price_won then raise exception 'CONFLICT'; end if;

  insert into private.product_price_history(
    product_id, old_price_won, new_price_won, reason, changed_by, staff_session_id
  ) values (
    v_product.id, v_product.selling_price_won, p_new_price_won, trim(p_reason), v_session.auth_user_id, v_session.id
  ) returning * into v_history;

  update public.products set selling_price_won = p_new_price_won, updated_at = now() where id = v_product.id;
  return query select v_history.id, 'PRICE-' || substr(v_history.id::text, 1, 8), v_history.changed_at;
end;
$$;

create or replace function api.inventory_lots(p_session_id uuid)
returns table(
  lot_id uuid,
  product_id uuid,
  product_name text,
  receipt_number text,
  received_at timestamptz,
  expiration_date date,
  quantity_received integer,
  quantity_remaining integer,
  landed_unit_cost_won bigint,
  inventory_value_won bigint
)
language plpgsql
security definer
set search_path = ''
as $$
begin
  perform private.assert_session_any(p_session_id, array['inventory.read','reports.inventory']);
  return query
  select l.id, l.product_id, p.name, r.receipt_number, l.received_at, l.expiration_date,
    l.quantity_received, l.quantity_remaining,
    round(l.landed_unit_cost_won)::bigint,
    round(l.quantity_remaining * l.landed_unit_cost_won)::bigint
  from private.inventory_lots l
  join public.products p on p.id = l.product_id
  join private.stock_receipt_lines rl on rl.id = l.receipt_line_id
  join private.stock_receipts r on r.id = rl.receipt_id
  order by p.name, l.received_at, l.id;
end;
$$;

create or replace function api.receive_stock(
  p_session_id uuid,
  p_supplier_name text,
  p_supplier_invoice text,
  p_purchase_date date,
  p_shipping_won bigint,
  p_other_costs_won bigint,
  p_discount_won bigint,
  p_notes text,
  p_lines jsonb,
  p_idempotency_key uuid
)
returns table(
  receipt_id uuid,
  receipt_number text,
  total_quantity bigint,
  purchase_subtotal_won bigint,
  total_landed_cost_won bigint,
  created_at timestamptz
)
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_session private.staff_sessions;
  v_existing private.stock_receipts;
  v_receipt private.stock_receipts;
  v_line record;
  v_product public.products;
  v_line_count integer;
  v_index integer := 0;
  v_total_quantity bigint := 0;
  v_subtotal bigint := 0;
  v_base bigint;
  v_weight bigint;
  v_weight_total bigint := 0;
  v_overhead_total bigint;
  v_overhead_alloc bigint;
  v_discount_alloc bigint;
  v_overhead_assigned bigint := 0;
  v_discount_assigned bigint := 0;
  v_line_landed bigint;
  v_line_id uuid;
  v_lot_id uuid;
  v_receipt_number text;
  v_now timestamptz := now();
begin
  v_session := private.assert_session(p_session_id, 'inventory.receive');
  if p_shipping_won < 0 or p_other_costs_won < 0 or p_discount_won < 0
     or jsonb_typeof(p_lines) <> 'array' or jsonb_array_length(p_lines) < 1 or jsonb_array_length(p_lines) > 200
     or length(trim(p_supplier_name)) < 1 or length(trim(p_supplier_invoice)) < 1 then
    raise exception 'BAD_REQUEST';
  end if;

  select * into v_existing from private.stock_receipts where idempotency_key = p_idempotency_key;
  if found then
    if v_existing.staff_session_id <> v_session.id then raise exception 'CONFLICT'; end if;
    return query select v_existing.id, v_existing.receipt_number,
      (select sum(quantity)::bigint from private.stock_receipt_lines where receipt_id = v_existing.id),
      v_existing.purchase_subtotal_won, v_existing.total_landed_cost_won, v_existing.created_at;
    return;
  end if;

  v_line_count := jsonb_array_length(p_lines);
  for v_line in
    select entry, ordinality::integer as ordinal
    from jsonb_array_elements(p_lines) with ordinality as x(entry, ordinality)
  loop
    if (v_line.entry->>'quantity')::integer < 1 or (v_line.entry->>'purchaseUnitCostWon')::bigint < 0 then
      raise exception 'BAD_REQUEST';
    end if;
    select * into v_product from public.products where id = (v_line.entry->>'productId')::uuid and active;
    if not found then raise exception 'NOT_FOUND'; end if;
    v_base := (v_line.entry->>'quantity')::bigint * (v_line.entry->>'purchaseUnitCostWon')::bigint;
    v_subtotal := v_subtotal + v_base;
    v_total_quantity := v_total_quantity + (v_line.entry->>'quantity')::integer;
  end loop;
  v_weight_total := case when v_subtotal > 0 then v_subtotal else v_total_quantity end;
  v_overhead_total := p_shipping_won + p_other_costs_won;
  if p_discount_won > v_subtotal + v_overhead_total then raise exception 'BAD_REQUEST'; end if;

  v_receipt_number := 'RCV-' || to_char(v_now, 'YYYYMMDD') || '-' || lpad(nextval('private.stock_receipt_sequence')::text, 6, '0');
  insert into private.stock_receipts(
    receipt_number, supplier_name, supplier_invoice, purchase_date,
    purchase_subtotal_won, shipping_won, other_costs_won, discount_won, total_landed_cost_won,
    notes, received_by, staff_session_id, idempotency_key
  ) values (
    v_receipt_number, trim(p_supplier_name), trim(p_supplier_invoice), p_purchase_date,
    v_subtotal, p_shipping_won, p_other_costs_won, p_discount_won,
    v_subtotal + v_overhead_total - p_discount_won,
    nullif(trim(coalesce(p_notes,'')),''), v_session.auth_user_id, v_session.id, p_idempotency_key
  ) returning * into v_receipt;

  for v_line in
    select entry, ordinality::integer as ordinal
    from jsonb_array_elements(p_lines) with ordinality as x(entry, ordinality)
    order by ordinality
  loop
    v_index := v_index + 1;
    v_base := (v_line.entry->>'quantity')::bigint * (v_line.entry->>'purchaseUnitCostWon')::bigint;
    v_weight := case when v_subtotal > 0 then v_base else (v_line.entry->>'quantity')::bigint end;
    if v_index = v_line_count then
      v_overhead_alloc := v_overhead_total - v_overhead_assigned;
      v_discount_alloc := p_discount_won - v_discount_assigned;
    else
      v_overhead_alloc := floor(v_overhead_total::numeric * v_weight / v_weight_total)::bigint;
      v_discount_alloc := floor(p_discount_won::numeric * v_weight / v_weight_total)::bigint;
      v_overhead_assigned := v_overhead_assigned + v_overhead_alloc;
      v_discount_assigned := v_discount_assigned + v_discount_alloc;
    end if;
    v_line_landed := v_base + v_overhead_alloc - v_discount_alloc;
    if v_line_landed < 0 then raise exception 'BAD_REQUEST'; end if;

    insert into private.stock_receipt_lines(
      receipt_id, product_id, quantity, purchase_unit_cost_won, base_cost_won,
      allocated_overhead_won, allocated_discount_won, total_landed_cost_won,
      supplier_lot_code, expiration_date
    ) values (
      v_receipt.id, (v_line.entry->>'productId')::uuid, (v_line.entry->>'quantity')::integer,
      (v_line.entry->>'purchaseUnitCostWon')::bigint, v_base,
      v_overhead_alloc, v_discount_alloc, v_line_landed,
      nullif(trim(coalesce(v_line.entry->>'supplierLotCode','')),''),
      nullif(v_line.entry->>'expirationDate','')::date
    ) returning id into v_line_id;

    insert into private.inventory_lots(
      receipt_line_id, product_id, received_at, expiration_date,
      quantity_received, quantity_remaining, landed_unit_cost_won
    ) values (
      v_line_id, (v_line.entry->>'productId')::uuid, v_now,
      nullif(v_line.entry->>'expirationDate','')::date,
      (v_line.entry->>'quantity')::integer, (v_line.entry->>'quantity')::integer,
      v_line_landed::numeric / (v_line.entry->>'quantity')::integer
    ) returning id into v_lot_id;

    insert into private.inventory_movements(
      product_id, lot_id, movement_type, quantity_change, unit_cost_won, total_cost_won,
      reason_code, notes, staff_user_id, staff_session_id, source_type, source_id, idempotency_key
    ) values (
      (v_line.entry->>'productId')::uuid, v_lot_id, 'PURCHASE_RECEIPT',
      (v_line.entry->>'quantity')::integer,
      v_line_landed::numeric / (v_line.entry->>'quantity')::integer, v_line_landed,
      'PURCHASE_RECEIPT', p_notes, v_session.auth_user_id, v_session.id, 'STOCK_RECEIPT', v_receipt.id, p_idempotency_key
    );
  end loop;

  insert into private.audit_events(event_type, actor_user_id, staff_session_id, subject_type, subject_id, reference_number, safe_payload)
  values ('STOCK_RECEIPT_POSTED', v_session.auth_user_id, v_session.id, 'STOCK_RECEIPT', v_receipt.id,
    'AUD-' || v_receipt.receipt_number,
    jsonb_build_object('total_quantity', v_total_quantity, 'total_landed_cost_won', v_receipt.total_landed_cost_won));

  return query select v_receipt.id, v_receipt.receipt_number, v_total_quantity,
    v_receipt.purchase_subtotal_won, v_receipt.total_landed_cost_won, v_receipt.created_at;
end;
$$;

create or replace function api.remove_stock(
  p_session_id uuid,
  p_product_id uuid,
  p_lot_id uuid,
  p_quantity integer,
  p_reason_code text,
  p_notes text,
  p_idempotency_key uuid
)
returns table(reference_id uuid, reference_number text, created_at timestamptz)
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_session private.staff_sessions;
  v_existing private.stock_adjustments;
  v_adjustment private.stock_adjustments;
  v_settings private.system_settings;
  v_lot private.inventory_lots;
  v_needed integer;
  v_take integer;
  v_cost bigint;
  v_total_cost bigint := 0;
  v_reference text;
  v_now timestamptz := now();
begin
  v_session := private.assert_session(p_session_id, 'inventory.adjust');
  if p_quantity < 1 or p_reason_code not in ('DAMAGED','EXPIRED','SUPPLIER_RETURN','STOCK_COUNT_LOSS')
     or length(trim(p_notes)) < 3 then raise exception 'BAD_REQUEST'; end if;
  if not exists(select 1 from public.products where id = p_product_id) then raise exception 'NOT_FOUND'; end if;

  select * into v_existing from private.stock_adjustments where idempotency_key = p_idempotency_key;
  if found then
    if v_existing.staff_session_id <> v_session.id then raise exception 'CONFLICT'; end if;
    return query select v_existing.id, v_existing.reference_number, v_existing.created_at;
    return;
  end if;

  if (select coalesce(sum(quantity_remaining),0) from private.inventory_lots
      where product_id = p_product_id and quantity_remaining > 0 and (p_lot_id is null or id = p_lot_id)) < p_quantity then
    raise exception 'INVENTORY_SHORTAGE';
  end if;

  select * into v_settings from private.system_settings where singleton;
  v_reference := 'ADJ-' || to_char(v_now, 'YYYYMMDD') || '-' || lpad(nextval('private.adjustment_sequence')::text, 6, '0');
  insert into private.stock_adjustments(
    reference_number, product_id, requested_lot_id, quantity_removed, reason_code, notes,
    total_cost_won, adjusted_by, staff_session_id, idempotency_key
  ) values (
    v_reference, p_product_id, p_lot_id, p_quantity, p_reason_code, trim(p_notes),
    0, v_session.auth_user_id, v_session.id, p_idempotency_key
  ) returning * into v_adjustment;

  v_needed := p_quantity;
  for v_lot in
    select l.* from private.inventory_lots l
    where l.product_id = p_product_id and l.quantity_remaining > 0 and (p_lot_id is null or l.id = p_lot_id)
    order by
      case when p_lot_id is not null then 0 else 1 end,
      case when v_settings.inventory_cost_method = 'FIFO' then l.received_at end asc,
      case when v_settings.inventory_cost_method = 'FIFO' then l.id end asc,
      case when v_settings.inventory_cost_method = 'LIFO' then l.received_at end desc,
      case when v_settings.inventory_cost_method = 'LIFO' then l.id end desc
    for update
  loop
    exit when v_needed = 0;
    v_take := least(v_needed, v_lot.quantity_remaining);
    v_cost := round(v_take * v_lot.landed_unit_cost_won)::bigint;
    update private.inventory_lots set quantity_remaining = quantity_remaining - v_take where id = v_lot.id;
    insert into private.inventory_movements(
      product_id, lot_id, movement_type, quantity_change, unit_cost_won, total_cost_won,
      reason_code, notes, staff_user_id, staff_session_id, source_type, source_id, idempotency_key
    ) values (
      p_product_id, v_lot.id, p_reason_code::private.inventory_movement_type, -v_take,
      v_lot.landed_unit_cost_won, -v_cost, p_reason_code, trim(p_notes),
      v_session.auth_user_id, v_session.id, 'STOCK_ADJUSTMENT', v_adjustment.id, p_idempotency_key
    );
    v_total_cost := v_total_cost + v_cost;
    v_needed := v_needed - v_take;
  end loop;
  if v_needed <> 0 then raise exception 'INVENTORY_SHORTAGE'; end if;
  update private.stock_adjustments set total_cost_won = v_total_cost where id = v_adjustment.id;

  insert into private.audit_events(event_type, actor_user_id, staff_session_id, subject_type, subject_id, reference_number, safe_payload)
  values ('STOCK_REMOVED', v_session.auth_user_id, v_session.id, 'STOCK_ADJUSTMENT', v_adjustment.id,
    'AUD-' || v_reference, jsonb_build_object('quantity', p_quantity, 'reason_code', p_reason_code, 'cost_won', v_total_cost));

  return query select v_adjustment.id, v_reference, v_now;
end;
$$;
-- END 004_inventory_functions.sql

-- BEGIN 005_wallet_functions.sql
create or replace function api.search_student_wallets(p_session_id uuid, p_query text default '')
returns table(
  student_id uuid,
  student_code text,
  display_name text,
  balance_won bigint,
  debt_won bigint,
  card_active boolean
)
language plpgsql
security definer
set search_path = ''
as $$
begin
  perform private.assert_session(p_session_id, 'wallet.read');
  return query
  select s.id, s.student_code, s.display_name, w.balance_won,
    greatest(0::bigint, -w.balance_won),
    exists(select 1 from private.student_cards c where c.student_id = s.id and c.active)
  from private.students s
  join private.wallets w on w.student_id = s.id
  where s.active and (
    trim(coalesce(p_query,'')) = ''
    or s.student_code ilike '%' || trim(p_query) || '%'
    or s.display_name ilike '%' || trim(p_query) || '%'
  )
  order by case when w.balance_won < 0 then 0 else 1 end, s.display_name
  limit 100;
end;
$$;

create or replace function api.create_wallet_adjustment_intent(
  p_session_id uuid,
  p_direction text,
  p_denominations integer[],
  p_reason_code text,
  p_notes text,
  p_idempotency_key uuid
)
returns table(
  intent_id uuid,
  direction private.wallet_direction,
  amount_won bigint,
  state private.intent_state,
  expires_at timestamptz
)
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_session private.staff_sessions;
  v_existing private.wallet_adjustment_intents;
  v_intent private.wallet_adjustment_intents;
  v_denom integer;
  v_amount bigint := 0;
begin
  v_session := private.assert_session(p_session_id, 'wallet.adjust');
  if p_direction not in ('CREDIT','DEBIT')
     or coalesce(array_length(p_denominations,1),0) < 1
     or array_length(p_denominations,1) > 30
     or length(trim(p_notes)) < 3 then raise exception 'BAD_REQUEST'; end if;

  foreach v_denom in array p_denominations loop
    if v_denom <> all(array[1000,5000,10000,20000,50000]) then raise exception 'BAD_REQUEST'; end if;
    v_amount := v_amount + v_denom;
  end loop;
  if v_amount <= 0 then raise exception 'BAD_REQUEST'; end if;

  if p_direction = 'CREDIT' and p_reason_code <> 'FUNDS_RECEIVED' then raise exception 'BAD_REQUEST'; end if;
  if p_direction = 'DEBIT' and p_reason_code not in (
    'PURCHASE_CORRECTION','DUPLICATE_CREDIT_REVERSAL','ADMINISTRATIVE_CHARGE','OTHER_APPROVED_CORRECTION'
  ) then raise exception 'BAD_REQUEST'; end if;

  select * into v_existing from private.wallet_adjustment_intents where idempotency_key = p_idempotency_key;
  if found then
    if v_existing.staff_session_id <> v_session.id then raise exception 'CONFLICT'; end if;
    return query select v_existing.id, v_existing.direction, v_existing.amount_won, v_existing.state, v_existing.expires_at;
    return;
  end if;

  insert into private.wallet_adjustment_intents(
    idempotency_key, staff_session_id, direction, amount_won, denominations,
    reason_code, notes, state, expires_at
  ) values (
    p_idempotency_key, v_session.id, p_direction::private.wallet_direction, v_amount, p_denominations,
    p_reason_code, trim(p_notes), 'awaiting_card', now() + interval '60 seconds'
  ) returning * into v_intent;

  return query select v_intent.id, v_intent.direction, v_intent.amount_won, v_intent.state, v_intent.expires_at;
end;
$$;

create or replace function api.scan_wallet_adjustment_card(
  p_session_id uuid,
  p_intent_id uuid,
  p_card_fingerprint text
)
returns table(
  intent_id uuid,
  state private.intent_state,
  student_id uuid,
  student_display_name text,
  current_balance_won bigint,
  projected_balance_won bigint,
  projected_debt_won bigint
)
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_session private.staff_sessions;
  v_intent private.wallet_adjustment_intents;
  v_student private.students;
  v_balance bigint;
  v_projected bigint;
begin
  v_session := private.assert_session(p_session_id, 'wallet.adjust');
  select * into v_intent from private.wallet_adjustment_intents where id = p_intent_id for update;
  if not found or v_intent.staff_session_id <> v_session.id then raise exception 'NOT_FOUND'; end if;
  if v_intent.expires_at <= now() then
    update private.wallet_adjustment_intents set state = 'expired', updated_at = now() where id = v_intent.id;
    raise exception 'SESSION_EXPIRED';
  end if;
  if v_intent.state <> 'awaiting_card' then raise exception 'CONFLICT'; end if;

  select s.* into v_student
  from private.student_cards c
  join private.students s on s.id = c.student_id
  where c.card_fingerprint = p_card_fingerprint and c.active and s.active;
  if not found then raise exception 'NOT_FOUND'; end if;
  select w.balance_won into v_balance from private.wallets w where w.student_id = v_student.id;
  if not found then raise exception 'NOT_FOUND'; end if;

  v_projected := case when v_intent.direction = 'CREDIT'
    then v_balance + v_intent.amount_won else v_balance - v_intent.amount_won end;
  update private.wallet_adjustment_intents
  set student_id = v_student.id, state = 'awaiting_pin', updated_at = now()
  where id = v_intent.id;

  return query select v_intent.id, 'awaiting_pin'::private.intent_state,
    v_student.id, v_student.display_name, v_balance, v_projected, greatest(0::bigint, -v_projected);
end;
$$;

create or replace function api.confirm_wallet_adjustment(
  p_session_id uuid,
  p_intent_id uuid,
  p_student_pin_proof text
)
returns table(
  approved boolean,
  error_code text,
  ledger_id uuid,
  reference_number text,
  amount_won bigint,
  balance_before_won bigint,
  balance_after_won bigint,
  debt_after_won bigint,
  created_at timestamptz
)
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_session private.staff_sessions;
  v_intent private.wallet_adjustment_intents;
  v_credential private.student_credentials;
  v_wallet private.wallets;
  v_settings private.system_settings;
  v_projected bigint;
  v_signed_amount bigint;
  v_ledger private.wallet_ledger;
  v_reference text;
  v_now timestamptz := now();
begin
  v_session := private.assert_session(p_session_id, 'wallet.adjust');
  select * into v_intent from private.wallet_adjustment_intents where id = p_intent_id for update;
  if not found or v_intent.staff_session_id <> v_session.id then raise exception 'NOT_FOUND'; end if;
  if v_intent.expires_at <= v_now then
    update private.wallet_adjustment_intents set state = 'expired', updated_at = v_now where id = v_intent.id;
    return query select false, 'SESSION_EXPIRED', null::uuid, null::text, null::bigint,
      null::bigint, null::bigint, null::bigint, v_now;
    return;
  end if;
  if v_intent.state = 'completed' and v_intent.completed_ledger_id is not null then
    return query select true, null::text, wl.id, wl.reference_number, wl.amount_won,
      wl.balance_before_won, wl.balance_after_won, greatest(0::bigint, -wl.balance_after_won), wl.created_at
    from private.wallet_ledger wl where wl.id = v_intent.completed_ledger_id;
    return;
  end if;
  if v_intent.state <> 'awaiting_pin' or v_intent.student_id is null then raise exception 'CONFLICT'; end if;

  select * into v_credential from private.student_credentials where student_id = v_intent.student_id for update;
  if not found then raise exception 'NOT_FOUND'; end if;
  if v_credential.locked_until is not null and v_credential.locked_until > v_now then
    return query select false, 'RATE_LIMITED', null::uuid, null::text, null::bigint,
      null::bigint, null::bigint, null::bigint, v_now;
    return;
  end if;
  if extensions.crypt(p_student_pin_proof, v_credential.pin_hash) <> v_credential.pin_hash then
    update private.student_credentials
    set failed_attempts = failed_attempts + 1,
        locked_until = case when failed_attempts + 1 >= 3 then v_now + interval '5 minutes' else null end
    where student_id = v_intent.student_id;
    update private.wallet_adjustment_intents
    set pin_attempts = least(3, pin_attempts + 1),
        state = case when pin_attempts + 1 >= 3 then 'cancelled'::private.intent_state else state end,
        updated_at = v_now
    where id = v_intent.id;
    return query select false, 'INVALID_PIN', null::uuid, null::text, null::bigint,
      null::bigint, null::bigint, null::bigint, v_now;
    return;
  end if;
  update private.student_credentials set failed_attempts = 0, locked_until = null where student_id = v_intent.student_id;

  select * into v_wallet from private.wallets where student_id = v_intent.student_id for update;
  select * into v_settings from private.system_settings where singleton;
  v_signed_amount := case when v_intent.direction = 'CREDIT' then v_intent.amount_won else -v_intent.amount_won end;
  v_projected := v_wallet.balance_won + v_signed_amount;
  if v_projected < v_settings.negative_wallet_limit_won then
    update private.wallet_adjustment_intents set state = 'cancelled', updated_at = v_now where id = v_intent.id;
    return query select false, 'WALLET_LIMIT', null::uuid, null::text, v_signed_amount,
      v_wallet.balance_won, v_projected, greatest(0::bigint, -v_projected), v_now;
    return;
  end if;

  v_reference := 'WAL-' || to_char(v_now, 'YYYYMMDD') || '-' || lpad(nextval('private.adjustment_sequence')::text, 6, '0');
  insert into private.wallet_ledger(
    reference_number, student_id, amount_won, entry_type, reason_code,
    balance_before_won, balance_after_won, staff_user_id, staff_session_id,
    source_type, source_id, idempotency_key, notes
  ) values (
    v_reference, v_intent.student_id, v_signed_amount,
    case when v_signed_amount > 0 then 'FUNDS_ADDED' else 'CONTROLLED_DEDUCTION' end,
    v_intent.reason_code, v_wallet.balance_won, v_projected,
    v_session.auth_user_id, v_session.id, 'WALLET_ADJUSTMENT', v_intent.id, v_intent.idempotency_key, v_intent.notes
  ) returning * into v_ledger;

  update private.wallets set balance_won = v_projected, updated_at = v_now where student_id = v_intent.student_id;
  update private.wallet_adjustment_intents set state = 'completed', completed_ledger_id = v_ledger.id, updated_at = v_now where id = v_intent.id;

  insert into private.audit_events(event_type, actor_user_id, staff_session_id, subject_type, subject_id, reference_number, safe_payload)
  values ('WALLET_ADJUSTMENT_POSTED', v_session.auth_user_id, v_session.id, 'WALLET_LEDGER', v_ledger.id,
    'AUD-' || v_reference, jsonb_build_object('amount_won', v_signed_amount, 'reason_code', v_intent.reason_code));

  return query select true, null::text, v_ledger.id, v_reference, v_signed_amount,
    v_wallet.balance_won, v_projected, greatest(0::bigint, -v_projected), v_now;
end;
$$;
-- END 005_wallet_functions.sql

-- BEGIN 006_security_functions.sql
create or replace function api.create_elevation(
  p_session_id uuid,
  p_approver_employee_code text,
  p_approver_pin_proof text,
  p_purpose text,
  p_student_id uuid,
  p_token_hash text
)
returns table(expires_at timestamptz)
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_session private.staff_sessions;
  v_approver public.staff_profiles;
  v_expiry timestamptz := now() + interval '60 seconds';
begin
  v_session := private.assert_session(p_session_id, 'security.credentials.request');
  if p_purpose not in ('RESET_STUDENT_PIN','RESET_STUDENT_CARD') or length(p_token_hash) <> 64 then raise exception 'BAD_REQUEST'; end if;
  if not exists(select 1 from private.students where id = p_student_id and active) then raise exception 'NOT_FOUND'; end if;

  v_approver := private.verify_staff_pin(p_approver_employee_code, p_approver_pin_proof, 'super_admin');

  insert into private.elevation_tokens(
    token_hash, requested_by, approved_by, staff_session_id, purpose, student_id, expires_at
  ) values (
    p_token_hash, v_session.auth_user_id, v_approver.auth_user_id, v_session.id, p_purpose, p_student_id, v_expiry
  );

  insert into private.audit_events(event_type, actor_user_id, approver_user_id, staff_session_id,
    subject_type, subject_id, reference_number, safe_payload)
  values ('CREDENTIAL_RESET_AUTHORIZED', v_session.auth_user_id, v_approver.auth_user_id, v_session.id,
    'STUDENT', p_student_id, 'AUD-ELEV-' || substr(gen_random_uuid()::text,1,8), jsonb_build_object('purpose', p_purpose));

  return query select v_expiry;
end;
$$;

create or replace function private.consume_elevation(
  p_session private.staff_sessions,
  p_token_hash text,
  p_purpose text,
  p_student_id uuid
)
returns private.elevation_tokens
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_token private.elevation_tokens;
begin
  select * into v_token from private.elevation_tokens
  where token_hash = p_token_hash
    and staff_session_id = p_session.id
    and requested_by = p_session.auth_user_id
    and purpose = p_purpose
    and student_id = p_student_id
    and consumed_at is null
    and expires_at > now()
  for update;
  if not found then raise exception 'FORBIDDEN'; end if;
  update private.elevation_tokens set consumed_at = now() where id = v_token.id returning * into v_token;
  return v_token;
end;
$$;

create or replace function api.reset_student_pin(
  p_session_id uuid,
  p_student_id uuid,
  p_elevation_token_hash text,
  p_new_pin_proof text
)
returns table(audit_reference text, completed_at timestamptz)
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_session private.staff_sessions;
  v_elevation private.elevation_tokens;
  v_reference text := 'AUD-PIN-' || substr(gen_random_uuid()::text,1,8);
  v_now timestamptz := now();
begin
  v_session := private.assert_session(p_session_id, 'security.credentials.request');
  if p_new_pin_proof !~ '^[a-f0-9]{64}$' then raise exception 'BAD_REQUEST'; end if;
  v_elevation := private.consume_elevation(v_session, p_elevation_token_hash, 'RESET_STUDENT_PIN', p_student_id);

  update private.student_credentials
  set pin_hash = extensions.crypt(p_new_pin_proof, extensions.gen_salt('bf', 12)),
      failed_attempts = 0, locked_until = null, pin_updated_at = v_now
  where student_id = p_student_id;
  if not found then raise exception 'NOT_FOUND'; end if;

  insert into private.audit_events(event_type, actor_user_id, approver_user_id, staff_session_id,
    subject_type, subject_id, reference_number, safe_payload)
  values ('STUDENT_PIN_RESET', v_session.auth_user_id, v_elevation.approved_by, v_session.id,
    'STUDENT', p_student_id, v_reference, '{}'::jsonb);
  return query select v_reference, v_now;
end;
$$;

create or replace function api.reset_student_card(
  p_session_id uuid,
  p_student_id uuid,
  p_elevation_token_hash text,
  p_new_card_fingerprint text
)
returns table(audit_reference text, completed_at timestamptz)
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_session private.staff_sessions;
  v_elevation private.elevation_tokens;
  v_reference text := 'AUD-CARD-' || substr(gen_random_uuid()::text,1,8);
  v_now timestamptz := now();
begin
  v_session := private.assert_session(p_session_id, 'security.credentials.request');
  if length(p_new_card_fingerprint) <> 64 then raise exception 'BAD_REQUEST'; end if;
  v_elevation := private.consume_elevation(v_session, p_elevation_token_hash, 'RESET_STUDENT_CARD', p_student_id);

  update private.student_cards set active = false, deactivated_at = v_now
  where student_id = p_student_id and active;
  insert into private.student_cards(student_id, card_fingerprint, active, issued_by)
  values (p_student_id, p_new_card_fingerprint, true, v_session.auth_user_id);

  insert into private.audit_events(event_type, actor_user_id, approver_user_id, staff_session_id,
    subject_type, subject_id, reference_number, safe_payload)
  values ('STUDENT_CARD_RESET', v_session.auth_user_id, v_elevation.approved_by, v_session.id,
    'STUDENT', p_student_id, v_reference, '{}'::jsonb);
  return query select v_reference, v_now;
end;
$$;
-- END 006_security_functions.sql

-- BEGIN 007_reports_and_grants.sql
create or replace function api.report_sales(
  p_session_id uuid,
  p_from date default null,
  p_to date default null
)
returns table(
  receipt_number text,
  created_at timestamptz,
  cashier_name text,
  revenue_won bigint,
  cogs_won bigint,
  gross_profit_won bigint,
  student_code text,
  balance_after_won bigint
)
language plpgsql
security definer
set search_path = ''
as $$
begin
  perform private.assert_session(p_session_id, 'reports.sales');
  return query
  select s.receipt_number, s.created_at, sp.display_name,
    s.total_won, s.cost_of_goods_sold_won, s.total_won - s.cost_of_goods_sold_won,
    st.student_code, wl.balance_after_won
  from private.sales s
  join public.staff_profiles sp on sp.auth_user_id = s.cashier_user_id
  join private.students st on st.id = s.student_id
  join private.wallet_ledger wl on wl.id = s.wallet_ledger_id
  where (p_from is null or s.created_at >= p_from::timestamptz)
    and (p_to is null or s.created_at < (p_to + 1)::timestamptz)
  order by s.created_at desc
  limit 5000;
end;
$$;

create or replace function api.report_inventory(p_session_id uuid)
returns table(
  product_name text,
  sku text,
  quantity_on_hand bigint,
  inventory_value_won bigint,
  reorder_level integer,
  low_stock boolean
)
language plpgsql
security definer
set search_path = ''
as $$
begin
  perform private.assert_session(p_session_id, 'reports.inventory');
  return query
  select p.name, p.sku,
    coalesce(sum(l.quantity_remaining),0)::bigint,
    coalesce(round(sum(l.quantity_remaining * l.landed_unit_cost_won)),0)::bigint,
    p.reorder_level,
    coalesce(sum(l.quantity_remaining),0) <= p.reorder_level
  from public.products p
  left join private.inventory_lots l on l.product_id = p.id
  left join private.stock_receipt_lines rl on rl.id = l.receipt_line_id
  left join private.stock_receipts r on r.id = rl.receipt_id
  where p.active
  group by p.id, p.name, p.sku
  order by p.name;
end;
$$;

create or replace function api.report_wallets(p_session_id uuid)
returns table(
  student_code text,
  display_name text,
  balance_won bigint,
  debt_won bigint,
  last_changed_at timestamptz
)
language plpgsql
security definer
set search_path = ''
as $$
begin
  perform private.assert_session(p_session_id, 'reports.wallets');
  return query
  select s.student_code, s.display_name, w.balance_won,
    greatest(0::bigint, -w.balance_won), max(wl.created_at)
  from private.students s
  join private.wallets w on w.student_id = s.id
  left join private.wallet_ledger wl on wl.student_id = s.id
  where s.active
  group by s.id, s.student_code, s.display_name, w.balance_won
  order by case when w.balance_won < 0 then 0 else 1 end, s.display_name;
end;
$$;

-- Functions are not executable by default merely because the schema is exposed.
revoke all on all functions in schema api from public;
grant execute on all functions in schema api to campuspay_runtime;

alter default privileges in schema api revoke execute on functions from public;
alter default privileges in schema api grant execute on functions to campuspay_runtime;
-- END 007_reports_and_grants.sql

-- BEGIN 008_coupon_functions.sql
-- Coupon module and coupon-aware checkout.
-- Raw coupon codes are never stored; only server-created HMAC fingerprints and masks reach Postgres.

create type private.coupon_discount_type as enum ('FIXED_WON', 'PERCENTAGE');

create table private.coupons (
  id uuid primary key default gen_random_uuid(),
  idempotency_key uuid not null unique,
  name text not null check (length(name) between 2 and 120),
  code_fingerprint text not null unique check (length(code_fingerprint) = 64),
  code_masked text not null check (length(code_masked) between 4 and 20),
  discount_type private.coupon_discount_type not null,
  fixed_amount_won bigint,
  percentage_bps integer,
  minimum_subtotal_won bigint not null default 0 check (minimum_subtotal_won >= 0),
  max_discount_won bigint check (max_discount_won is null or max_discount_won > 0),
  total_redemption_limit integer check (total_redemption_limit is null or total_redemption_limit > 0),
  per_student_limit integer check (per_student_limit is null or per_student_limit > 0),
  starts_at timestamptz not null,
  ends_at timestamptz,
  active boolean not null default true,
  created_by uuid not null references public.staff_profiles(auth_user_id) on delete restrict,
  staff_session_id uuid not null references private.staff_sessions(id) on delete restrict,
  deactivated_by uuid references public.staff_profiles(auth_user_id) on delete restrict,
  deactivated_session_id uuid references private.staff_sessions(id) on delete restrict,
  deactivation_reason text,
  deactivated_at timestamptz,
  created_at timestamptz not null default now(),
  constraint coupon_terms_match_type check (
    (discount_type = 'FIXED_WON' and fixed_amount_won > 0 and percentage_bps is null)
    or
    (discount_type = 'PERCENTAGE' and percentage_bps between 1 and 10000 and fixed_amount_won is null)
  ),
  constraint coupon_time_window_valid check (ends_at is null or ends_at > starts_at)
);
create index coupons_active_window_idx on private.coupons(active, starts_at, ends_at);

create table private.coupon_redemptions (
  id uuid primary key default gen_random_uuid(),
  coupon_id uuid not null references private.coupons(id) on delete restrict,
  sale_id uuid not null unique references private.sales(id) on delete restrict,
  student_id uuid not null references private.students(id) on delete restrict,
  subtotal_won bigint not null check (subtotal_won > 0),
  discount_won bigint not null check (discount_won > 0),
  total_won bigint not null check (total_won >= 0),
  redeemed_by uuid not null references public.staff_profiles(auth_user_id) on delete restrict,
  staff_session_id uuid not null references private.staff_sessions(id) on delete restrict,
  created_at timestamptz not null default now(),
  constraint coupon_redemption_math check (subtotal_won = discount_won + total_won)
);
create index coupon_redemptions_coupon_created_idx on private.coupon_redemptions(coupon_id, created_at desc);
create index coupon_redemptions_student_coupon_idx on private.coupon_redemptions(student_id, coupon_id);

alter table private.payment_intents add column subtotal_won bigint;
update private.payment_intents set subtotal_won = total_won where subtotal_won is null;
alter table private.payment_intents alter column subtotal_won set not null;
alter table private.payment_intents add constraint payment_intents_subtotal_positive check (subtotal_won > 0);
alter table private.payment_intents add column discount_won bigint not null default 0 check (discount_won >= 0);
alter table private.payment_intents add column coupon_id uuid references private.coupons(id) on delete restrict;
alter table private.payment_intents add column coupon_name_snapshot text;
alter table private.payment_intents add column coupon_code_masked text;
alter table private.payment_intents drop constraint payment_intents_total_won_check;
alter table private.payment_intents add constraint payment_intents_total_nonnegative check (total_won >= 0);
alter table private.payment_intents add constraint payment_intents_discount_math check (subtotal_won = discount_won + total_won);

alter table private.sales add column subtotal_won bigint;
update private.sales set subtotal_won = total_won where subtotal_won is null;
alter table private.sales alter column subtotal_won set not null;
alter table private.sales add constraint sales_subtotal_positive check (subtotal_won > 0);
alter table private.sales add column discount_won bigint not null default 0 check (discount_won >= 0);
alter table private.sales add column coupon_id uuid references private.coupons(id) on delete restrict;
alter table private.sales add column coupon_name_snapshot text;
alter table private.sales add column coupon_code_masked text;
alter table private.sales add column balance_before_won bigint;
alter table private.sales add column balance_after_won bigint;
update private.sales s
set balance_before_won = coalesce(
      (select wl.balance_before_won from private.wallet_ledger wl where wl.id = s.wallet_ledger_id),
      (select w.balance_won from private.wallets w where w.student_id = s.student_id),
      0
    ),
    balance_after_won = coalesce(
      (select wl.balance_after_won from private.wallet_ledger wl where wl.id = s.wallet_ledger_id),
      (select w.balance_won from private.wallets w where w.student_id = s.student_id),
      0
    )
where s.balance_before_won is null or s.balance_after_won is null;
update private.sales set balance_before_won = 0 where balance_before_won is null;
update private.sales set balance_after_won = 0 where balance_after_won is null;
alter table private.sales alter column balance_before_won set not null;
alter table private.sales alter column balance_after_won set not null;
alter table private.sales drop constraint sales_total_won_check;
alter table private.sales add constraint sales_total_nonnegative check (total_won >= 0);
alter table private.sales add constraint sales_discount_math check (subtotal_won = discount_won + total_won);

revoke all on private.coupons, private.coupon_redemptions from public, campuspay_runtime;

create or replace function private.price_cart(p_items jsonb, p_check_stock boolean default true)
returns table(
  product_id uuid,
  product_name text,
  quantity integer,
  unit_price_won bigint,
  line_total_won bigint
)
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_item record;
  v_product public.products;
  v_stock bigint;
begin
  if jsonb_typeof(p_items) <> 'array'
     or jsonb_array_length(p_items) = 0
     or jsonb_array_length(p_items) > 50 then
    raise exception 'BAD_REQUEST';
  end if;

  for v_item in
    select
      (entry->>'productId')::uuid as product_id,
      sum((entry->>'quantity')::integer)::integer as quantity
    from jsonb_array_elements(p_items) entry
    group by (entry->>'productId')::uuid
  loop
    if v_item.quantity < 1 or v_item.quantity > 99 then raise exception 'BAD_REQUEST'; end if;

    select * into v_product
    from public.products
    where id = v_item.product_id and active;
    if not found then raise exception 'NOT_FOUND'; end if;

    if p_check_stock then
      select coalesce(sum(l.quantity_remaining), 0) into v_stock
      from private.inventory_lots l
      where l.product_id = v_product.id and l.quantity_remaining > 0;
      if v_stock < v_item.quantity then raise exception 'INVENTORY_SHORTAGE'; end if;
    end if;

    product_id := v_product.id;
    product_name := v_product.name;
    quantity := v_item.quantity;
    unit_price_won := v_product.selling_price_won;
    line_total_won := v_product.selling_price_won * v_item.quantity;
    return next;
  end loop;
end;
$$;

create or replace function private.calculate_coupon_discount(
  p_discount_type private.coupon_discount_type,
  p_fixed_amount_won bigint,
  p_percentage_bps integer,
  p_max_discount_won bigint,
  p_subtotal_won bigint
)
returns bigint
language plpgsql
immutable
set search_path = ''
as $$
declare
  v_discount bigint;
begin
  if p_subtotal_won <= 0 then return 0; end if;

  if p_discount_type = 'FIXED_WON' then
    v_discount := p_fixed_amount_won;
  else
    v_discount := greatest(1::bigint, floor((p_subtotal_won::numeric * p_percentage_bps::numeric) / 10000)::bigint);
  end if;

  if p_max_discount_won is not null then
    v_discount := least(v_discount, p_max_discount_won);
  end if;

  return least(p_subtotal_won, greatest(0::bigint, v_discount));
end;
$$;

create or replace function private.assert_coupon_window(
  p_coupon private.coupons,
  p_subtotal_won bigint
)
returns void
language plpgsql
stable
set search_path = ''
as $$
begin
  if not p_coupon.active then raise exception 'COUPON_EXPIRED'; end if;
  if p_coupon.starts_at > now() then raise exception 'COUPON_EXPIRED'; end if;
  if p_coupon.ends_at is not null and p_coupon.ends_at <= now() then raise exception 'COUPON_EXPIRED'; end if;
  if p_subtotal_won < p_coupon.minimum_subtotal_won then raise exception 'COUPON_MINIMUM'; end if;
  if p_coupon.total_redemption_limit is not null
     and (select count(*) from private.coupon_redemptions cr where cr.coupon_id = p_coupon.id) >= p_coupon.total_redemption_limit then
    raise exception 'COUPON_LIMIT';
  end if;
end;
$$;

revoke all on function private.price_cart(jsonb, boolean) from public, campuspay_runtime;
revoke all on function private.calculate_coupon_discount(private.coupon_discount_type, bigint, integer, bigint, bigint) from public, campuspay_runtime;
revoke all on function private.assert_coupon_window(private.coupons, bigint) from public, campuspay_runtime;

create or replace function api.create_coupon(
  p_session_id uuid,
  p_name text,
  p_code_fingerprint text,
  p_code_masked text,
  p_discount_type text,
  p_fixed_amount_won bigint,
  p_percentage_bps integer,
  p_minimum_subtotal_won bigint,
  p_max_discount_won bigint,
  p_total_redemption_limit integer,
  p_per_student_limit integer,
  p_starts_at timestamptz,
  p_ends_at timestamptz,
  p_idempotency_key uuid
)
returns table(
  coupon_id uuid,
  name text,
  code_masked text,
  active boolean,
  created_at timestamptz
)
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_session private.staff_sessions;
  v_coupon private.coupons;
begin
  v_session := private.assert_session(p_session_id, 'coupons.manage');

  select * into v_coupon from private.coupons where idempotency_key = p_idempotency_key;
  if found then
    if v_coupon.created_by <> v_session.auth_user_id then raise exception 'CONFLICT'; end if;
    return query select v_coupon.id, v_coupon.name, v_coupon.code_masked, v_coupon.active, v_coupon.created_at;
    return;
  end if;

  if length(p_code_fingerprint) <> 64
     or length(trim(p_name)) not between 2 and 120
     or p_discount_type not in ('FIXED_WON', 'PERCENTAGE')
     or p_minimum_subtotal_won < 0
     or (p_ends_at is not null and p_ends_at <= p_starts_at) then
    raise exception 'BAD_REQUEST';
  end if;

  if exists (select 1 from private.coupons c where c.code_fingerprint = p_code_fingerprint) then
    raise exception 'CONFLICT';
  end if;

  insert into private.coupons(
    idempotency_key, name, code_fingerprint, code_masked, discount_type,
    fixed_amount_won, percentage_bps, minimum_subtotal_won, max_discount_won,
    total_redemption_limit, per_student_limit, starts_at, ends_at,
    created_by, staff_session_id
  ) values (
    p_idempotency_key, trim(p_name), p_code_fingerprint, p_code_masked, p_discount_type::private.coupon_discount_type,
    p_fixed_amount_won, p_percentage_bps, p_minimum_subtotal_won, p_max_discount_won,
    p_total_redemption_limit, p_per_student_limit, p_starts_at, p_ends_at,
    v_session.auth_user_id, v_session.id
  ) returning * into v_coupon;

  insert into private.audit_events(
    event_type, actor_user_id, staff_session_id, subject_type, subject_id, reference_number, safe_payload
  ) values (
    'COUPON_CREATED', v_session.auth_user_id, v_session.id, 'COUPON', v_coupon.id,
    'AUD-COUPON-' || v_coupon.id::text,
    jsonb_build_object(
      'name', v_coupon.name,
      'code_masked', v_coupon.code_masked,
      'discount_type', v_coupon.discount_type,
      'fixed_amount_won', v_coupon.fixed_amount_won,
      'percentage_bps', v_coupon.percentage_bps,
      'minimum_subtotal_won', v_coupon.minimum_subtotal_won,
      'max_discount_won', v_coupon.max_discount_won,
      'total_redemption_limit', v_coupon.total_redemption_limit,
      'per_student_limit', v_coupon.per_student_limit,
      'starts_at', v_coupon.starts_at,
      'ends_at', v_coupon.ends_at
    )
  );

  return query select v_coupon.id, v_coupon.name, v_coupon.code_masked, v_coupon.active, v_coupon.created_at;
exception
  when unique_violation then raise exception 'CONFLICT';
end;
$$;

create or replace function api.list_coupons(p_session_id uuid)
returns table(
  coupon_id uuid,
  name text,
  code_masked text,
  discount_type text,
  fixed_amount_won bigint,
  percentage_bps integer,
  minimum_subtotal_won bigint,
  max_discount_won bigint,
  total_redemption_limit integer,
  per_student_limit integer,
  redemption_count bigint,
  discount_given_won bigint,
  starts_at timestamptz,
  ends_at timestamptz,
  active boolean,
  created_at timestamptz
)
language plpgsql
security definer
set search_path = ''
as $$
begin
  perform private.assert_session(p_session_id, 'coupons.manage');
  return query
  select
    c.id, c.name, c.code_masked, c.discount_type::text, c.fixed_amount_won, c.percentage_bps,
    c.minimum_subtotal_won, c.max_discount_won, c.total_redemption_limit, c.per_student_limit,
    count(cr.id)::bigint, coalesce(sum(cr.discount_won), 0)::bigint,
    c.starts_at, c.ends_at, c.active, c.created_at
  from private.coupons c
  left join private.coupon_redemptions cr on cr.coupon_id = c.id
  group by c.id
  order by c.created_at desc;
end;
$$;

create or replace function api.deactivate_coupon(
  p_session_id uuid,
  p_coupon_id uuid,
  p_reason text
)
returns table(
  coupon_id uuid,
  active boolean,
  deactivated_at timestamptz
)
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_session private.staff_sessions;
  v_coupon private.coupons;
begin
  v_session := private.assert_session(p_session_id, 'coupons.manage');
  if length(trim(p_reason)) < 3 then raise exception 'BAD_REQUEST'; end if;

  select * into v_coupon from private.coupons where id = p_coupon_id for update;
  if not found then raise exception 'NOT_FOUND'; end if;

  if v_coupon.active then
    update private.coupons
    set active = false,
        deactivated_by = v_session.auth_user_id,
        deactivated_session_id = v_session.id,
        deactivation_reason = trim(p_reason),
        deactivated_at = now()
    where id = v_coupon.id
    returning * into v_coupon;

    insert into private.audit_events(
      event_type, actor_user_id, staff_session_id, subject_type, subject_id, reference_number, safe_payload
    ) values (
      'COUPON_DEACTIVATED', v_session.auth_user_id, v_session.id, 'COUPON', v_coupon.id,
      'AUD-COUPON-DEACTIVATE-' || v_coupon.id::text,
      jsonb_build_object('name', v_coupon.name, 'code_masked', v_coupon.code_masked, 'reason', trim(p_reason))
    );
  end if;

  return query select v_coupon.id, v_coupon.active, v_coupon.deactivated_at;
end;
$$;

create or replace function api.quote_coupon(
  p_session_id uuid,
  p_items jsonb,
  p_coupon_code_fingerprint text
)
returns table(
  coupon_id uuid,
  coupon_name text,
  code_masked text,
  subtotal_won bigint,
  discount_won bigint,
  total_won bigint
)
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_coupon private.coupons;
  v_subtotal bigint;
  v_discount bigint;
begin
  perform private.assert_session(p_session_id, 'coupons.redeem');
  if length(p_coupon_code_fingerprint) <> 64 then raise exception 'COUPON_INVALID'; end if;

  select coalesce(sum(pc.line_total_won), 0)::bigint into v_subtotal
  from private.price_cart(p_items, true) pc;
  if v_subtotal <= 0 then raise exception 'BAD_REQUEST'; end if;

  select * into v_coupon from private.coupons where code_fingerprint = p_coupon_code_fingerprint;
  if not found then raise exception 'COUPON_INVALID'; end if;
  perform private.assert_coupon_window(v_coupon, v_subtotal);

  v_discount := private.calculate_coupon_discount(
    v_coupon.discount_type,
    v_coupon.fixed_amount_won,
    v_coupon.percentage_bps,
    v_coupon.max_discount_won,
    v_subtotal
  );
  if v_discount <= 0 then raise exception 'COUPON_INVALID'; end if;

  return query select v_coupon.id, v_coupon.name, v_coupon.code_masked,
    v_subtotal, v_discount, v_subtotal - v_discount;
end;
$$;

-- Replace the original non-coupon payment-intent RPC with the coupon-aware signature.
drop function api.create_payment_intent(uuid, jsonb, uuid);

create or replace function api.create_payment_intent(
  p_session_id uuid,
  p_items jsonb,
  p_idempotency_key uuid,
  p_coupon_code_fingerprint text
)
returns table(
  intent_id uuid,
  state private.intent_state,
  subtotal_won bigint,
  discount_won bigint,
  total_won bigint,
  coupon_name text,
  coupon_code_masked text,
  expires_at timestamptz
)
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_session private.staff_sessions;
  v_existing private.payment_intents;
  v_intent private.payment_intents;
  v_priced record;
  v_coupon private.coupons;
  v_subtotal bigint;
  v_discount bigint := 0;
begin
  v_session := private.assert_session(p_session_id, 'pos.checkout');
  if p_coupon_code_fingerprint is not null
     and not private.role_has_permission(v_session.role_snapshot, 'coupons.redeem') then
    raise exception 'FORBIDDEN';
  end if;

  select * into v_existing from private.payment_intents where idempotency_key = p_idempotency_key;
  if found then
    if v_existing.staff_session_id <> v_session.id then raise exception 'CONFLICT'; end if;
    return query select
      v_existing.id, v_existing.state, v_existing.subtotal_won, v_existing.discount_won,
      v_existing.total_won, v_existing.coupon_name_snapshot, v_existing.coupon_code_masked,
      v_existing.expires_at;
    return;
  end if;

  select coalesce(sum(pc.line_total_won), 0)::bigint into v_subtotal
  from private.price_cart(p_items, true) pc;
  if v_subtotal <= 0 then raise exception 'BAD_REQUEST'; end if;

  if p_coupon_code_fingerprint is not null then
    if length(p_coupon_code_fingerprint) <> 64 then raise exception 'COUPON_INVALID'; end if;
    select * into v_coupon from private.coupons where code_fingerprint = p_coupon_code_fingerprint;
    if not found then raise exception 'COUPON_INVALID'; end if;
    perform private.assert_coupon_window(v_coupon, v_subtotal);
    v_discount := private.calculate_coupon_discount(
      v_coupon.discount_type,
      v_coupon.fixed_amount_won,
      v_coupon.percentage_bps,
      v_coupon.max_discount_won,
      v_subtotal
    );
    if v_discount <= 0 then raise exception 'COUPON_INVALID'; end if;
  end if;

  insert into private.payment_intents(
    idempotency_key, staff_session_id, subtotal_won, discount_won, total_won,
    coupon_id, coupon_name_snapshot, coupon_code_masked, state, expires_at
  ) values (
    p_idempotency_key, v_session.id, v_subtotal, v_discount, v_subtotal - v_discount,
    v_coupon.id, v_coupon.name, v_coupon.code_masked, 'awaiting_card', now() + interval '30 seconds'
  ) returning * into v_intent;

  for v_priced in select * from private.price_cart(p_items, true)
  loop
    insert into private.payment_intent_items(intent_id, product_id, quantity, unit_price_won, line_total_won)
    values (v_intent.id, v_priced.product_id, v_priced.quantity, v_priced.unit_price_won, v_priced.line_total_won);
  end loop;

  return query select
    v_intent.id, v_intent.state, v_intent.subtotal_won, v_intent.discount_won,
    v_intent.total_won, v_intent.coupon_name_snapshot, v_intent.coupon_code_masked,
    v_intent.expires_at;
end;
$$;

-- Replace checkout so coupon limits and redemption are committed with the sale.
drop function api.confirm_payment(uuid, uuid, text);

create or replace function api.confirm_payment(
  p_session_id uuid,
  p_intent_id uuid,
  p_student_pin_proof text
)
returns table(
  approved boolean,
  error_code text,
  sale_id uuid,
  receipt_number text,
  subtotal_won bigint,
  discount_won bigint,
  total_won bigint,
  coupon_name text,
  coupon_code_masked text,
  balance_before_won bigint,
  balance_after_won bigint,
  debt_after_won bigint,
  cogs_won bigint,
  created_at timestamptz
)
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_session private.staff_sessions;
  v_intent private.payment_intents;
  v_credential private.student_credentials;
  v_wallet private.wallets;
  v_settings private.system_settings;
  v_coupon private.coupons;
  v_sale private.sales;
  v_item record;
  v_lot private.inventory_lots;
  v_sale_item_id uuid;
  v_needed integer;
  v_take integer;
  v_line_cogs bigint;
  v_all_cogs bigint := 0;
  v_cost bigint;
  v_projected bigint;
  v_ledger_id uuid;
  v_receipt text;
  v_count bigint;
  v_now timestamptz := now();
begin
  v_session := private.assert_session(p_session_id, 'pos.checkout');
  select * into v_intent from private.payment_intents where id = p_intent_id for update;
  if not found or v_intent.staff_session_id <> v_session.id then raise exception 'NOT_FOUND'; end if;

  if v_intent.expires_at <= v_now then
    update private.payment_intents set state = 'expired', updated_at = v_now where id = v_intent.id;
    return query select false, 'SESSION_EXPIRED', null::uuid, null::text,
      v_intent.subtotal_won, v_intent.discount_won, v_intent.total_won,
      v_intent.coupon_name_snapshot, v_intent.coupon_code_masked,
      null::bigint, null::bigint, null::bigint, null::bigint, v_now;
    return;
  end if;

  if v_intent.state = 'completed' and v_intent.completed_sale_id is not null then
    return query
    select true, null::text, s.id, s.receipt_number,
      s.subtotal_won, s.discount_won, s.total_won,
      s.coupon_name_snapshot, s.coupon_code_masked,
      s.balance_before_won, s.balance_after_won, greatest(0::bigint, -s.balance_after_won),
      s.cost_of_goods_sold_won, s.created_at
    from private.sales s
    where s.id = v_intent.completed_sale_id;
    return;
  end if;

  if v_intent.state <> 'awaiting_pin' or v_intent.student_id is null then raise exception 'CONFLICT'; end if;

  select * into v_credential from private.student_credentials where student_id = v_intent.student_id for update;
  if not found then raise exception 'NOT_FOUND'; end if;
  if v_credential.locked_until is not null and v_credential.locked_until > v_now then
    return query select false, 'RATE_LIMITED', null::uuid, null::text,
      v_intent.subtotal_won, v_intent.discount_won, v_intent.total_won,
      v_intent.coupon_name_snapshot, v_intent.coupon_code_masked,
      null::bigint, null::bigint, null::bigint, null::bigint, v_now;
    return;
  end if;

  if extensions.crypt(p_student_pin_proof, v_credential.pin_hash) <> v_credential.pin_hash then
    update private.student_credentials
    set failed_attempts = failed_attempts + 1,
        locked_until = case when failed_attempts + 1 >= 3 then v_now + interval '5 minutes' else null end
    where student_id = v_intent.student_id;
    update private.payment_intents
    set pin_attempts = least(3, pin_attempts + 1),
        state = case when pin_attempts + 1 >= 3 then 'cancelled'::private.intent_state else state end,
        updated_at = v_now
    where id = v_intent.id;
    return query select false, 'INVALID_PIN', null::uuid, null::text,
      v_intent.subtotal_won, v_intent.discount_won, v_intent.total_won,
      v_intent.coupon_name_snapshot, v_intent.coupon_code_masked,
      null::bigint, null::bigint, null::bigint, null::bigint, v_now;
    return;
  end if;
  update private.student_credentials set failed_attempts = 0, locked_until = null where student_id = v_intent.student_id;

  if v_intent.coupon_id is not null then
    select * into v_coupon from private.coupons where id = v_intent.coupon_id for update;
    if not found
       or not v_coupon.active
       or v_coupon.starts_at > v_now
       or (v_coupon.ends_at is not null and v_coupon.ends_at <= v_now) then
      update private.payment_intents set state = 'cancelled', updated_at = v_now where id = v_intent.id;
      return query select false, 'COUPON_UNAVAILABLE', null::uuid, null::text,
        v_intent.subtotal_won, v_intent.discount_won, v_intent.total_won,
        v_intent.coupon_name_snapshot, v_intent.coupon_code_masked,
        null::bigint, null::bigint, null::bigint, null::bigint, v_now;
      return;
    end if;

    if v_coupon.total_redemption_limit is not null then
      select count(*) into v_count from private.coupon_redemptions where coupon_id = v_coupon.id;
      if v_count >= v_coupon.total_redemption_limit then
        update private.payment_intents set state = 'cancelled', updated_at = v_now where id = v_intent.id;
        return query select false, 'COUPON_UNAVAILABLE', null::uuid, null::text,
          v_intent.subtotal_won, v_intent.discount_won, v_intent.total_won,
          v_intent.coupon_name_snapshot, v_intent.coupon_code_masked,
          null::bigint, null::bigint, null::bigint, null::bigint, v_now;
        return;
      end if;
    end if;

    if v_coupon.per_student_limit is not null then
      select count(*) into v_count
      from private.coupon_redemptions
      where coupon_id = v_coupon.id and student_id = v_intent.student_id;
      if v_count >= v_coupon.per_student_limit then
        update private.payment_intents set state = 'cancelled', updated_at = v_now where id = v_intent.id;
        return query select false, 'COUPON_STUDENT_LIMIT', null::uuid, null::text,
          v_intent.subtotal_won, v_intent.discount_won, v_intent.total_won,
          v_intent.coupon_name_snapshot, v_intent.coupon_code_masked,
          null::bigint, null::bigint, null::bigint, null::bigint, v_now;
        return;
      end if;
    end if;
  end if;

  select * into v_wallet from private.wallets where student_id = v_intent.student_id for update;
  select * into v_settings from private.system_settings where singleton;
  v_projected := v_wallet.balance_won - v_intent.total_won;
  if v_projected < v_settings.negative_wallet_limit_won then
    update private.payment_intents set state = 'cancelled', updated_at = v_now where id = v_intent.id;
    return query select false, 'WALLET_LIMIT', null::uuid, null::text,
      v_intent.subtotal_won, v_intent.discount_won, v_intent.total_won,
      v_intent.coupon_name_snapshot, v_intent.coupon_code_masked,
      v_wallet.balance_won, v_projected, greatest(0::bigint, -v_projected), null::bigint, v_now;
    return;
  end if;

  v_receipt := 'SALE-' || to_char(v_now, 'YYYYMMDD') || '-' || lpad(nextval('private.sale_receipt_sequence')::text, 6, '0');
  insert into private.sales(
    receipt_number, student_id, cashier_user_id, staff_session_id,
    subtotal_won, discount_won, total_won, coupon_id, coupon_name_snapshot, coupon_code_masked,
    balance_before_won, balance_after_won, payment_intent_id
  ) values (
    v_receipt, v_intent.student_id, v_session.auth_user_id, v_session.id,
    v_intent.subtotal_won, v_intent.discount_won, v_intent.total_won,
    v_intent.coupon_id, v_intent.coupon_name_snapshot, v_intent.coupon_code_masked,
    v_wallet.balance_won, v_projected, v_intent.id
  ) returning * into v_sale;

  for v_item in
    select pii.*, p.name as product_name
    from private.payment_intent_items pii
    join public.products p on p.id = pii.product_id
    where pii.intent_id = v_intent.id
    order by pii.id
  loop
    if (select coalesce(sum(quantity_remaining), 0) from private.inventory_lots where product_id = v_item.product_id and quantity_remaining > 0) < v_item.quantity then
      raise exception 'INVENTORY_SHORTAGE';
    end if;

    insert into private.sale_items(
      sale_id, product_id, product_name_snapshot, quantity, unit_price_won, line_total_won
    ) values (
      v_sale.id, v_item.product_id, v_item.product_name, v_item.quantity, v_item.unit_price_won, v_item.line_total_won
    ) returning id into v_sale_item_id;

    v_needed := v_item.quantity;
    v_line_cogs := 0;
    for v_lot in
      select l.* from private.inventory_lots l
      where l.product_id = v_item.product_id and l.quantity_remaining > 0
      order by
        case when v_settings.inventory_cost_method = 'FIFO' then l.received_at end asc,
        case when v_settings.inventory_cost_method = 'FIFO' then l.id end asc,
        case when v_settings.inventory_cost_method = 'LIFO' then l.received_at end desc,
        case when v_settings.inventory_cost_method = 'LIFO' then l.id end desc
      for update
    loop
      exit when v_needed = 0;
      v_take := least(v_needed, v_lot.quantity_remaining);
      v_cost := round(v_take * v_lot.landed_unit_cost_won)::bigint;

      update private.inventory_lots set quantity_remaining = quantity_remaining - v_take where id = v_lot.id;
      insert into private.sale_cost_allocations(sale_item_id, inventory_lot_id, quantity, unit_cost_won, total_cost_won)
      values (v_sale_item_id, v_lot.id, v_take, v_lot.landed_unit_cost_won, v_cost);
      insert into private.inventory_movements(
        product_id, lot_id, movement_type, quantity_change, unit_cost_won, total_cost_won,
        reason_code, staff_user_id, staff_session_id, source_type, source_id, idempotency_key
      ) values (
        v_item.product_id, v_lot.id, 'SALE', -v_take, v_lot.landed_unit_cost_won, -v_cost,
        'STUDENT_SALE', v_session.auth_user_id, v_session.id, 'SALE_ITEM', v_sale_item_id, v_intent.idempotency_key
      );
      v_line_cogs := v_line_cogs + v_cost;
      v_needed := v_needed - v_take;
    end loop;
    if v_needed <> 0 then raise exception 'INVENTORY_SHORTAGE'; end if;
    update private.sale_items set cogs_won = v_line_cogs where id = v_sale_item_id;
    v_all_cogs := v_all_cogs + v_line_cogs;
  end loop;

  if v_intent.total_won > 0 then
    insert into private.wallet_ledger(
      reference_number, student_id, amount_won, entry_type, reason_code,
      balance_before_won, balance_after_won, staff_user_id, staff_session_id,
      source_type, source_id, idempotency_key
    ) values (
      'PAY-' || v_receipt, v_intent.student_id, -v_intent.total_won, 'PURCHASE', 'POS_SALE',
      v_wallet.balance_won, v_projected, v_session.auth_user_id, v_session.id,
      'SALE', v_sale.id, v_intent.idempotency_key
    ) returning id into v_ledger_id;

    update private.wallets set balance_won = v_projected, updated_at = v_now where student_id = v_intent.student_id;
  end if;

  update private.sales
  set cost_of_goods_sold_won = v_all_cogs, wallet_ledger_id = v_ledger_id
  where id = v_sale.id;

  if v_intent.coupon_id is not null then
    insert into private.coupon_redemptions(
      coupon_id, sale_id, student_id, subtotal_won, discount_won, total_won,
      redeemed_by, staff_session_id
    ) values (
      v_intent.coupon_id, v_sale.id, v_intent.student_id,
      v_intent.subtotal_won, v_intent.discount_won, v_intent.total_won,
      v_session.auth_user_id, v_session.id
    );
  end if;

  update private.payment_intents
  set state = 'completed', completed_sale_id = v_sale.id, updated_at = v_now
  where id = v_intent.id;

  insert into private.audit_events(
    event_type, actor_user_id, staff_session_id, subject_type, subject_id, reference_number, safe_payload
  ) values (
    'SALE_COMPLETED', v_session.auth_user_id, v_session.id, 'SALE', v_sale.id,
    'AUD-' || v_receipt,
    jsonb_build_object(
      'subtotal_won', v_intent.subtotal_won,
      'discount_won', v_intent.discount_won,
      'total_won', v_intent.total_won,
      'coupon_id', v_intent.coupon_id,
      'coupon_code_masked', v_intent.coupon_code_masked,
      'cogs_won', v_all_cogs
    )
  );

  return query select true, null::text, v_sale.id, v_receipt,
    v_intent.subtotal_won, v_intent.discount_won, v_intent.total_won,
    v_intent.coupon_name_snapshot, v_intent.coupon_code_masked,
    v_wallet.balance_won, v_projected, greatest(0::bigint, -v_projected), v_all_cogs, v_now;
end;
$$;

-- Replace sales reporting so discounts and coupon attribution remain visible.
drop function api.report_sales(uuid, date, date);

create or replace function api.report_sales(
  p_session_id uuid,
  p_from date default null,
  p_to date default null
)
returns table(
  receipt_number text,
  sold_at timestamptz,
  cashier_name text,
  subtotal_won bigint,
  discount_won bigint,
  revenue_won bigint,
  cogs_won bigint,
  gross_profit_won bigint,
  coupon_name text,
  coupon_code_masked text,
  student_name text,
  balance_after_won bigint
)
language plpgsql
security definer
set search_path = ''
as $$
begin
  perform private.assert_session(p_session_id, 'reports.sales');
  return query
  select s.receipt_number, s.created_at, sp.display_name,
    s.subtotal_won, s.discount_won, s.total_won,
    s.cost_of_goods_sold_won, s.total_won - s.cost_of_goods_sold_won,
    s.coupon_name_snapshot, s.coupon_code_masked,
    st.display_name, s.balance_after_won
  from private.sales s
  join public.staff_profiles sp on sp.auth_user_id = s.cashier_user_id
  join private.students st on st.id = s.student_id
  where (p_from is null or s.created_at >= p_from::timestamptz)
    and (p_to is null or s.created_at < (p_to + 1)::timestamptz)
  order by s.created_at desc
  limit 5000;
end;
$$;

create or replace function api.report_coupons(p_session_id uuid)
returns table(
  coupon_name text,
  code_masked text,
  redemption_count bigint,
  discount_won bigint,
  net_sales_won bigint,
  last_redeemed_at timestamptz
)
language plpgsql
security definer
set search_path = ''
as $$
begin
  perform private.assert_session(p_session_id, 'reports.coupons');
  return query
  select c.name, c.code_masked, count(cr.id)::bigint,
    coalesce(sum(cr.discount_won), 0)::bigint,
    coalesce(sum(cr.total_won), 0)::bigint,
    max(cr.created_at)
  from private.coupons c
  left join private.coupon_redemptions cr on cr.coupon_id = c.id
  group by c.id
  order by c.created_at desc;
end;
$$;

revoke all on function api.create_coupon(uuid, text, text, text, text, bigint, integer, bigint, bigint, integer, integer, timestamptz, timestamptz, uuid) from public;
revoke all on function api.list_coupons(uuid) from public;
revoke all on function api.deactivate_coupon(uuid, uuid, text) from public;
revoke all on function api.quote_coupon(uuid, jsonb, text) from public;
revoke all on function api.create_payment_intent(uuid, jsonb, uuid, text) from public;
revoke all on function api.confirm_payment(uuid, uuid, text) from public;
revoke all on function api.report_sales(uuid, date, date) from public;
revoke all on function api.report_coupons(uuid) from public;

grant execute on function api.create_coupon(uuid, text, text, text, text, bigint, integer, bigint, bigint, integer, integer, timestamptz, timestamptz, uuid) to campuspay_runtime;
grant execute on function api.list_coupons(uuid) to campuspay_runtime;
grant execute on function api.deactivate_coupon(uuid, uuid, text) to campuspay_runtime;
grant execute on function api.quote_coupon(uuid, jsonb, text) to campuspay_runtime;
grant execute on function api.create_payment_intent(uuid, jsonb, uuid, text) to campuspay_runtime;
grant execute on function api.confirm_payment(uuid, uuid, text) to campuspay_runtime;
grant execute on function api.report_sales(uuid, date, date) to campuspay_runtime;
grant execute on function api.report_coupons(uuid) to campuspay_runtime;
-- END 008_coupon_functions.sql

-- BEGIN 009_runtime_hardening.sql
-- Runtime role can execute only the narrow API functions.
create table if not exists private.schema_migrations (
  version text primary key,
  applied_at timestamptz not null default now()
);

insert into private.schema_migrations(version)
values ('20260904190000_initial_campuspay_neon')
on conflict (version) do nothing;

revoke all on schema private from public, campuspay_runtime;
revoke all on all tables in schema public from public, campuspay_runtime;
revoke all on all tables in schema private from public, campuspay_runtime;
revoke all on all sequences in schema private from public, campuspay_runtime;
revoke all on all functions in schema private from public, campuspay_runtime;
revoke all on all functions in schema api from public;
grant usage on schema api to campuspay_runtime;
grant execute on all functions in schema api to campuspay_runtime;

alter default privileges in schema public revoke all on tables from public, campuspay_runtime;
alter default privileges in schema private revoke all on tables from public, campuspay_runtime;
alter default privileges in schema private revoke all on sequences from public, campuspay_runtime;
alter default privileges in schema private revoke execute on functions from public, campuspay_runtime;
alter default privileges in schema api revoke execute on functions from public;
alter default privileges in schema api grant execute on functions to campuspay_runtime;
-- END 009_runtime_hardening.sql
