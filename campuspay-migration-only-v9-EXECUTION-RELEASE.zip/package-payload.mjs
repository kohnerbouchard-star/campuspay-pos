import fs from 'node:fs';import path from 'node:path';import {sha} from './core.mjs';
try{
 const root=path.dirname(new URL(import.meta.url).pathname);const manifest=JSON.parse(fs.readFileSync(new URL('./bundle-sha256.json',import.meta.url)));
 const files={};for(const [name,hash] of Object.entries(manifest)){if(!/^[a-z0-9.-]+$/.test(name))throw 0;const bytes=fs.readFileSync(new URL('./'+name,import.meta.url));if(sha(bytes)!==hash)throw 0;files[name]=bytes.toString('base64');}
 process.stdout.write(JSON.stringify({manifest,files}));
}catch{console.error('STOP: PACKAGE_CHANGED');process.exitCode=1;}
