// Database-only authorization. No deployment/configuration qualification is claimed.
import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';
import {CONTRACT,sha,stop} from './core.mjs';
import {validateBackupProof} from './driver.mjs';
import {canonical,evidenceHash,readFile} from './evidence.mjs';
export {evidenceHash};
export const POLICY=JSON.parse(fs.readFileSync(new URL('./migration-policy.json',import.meta.url)));
export function validatePolicy(p=POLICY){
 if(p.status!=='REVIEWED_MIGRATION_ONLY_MAINTENANCE_REQUIRED'||p.candidate!==CONTRACT.candidate||p.tree!==CONTRACT.tree||p.action!=='APPLY ONLY THE FIVE CAMPUSPAY MIGRATIONS'||p.promotionIncluded!==false||p.maintenanceRequired!==true||p.deploymentConfigurationQualified!==false)stop('MIGRATION_POLICY_DISABLED_OR_MISMATCH');
 if(canonical(p.pendingMigrations)!==canonical(CONTRACT.pendingMigrations))stop('APPROVED_MIGRATIONS_MISMATCH');
 if(!Array.isArray(p.approvalReferences)||p.approvalReferences.length!==2||p.approvalReferences.some(x=>typeof x!=='string'||!x.trim()))stop('MIGRATION_APPROVAL_REFERENCE_MISSING');
 const r=p.retentionReview;
 if(r?.kind!=='HISTORICAL_VERIFIED_RESULTS_NOT_A_NEW_DOWNLOAD'||r.independentDriveDownloadHashMatched!==true||r.savedKeySeparatelyRetrievedAndRestorePassed!==true||r.driveFileId!=='1j58zZkzM2Sk3LaJxFhWeix-mWhWSuPrO'||r.driveFolderId!=='13JPQ-J6eEmzqRBrHoaqQpm4Xk80rsFI6'||r.backupTranscript!=='userSentinel_dc9d158d4e788191a75c58caa67cdd18'||r.keyRetrievalTranscript!=='userSentinel_77de3c68c15c8191800c863ab4ae708e'||r.keyRetrievalEventTime!==null||r.driveMD5!==null||r.driveTrashed!==null)stop('HISTORICAL_RECOVERY_EVIDENCE_INVALID');
}
export function validateMigrationBackup(b,p=POLICY){
 validatePolicy(p);validateBackupProof(b,p.backup.run);
 // Match every reported restoration field; preserve and compare the actual original
 // proof in the host and Linux volume rather than synthesizing a replacement file.
 for(const key of Object.keys(p.backup))if(canonical(b[key])!==canonical(p.backup[key]))stop('REVIEWED_BACKUP_RESULT_MISMATCH');
 if(b.candidate!==CONTRACT.candidate||b.stage!=='LOCAL_BACKUP_RESTORE_VERIFIED_RETENTION_PENDING'||b.sourceStillMatchesBackup!==true||b.tables!==57||b.restore?.tables!==57||b.restore.integrity!=='matched'||b.restore.runtime_direct_table_grants!==0||b.restore.public_schema_recreated!==true||!Number.isFinite(Date.parse(b.verifiedAt))||Date.parse(b.verifiedAt)>Date.now())stop('BACKUP_PROOF_INCOMPLETE');
}
export function validateReviewedMigration(e,p=POLICY){
 validateMigrationBackup(e?.backup,p);
 if(e.policySHA256!==evidenceHash(p))stop('MIGRATION_POLICY_BINDING_MISMATCH');
 if(canonical(e.retentionReview)!==canonical(p.retentionReview))stop('HISTORICAL_RECOVERY_EVIDENCE_CHANGED');
 if(e.scope!=='DATABASE_ONLY_KEEP_FULL_MAINTENANCE')stop('MIGRATION_SCOPE_MISMATCH');
 return e;
}
export function verifyRetainedCopies(original,download,b){
 const a=fs.realpathSync(original),d=fs.realpathSync(download),as=fs.statSync(a),ds=fs.statSync(d);
 if(a===d||path.dirname(a)===path.dirname(d)||(as.dev===ds.dev&&as.ino===ds.ino))stop('RETAINED_COPIES_MUST_BE_DISTINCT');
 for(const file of [original,download]){
  const bytes=readFile(file,64*1024*1024);
  if(bytes.length!==b.bytes||sha(bytes)!==b.sha256||!bytes.subarray(0,8).equals(Buffer.from('CPBKP01\n')))stop('CIPHERTEXT_COPY_MISMATCH');
 }
 // This fresh read verifies retained local bytes. It does not claim a new Drive
 // download, a Drive MD5 result, or a repeated key retrieval/restore event.
}
export function verifyInputDirectory(dir,original,download,p=POLICY){
 const backup=JSON.parse(readFile(path.join(dir,'verified-backup.json')));
 const e={backup,policySHA256:evidenceHash(p),retentionReview:p.retentionReview,scope:'DATABASE_ONLY_KEEP_FULL_MAINTENANCE'};
 validateReviewedMigration(e,p);verifyRetainedCopies(original,download,backup);return e;
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 try{const [mode,...args]=process.argv.slice(2);if(mode!=='verify-inputs'||args.length!==3)stop('EVIDENCE_MODE_OR_ARGUMENTS_INVALID');console.log(JSON.stringify(verifyInputDirectory(...args)));}
 catch(e){console.error('STOP: '+(/^[A-Z_]+$/.test(e?.message||'')?e.message:'MIGRATION_EVIDENCE_CHECK_FAILED'));process.exitCode=1;}
}
