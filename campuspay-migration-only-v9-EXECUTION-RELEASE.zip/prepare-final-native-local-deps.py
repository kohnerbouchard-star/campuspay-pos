from pathlib import Path
import subprocess,uuid,tarfile,os,json
root=Path('/workspace/campuspay-migration-only-v9');repo=Path('/workspace/campuspay-pos')
volume='campuspay-v9-deps-'+uuid.uuid4().hex[:16]
image='node@sha256:43ac6c60b8f89723f746e8a92ce91abd5017e627ce1ddfe4238355d3a30b772c'
def run(a,**kw):return subprocess.run(a,check=True,**kw)
archive=Path('/tmp')/(volume+'.tar')
with tarfile.open(archive,'w') as t:
 for name in ['package.json','package-lock.json']:t.add(repo/name,arcname=name)
 for name,version in json.loads((root/'contract.json').read_text())['criticalDependencies'].items():
  d=repo/'node_modules'/name
  assert json.loads((d/'package.json').read_text())['version']==version
  t.add(d,arcname='node_modules/'+name)
run(['docker','volume','create','--label','campuspay.purpose=cutover-dependency-rehearsal',volume],stdout=subprocess.DEVNULL)
try:
 with archive.open('rb') as f:run(['docker','run','--rm','--pull','never','--network','none','-i','--mount','type=volume,src='+volume+',dst=/work',image,'sh','-ceu','tar -xf - -C /work'],stdin=f)
 import hashlib
 (root/'final-dependency-provenance.json').write_text(json.dumps({'source':'Existing qualified checkout node_modules; no fresh npm install claimed','syntheticOnly':True,'archiveSHA256':hashlib.sha256(archive.read_bytes()).hexdigest(),'packages':json.loads((root/'contract.json').read_text())['criticalDependencies']},indent=2)+'\n')
 run(['python3',str(root/'native-rehearsal-linux.py')],env={**os.environ,'CAMPUSPAY_TOOLS_VOLUME':volume})
finally:
 label=subprocess.check_output(['docker','volume','inspect','--format','{{index .Labels "campuspay.purpose"}}',volume],text=True).strip()
 if label!='cutover-dependency-rehearsal':raise Exception('LABEL_MISMATCH')
 run(['docker','volume','rm',volume],stdout=subprocess.DEVNULL)
 archive.unlink()
