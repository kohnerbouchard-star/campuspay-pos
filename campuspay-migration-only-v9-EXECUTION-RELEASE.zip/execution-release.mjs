// A release decision is separate from the user's already recorded migration approval.
import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';import {CONTRACT,stop} from './core.mjs';
export const RELEASE=JSON.parse(fs.readFileSync(new URL('./execution-release.json',import.meta.url)));
export function validateExecutionRelease(r=RELEASE,now=Date.now()){
 if(r?.status!=='REVIEWED_FOR_EXECUTION'||r.candidate!==CONTRACT.candidate||r.tree!==CONTRACT.tree||r.scope!=='DATABASE_ONLY_KEEP_FULL_MAINTENANCE'||typeof r.reviewReference!=='string'||!r.reviewReference.trim()||!Number.isFinite(Date.parse(r.reviewedAt))||Date.parse(r.reviewedAt)>now)stop('INDEPENDENT_PACKAGE_REVIEW_NOT_COMPLETED');
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 try{validateExecutionRelease();}catch(e){console.error('STOP: INDEPENDENT_PACKAGE_REVIEW_NOT_COMPLETED');process.exitCode=1;}
}
