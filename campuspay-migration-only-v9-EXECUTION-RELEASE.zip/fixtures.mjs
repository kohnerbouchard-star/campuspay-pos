// SYNTHETIC ONLY. Contains no production secret, backup, evidence, or approval.
import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';
import {CONTRACT} from './core.mjs';import {evidenceHash,collectRetention,PROJECT,TEAM,STAGED,HOST} from './evidence.mjs';
export async function fixture(dir){
 fs.mkdirSync(dir,{recursive:true});for(const d of ['original','download','evidence'])fs.mkdirSync(path.join(dir,d));
 const run='11111111-1111-4111-8111-111111111111',file='campuspay-pre-cutover-'+run+'.cpbackup';
 const bytes=Buffer.concat([Buffer.from('CPBKP01\n'),crypto.randomBytes(64)]),sha256=crypto.createHash('sha256').update(bytes).digest('hex'),now=new Date().toISOString();
 const backup={candidate:CONTRACT.candidate,host:HOST,database:'campuspay',run,file,bytes:bytes.length,sha256,stage:'LOCAL_BACKUP_RESTORE_VERIFIED_RETENTION_PENDING',sourceStillMatchesBackup:true,restore:{integrity:'matched',runtime_direct_table_grants:0}};
 const drive={schema:'campuspay-drive-object-v1',driveFileId:'synthetic-drive-file-id',folderId:'13JPQ-J6eEmzqRBrHoaqQpm4Xk80rsFI6',ownerEmail:'kohnerbouchard@gmail.com',shared:false,ownerOnlyPermissionsVerified:true,trashed:false,name:file,bytes:bytes.length,md5Checksum:crypto.createHash('md5').update(bytes).digest('hex'),verifiedAt:now,evidenceReference:'SYNTHETIC ONLY'};
 const config={schema:'campuspay-staged-config-v1',projectId:PROJECT,teamId:TEAM,deploymentId:STAGED,candidate:CONTRACT.candidate,tree:CONTRACT.tree,evidenceKind:'IMMUTABLE_DEPLOYMENT_CONFIGURATION_REVIEW',runtimeDatabase:{host:HOST,database:'campuspay',user:'campuspay_runtime_login',sslmode:'verify-full'},ownerDatabaseURLAbsent:true,staffOrigin:'https://mica-pos.vercel.app',storeOrigin:'https://mica-store.vercel.app',secureHostOnlyCookies:true,existingSecretsPresentAndUnchanged:true,activationUnchanged:true,reviewedAt:now,evidenceReference:'SYNTHETIC ONLY'};
 const approval={schema:'campuspay-cutover-approval-v1',projectId:PROJECT,teamId:TEAM,deploymentId:STAGED,candidate:CONTRACT.candidate,tree:CONTRACT.tree,action:'APPLY ONLY THE FIVE CAMPUSPAY MIGRATIONS',backupRun:run,backupSHA256:sha256,pendingMigrations:CONTRACT.pendingMigrations.map(m=>m.version),backupRestoreReviewed:true,independentDriveDownloadReviewed:true,immutableConfigReviewed:true,exactCandidateCIReviewed:true,sameConnectionRunnerIntegrationReviewed:true,windowsWrapperReviewed:true,promotionIncluded:false,approvedAt:now,approvalReference:'SYNTHETIC ONLY'};
 const keyRetrieval={schema:'campuspay-key-retrieval-v1',backupRun:run,purpose:'ISOLATED_RESTORE',source:'APPLE_PASSWORDS',separatelyReentered:true,recordedAt:now,evidenceReference:'SYNTHETIC ONLY'};
 const original=path.join(dir,'original',file),download=path.join(dir,'download',file);
 fs.writeFileSync(original,bytes);fs.writeFileSync(download,bytes);
 const retention=await collectRetention({backup,drive,original,download,independentDownloadConfirmed:true,keyRetrieval});
 const e={backup,retention,drive,config,approval},names={backup:'verified-backup.json',retention:'retention-proof.json',drive:'drive-object.json',config:'staged-config.json',approval:'cutover-approval.json'};
 for(const [k,name] of Object.entries(names))fs.writeFileSync(path.join(dir,'evidence',name),JSON.stringify(e[k],null,2)+'\n');
 const keyRetrievalFile=path.join(dir,'evidence','key-retrieval.json');fs.writeFileSync(keyRetrievalFile,JSON.stringify(keyRetrieval,null,2)+'\n');
 const policy={status:'REVIEWED_FOR_APPROVED_FIVE_MIGRATIONS',candidate:CONTRACT.candidate,tree:CONTRACT.tree,evidenceHashes:Object.fromEntries(Object.entries(e).map(([k,v])=>[k,evidenceHash(v)]))};
 return {e,policy,original,download,keyRetrievalFile,evidence:path.join(dir,'evidence')};
}
if(process.argv[2]==='--make-fixture'){const f=await fixture(process.argv[3]);fs.writeFileSync(path.join(process.argv[3],'fixture.json'),JSON.stringify(f));}
