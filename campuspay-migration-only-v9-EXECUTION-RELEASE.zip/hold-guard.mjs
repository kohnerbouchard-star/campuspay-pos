import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
export const PROJECT='prj_wXkpTGGYjL6emMhAX6RSwxkafkME';
export const TEAM='team_PRsNkw4DHrGsUHl6ikKw2XyJ';
export const STAGED='dpl_TUjLdvRW2DTuBAyoAmqUKQSoyWzy';
export const LIVE='dpl_3brN53nacbuaDiT1JMLtYzAKGhKQ';
export const GENERATED=['campuspay-8j1gmttl6-econovaria.vercel.app','campuspay-pos-econovaria.vercel.app','campuspay-pos-git-feat-effective-access-works-536c6a-econovaria.vercel.app','campuspay-h8smqq83v-econovaria.vercel.app'];
export const PUBLIC_HOSTS=['mica-pos.vercel.app','mica-store.vercel.app'];
export const AUTHENTICATED_DENIAL=Object.freeze({candidate:STAGED,domain:GENERATED[0],ruleId:'rule_campus_pay_maintenance_9bJUPi',configVersion:3,result:'REQUEST_WAS_DENIED',existingVercelSignedInBrowser:true,bypassUsed:false,settingsChanged:false,evidenceReference:'User confirmation Sentinel_ec948eadb46c81918c0420e562244bae, relayed by parent on 2026-10-06'});
const fail=s=>{throw new Error(s);};
export function checkWaf(d){
 if(!d.active||d.active.firewallEnabled!==true||!Array.isArray(d.active.rules))fail('MAINTENANCE_NOT_PUBLISHED');
 if((d.draft?.changes||[]).length)fail('UNREVIEWED_FIREWALL_DRAFT');
 const r=d.active.rules.filter(x=>x.active===true)[0];
 if(!r||r.name!=='CampusPay maintenance'||typeof r.id!=='string')fail('MAINTENANCE_NOT_FIRST');
 const groups=r.conditionGroup;if(!Array.isArray(groups)||groups.length!==1||groups[0].conditions?.length!==1)fail('MAINTENANCE_HAS_EXCEPTIONS');
 const c=groups[0].conditions[0];if(c.type!=='path'||c.op!=='pre'||c.value!=='/'||(c.neg??false)!==false||c.key)fail('MAINTENANCE_HAS_EXCEPTIONS');
 const m=r.action?.mitigate;if(m?.action!=='deny'||(m.duration??0)!==0||m.rateLimit||m.redirect)fail('MAINTENANCE_ACTION_MISMATCH');
 if(r.id!==AUTHENTICATED_DENIAL.ruleId||d.active.version!==AUTHENTICATED_DENIAL.configVersion)fail('REVIEWED_MAINTENANCE_ID_OR_VERSION_CHANGED');
 if(d.bypassUnavailable&&d.bypassUnavailable.reason!=='plan')fail('FIREWALL_INSPECTION_INCOMPLETE');
 return {projectId:PROJECT,teamId:TEAM,maintenanceRuleId:r.id,ruleVerified:true,configVersion:d.active.version,systemBypassRead:d.bypassUnavailable?'plan-gated':'available',checkedAt:new Date().toISOString()};
}
export function checkDeployment(d){
 if(d.id!==STAGED||d.projectId!==PROJECT||d.name!=='campuspay-pos'||d.target!=='production'||d.readyState!=='READY')fail('STAGED_DEPLOYMENT_MISMATCH');
 if(d.team?.id&&d.team.id!==TEAM)fail('STAGED_TEAM_MISMATCH');
 if(d.url!==GENERATED[0])fail('STAGED_URL_MISMATCH');
 if(d.meta?.campuspaySourceCommit!=='4e55ece88cb0afcc3e85c8f0436f8d346f5c40a1'||d.meta?.campuspaySourceTree!=='25041b33225b68a95b8f54d8e59e23b0cd624e3e')fail('STAGED_SOURCE_MISMATCH');
 if(!Array.isArray(d.alias)||d.alias.some(x=>x!==GENERATED[1]))fail('UNREVIEWED_STAGED_ALIAS');
 return {deploymentId:d.id,target:d.target,readyState:d.readyState,sourceMetadataMatched:true,aliases:d.alias};
}
export function checkDomain(d,domain){if(!PUBLIC_HOSTS.includes(domain)||d.id!==LIVE||d.projectId!==PROJECT||!(d.alias||[]).includes(domain))fail('LIVE_DOMAIN_CHANGED');return {domain,deploymentId:d.id,unchanged:true};}
export function checkProject(d){
 if(d.id!==PROJECT||d.name!=='campuspay-pos'||d.accountId!==TEAM||d.targets?.production?.id!==LIVE||d.targets.production.readyState!=='READY'||d.targets.production.aliasError)fail('PROJECT_PRODUCTION_CHANGED');
 if(!Object.hasOwn(d,'lastAliasRequest')||d.lastAliasRequest!==null&&!(d.lastAliasRequest.jobStatus==='succeeded'&&d.lastAliasRequest.toDeploymentId===LIVE))fail('PROMOTION_STATE_NOT_QUIESCENT');
 if(d.rollingRelease!=null)fail('ROLLING_RELEASE_CONFIG_REQUIRES_REVIEW');
 if(d.ssoProtection?.deploymentType!=='all_except_custom_domains'||d.passwordProtection!=null||d.trustedIps!=null)fail('PROTECTION_SCOPE_CHANGED_OR_UNVERIFIED');
 return {projectId:PROJECT,productionDeploymentId:LIVE,noPendingPromotion:true,protectionScope:'all_except_custom_domains',passwordProtection:false,trustedIps:false,checkedAt:new Date().toISOString()};
}
export function checkDomains(d){
 if(!Array.isArray(d.domains)||!d.pagination||d.pagination.next!==null||d.pagination.count!==d.domains.length)fail('DOMAIN_INVENTORY_INCOMPLETE');
 const names=d.domains.map(x=>x.name).sort();
 if(new Set(names).size!==names.length||!PUBLIC_HOSTS.every(x=>names.includes(x))||names.some(x=>![...PUBLIC_HOSTS,GENERATED[1]].includes(x)))fail('UNREVIEWED_PRODUCTION_DOMAIN');
 if(d.domains.some(x=>x.projectId!==PROJECT||x.verified!==true||x.gitBranch!=null||x.customEnvironmentId!=null||x.redirect!=null))fail('PRODUCTION_DOMAIN_CONFIG_CHANGED');
 return {domains:names,complete:true,approvedDomainInventoryVerified:true};
}
export function checkRolling(d){if(!Object.hasOwn(d,'rollingRelease')||d.rollingRelease!==null)fail('ROLLING_RELEASE_NOT_ABSENT');return {noRollingRelease:true};}
export function checkActive(d){if(!Array.isArray(d.deployments)||d.deployments.length||!d.pagination||d.pagination.next!==null)fail('CONCURRENT_DEPLOYMENT_OR_INCOMPLETE_READ');return {noConcurrentDeployment:true};}
export function checkGenerated(d,domain){
 if(!GENERATED.includes(domain)||d.projectId!==PROJECT||d.name!=='campuspay-pos'||d.readyState!=='READY'||d.team?.id&&d.team.id!==TEAM)fail('GENERATED_HOST_PROJECT_MISMATCH');
 if(domain===GENERATED[0]||domain===GENERATED[1]){checkDeployment(d);if(domain===GENERATED[1]&&!d.alias.includes(domain))fail('GENERATED_ALIAS_CHANGED');}
 else if(d.target!==null||(d.url!==domain&&!(d.alias||[]).includes(domain)))fail('PREVIEW_HOST_IDENTITY_CHANGED');
 if(typeof d.id!=='string'||!d.id.startsWith('dpl_'))fail('GENERATED_DEPLOYMENT_ID_MISSING');
 return {domain,deploymentId:d.id,projectId:PROJECT,teamId:TEAM,readyState:'READY',target:d.target,identityVerified:true};
}
export function validateContext(c,now=Date.now()){
 if(c?.schema!=='campuspay-full-hold-v4'||c.projectId!==PROJECT||c.teamId!==TEAM||c.protectionScope!=='all_except_custom_domains'||c.waf?.ruleVerified!==true||c.waf.maintenanceRuleId!==AUTHENTICATED_DENIAL.ruleId||c.waf.configVersion!==3||c.candidate?.deploymentId!==STAGED||c.candidate.sourceMetadataMatched!==true||c.authenticatedDenialEvidenceReference!==AUTHENTICATED_DENIAL.evidenceReference)fail('FULL_HOLD_CONTEXT_INVALID');
 if(!Array.isArray(c.inventory)||c.inventory.length!==4||JSON.stringify(c.inventory.map(x=>x.domain).sort())!==JSON.stringify([...GENERATED].sort())||c.inventory.some(x=>x.projectId!==PROJECT||x.teamId!==TEAM||x.identityVerified!==true||x.readyState!=='READY'||typeof x.deploymentId!=='string'||!x.deploymentId.startsWith('dpl_')||((x.domain===GENERATED[0]||x.domain===GENERATED[1])&&(x.deploymentId!==STAGED||x.target!=='production'))||((x.domain===GENERATED[2]||x.domain===GENERATED[3])&&x.target!==null)))fail('GENERATED_HOST_INVENTORY_INCOMPLETE');
 if(!Array.isArray(c.live)||c.live.length!==2||JSON.stringify(c.live.map(x=>x.domain).sort())!==JSON.stringify([...PUBLIC_HOSTS].sort())||c.live.some(x=>x.deploymentId!==LIVE||x.unchanged!==true))fail('LIVE_TARGETS_UNVERIFIED');
 for(const stamp of [c.waf.checkedAt,c.projectCheckedAt])if(!Number.isFinite(Date.parse(stamp))||Date.parse(stamp)>now||now-Date.parse(stamp)>300000)fail('FULL_HOLD_CONTEXT_STALE');
}
export function makeContext(dir,phase,now=Date.now()){
 if(!['initial','before-apply','after-apply'].includes(phase))fail('HOLD_PHASE_INVALID');
 const read=n=>JSON.parse(fs.readFileSync(path.join(dir,phase+'-'+n+'.json'),'utf8'));
 const w=read('waf'),project=read('project'),candidate=read('candidate');
 if(project.projectId!==PROJECT||project.productionDeploymentId!==LIVE||project.noPendingPromotion!==true||project.protectionScope!=='all_except_custom_domains'||project.passwordProtection!==false||project.trustedIps!==false)fail('PROTECTION_SCOPE_CHANGED_OR_UNVERIFIED');
 const inventory=GENERATED.map((domain,i)=>i===0?{domain,deploymentId:candidate.deploymentId,projectId:PROJECT,teamId:TEAM,readyState:candidate.readyState,target:candidate.target,identityVerified:candidate.sourceMetadataMatched}:read(domain));
 const c={schema:'campuspay-full-hold-v4',projectId:PROJECT,teamId:TEAM,protectionScope:project.protectionScope,waf:w,candidate,inventory,live:PUBLIC_HOSTS.map(read),projectCheckedAt:project.checkedAt,authenticatedDenialEvidenceReference:AUTHENTICATED_DENIAL.evidenceReference};validateContext(c,now);return c;
}
export function checkHttp(raw,requestURL,context,now=Date.now()){
 validateContext(context,now);const requests=[...PUBLIC_HOSTS,...GENERATED].flatMap(host=>['/','/api/health'].map(route=>'https://'+host+route));
 if(!requests.includes(requestURL)||raw.length>65536)fail('HTTP_PROBE_TARGET_OR_SIZE_INVALID');
 const request=new URL(requestURL),blocks=raw.split(/\r?\n\r?\n/).filter(x=>/^HTTP\/\S+ \d{3}/.test(x));if(!blocks.length)fail('HTTP_STATUS_MISSING');
 const lines=blocks.at(-1).split(/\r?\n/),match=lines.shift().match(/^HTTP\/\S+ (\d{3})/);if(!match)fail('HTTP_STATUS_MISSING');const status=Number(match[1]),headers=new Map();
 for(const line of lines){if(!line)continue;const i=line.indexOf(':');if(i<=0||/^\s/.test(line))fail('MALFORMED_HTTP_HEADER');const name=line.slice(0,i).toLowerCase();headers.set(name,[...(headers.get(name)||[]),line.slice(i+1).trim()]);}
 const locations=headers.get('location')||[],server=headers.get('server')||[];if(server.length!==1||server[0].toLowerCase()!=='vercel')fail('UNEXPECTED_HTTP_SERVER');
 if(status===403){if(locations.length)fail('DENY_RESPONSE_HAS_LOCATION');return {requestURL,status,classification:'WAF_DENIED',rawHeadersOmitted:true};}
 if(PUBLIC_HOSTS.includes(request.hostname))fail('PUBLIC_MICA_HOST_MUST_RETURN_403');
 if(status!==302||!GENERATED.includes(request.hostname)||locations.length!==1)fail('UNEXPECTED_GENERATED_HOST_RESPONSE');
 const location=locations[0];if(/[\u0000-\u0020\u007f\\]/.test(location)||/%(?![0-9a-fA-F]{2})/.test(location))fail('MALFORMED_SSO_LOCATION');
 if(!/^https:\/\/vercel\.com\/sso-api\?[^#\r\n]*$/.test(location))fail('UNEXPECTED_SSO_LOCATION');
 let u;try{u=new URL(location);}catch{fail('MALFORMED_SSO_LOCATION');}
 if(u.origin!=='https://vercel.com'||u.pathname!=='/sso-api'||u.username||u.password||u.port||u.hash)fail('UNEXPECTED_SSO_LOCATION');
 const keys=[...u.searchParams.keys()];if(keys.some(k=>!['url','nonce'].includes(k))||u.searchParams.getAll('url').length!==1||u.searchParams.getAll('nonce').length>1||u.searchParams.get('url')!==requestURL)fail('SSO_TARGET_AMBIGUOUS_OR_MISMATCH');
 if(!headers.has('x-vercel-id'))fail('SSO_RESPONSE_NOT_IDENTIFIED');
 return {requestURL,status,classification:'VERIFIED_VERCEL_SSO_BEFORE_WAF',locationOrigin:'https://vercel.com',locationPath:'/sso-api',embeddedTargetMatchesPreciseRequest:true,queryValuesOmitted:true,rawHeadersOmitted:true};
}
export function finalize(dir,phase,now=Date.now()){
 const context=JSON.parse(fs.readFileSync(path.join(dir,phase+'-context.json'),'utf8'));validateContext(context,now);
 const read=s=>JSON.parse(fs.readFileSync(path.join(dir,phase+'-'+s+'.json'),'utf8'));
 const project=read('project'),domains=read('domains'),rolling=read('rolling'),active=read('active');
 if(domains.approvedDomainInventoryVerified!==true||rolling.noRollingRelease!==true||active.noConcurrentDeployment!==true||project.noPendingPromotion!==true)fail('HOLD_COMPONENTS_MISMATCH');
 const expected=[...PUBLIC_HOSTS,...GENERATED].flatMap(host=>['/','/api/health'].map(route=>'https://'+host+route));
 const probes=expected.map((url,i)=>{const p=JSON.parse(fs.readFileSync(path.join(dir,phase+'-probe-'+(i+1)+'.json'),'utf8'));if(p.requestURL!==url||!['WAF_DENIED','VERIFIED_VERCEL_SSO_BEFORE_WAF'].includes(p.classification)||(PUBLIC_HOSTS.includes(new URL(url).hostname)&&(p.status!==403||p.classification!=='WAF_DENIED')))fail('PROBE_SET_INCOMPLETE');return p;});
 if(phase!=='initial'){
  const first=JSON.parse(fs.readFileSync(path.join(dir,'initial-hold.json'),'utf8'));
  if(first.ruleId!==context.waf.maintenanceRuleId||first.configVersion!==context.waf.configVersion||first.protectionScope!==context.protectionScope||JSON.stringify(first.domains)!==JSON.stringify(domains.domains)||JSON.stringify(first.inventory)!==JSON.stringify(context.inventory))fail('HOLD_CONFIGURATION_CHANGED_DURING_RUN');
 }
 return {projectId:PROJECT,teamId:TEAM,candidate:'4e55ece88cb0afcc3e85c8f0436f8d346f5c40a1',deploymentId:STAGED,liveDeploymentId:LIVE,ruleName:'CampusPay maintenance',ruleId:context.waf.maintenanceRuleId,configVersion:context.waf.configVersion,firstActiveUnrestrictedDeny:true,unreviewedDraftCount:0,protectionScope:context.protectionScope,publicMicaDenied:4,generatedDenied:probes.filter(p=>!PUBLIC_HOSTS.includes(new URL(p.requestURL).hostname)&&p.classification==='WAF_DENIED').length,generatedSsoBeforeWaf:probes.filter(p=>p.classification==='VERIFIED_VERCEL_SSO_BEFORE_WAF').length,authenticatedCandidateDeniedEvidence:AUTHENTICATED_DENIAL.evidenceReference,redirectsFollowed:false,authenticationOrBypassUsed:false,approvedDomainInventoryVerified:true,noRollingRelease:true,noPendingPromotion:true,noConcurrentDeployment:true,domains:domains.domains,inventory:context.inventory,checkedAt:context.waf.checkedAt};
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 try{const mode=process.argv[2];let out;if(mode==='context')out=makeContext(process.argv[3],process.argv[4]);else if(mode==='finalize')out=finalize(process.argv[3],process.argv[4]);else if(mode==='http')out=checkHttp(fs.readFileSync(0,'utf8'),process.argv[3],JSON.parse(fs.readFileSync(process.argv[4],'utf8')));else{const d=JSON.parse(fs.readFileSync(0,'utf8'));const handlers={waf:checkWaf,deployment:checkDeployment,project:checkProject,domains:checkDomains,rolling:checkRolling,active:checkActive};out=mode==='domain'?checkDomain(d,process.argv[3]):mode==='generated'?checkGenerated(d,process.argv[3]):handlers[mode]?handlers[mode](d):fail('INVALID_MODE');}console.log(JSON.stringify(out,null,2));}
 catch(e){console.error('STOP: '+(/^[A-Z_]+$/.test(e?.message||'')?e.message:'HOLD_CHECK_FAILED'));process.exitCode=1;}
}
