import fs from 'node:fs';import assert from 'node:assert/strict';import {randomUUID} from 'node:crypto';
import pg from '/work/node_modules/pg/lib/index.js';
import {CONTRACT,inventory,beforeMigration,afterMigration,invokeQualifiedRunner,validateOwnerDefaultPrivileges} from './core.mjs';
import {reserveAttempt} from './driver.mjs';
const dbName='campuspay_cutover_'+randomUUID().replaceAll('-','');
const control=new pg.Client({connectionString:'postgresql://postgres@localhost:5432/postgres?sslmode=disable'});
const url='postgresql://campuspay_owner@localhost:5432/'+dbName+'?sslmode=disable';
let c,created=false;
try{
 await control.connect();
 await control.query("do $$ begin if not exists(select 1 from pg_roles where rolname='campuspay_owner') then create role campuspay_owner login inherit nosuperuser createdb createrole replication bypassrls; end if; end $$");
 const ownerRole=(await control.query("select rolcanlogin,rolsuper,rolcreatedb,rolcreaterole,rolreplication,rolbypassrls,rolinherit from pg_roles where rolname='campuspay_owner'")).rows[0];assert.deepEqual(ownerRole,{rolcanlogin:true,rolsuper:false,rolcreatedb:true,rolcreaterole:true,rolreplication:true,rolbypassrls:true,rolinherit:true});
 await control.query('create database "'+dbName+'" owner campuspay_owner template template0');created=true;
 c=new pg.Client({connectionString:url});await c.connect();
 const ownerIdentity=(await c.query("select current_user as role,(select datdba::regrole::text from pg_database where datname=current_database()) as database_owner")).rows[0];assert.deepEqual(ownerIdentity,{role:'campuspay_owner',database_owner:'campuspay_owner'});
 for(const x of CONTRACT.baselineMigrations){await c.query('begin');await c.query(fs.readFileSync('/work/database/migrations/'+x.version+'.sql','utf8'));await c.query('insert into private.schema_migrations(version) values($1) on conflict do nothing',[x.version]);await c.query('commit');}
 await validateOwnerDefaultPrivileges(c);
 await c.query("do $$ begin if not exists(select 1 from pg_roles where rolname='campuspay_runtime_login') then create role campuspay_runtime_login login;end if;end $$");await c.query('grant campuspay_runtime to campuspay_runtime_login');
 const proof='e'.repeat(64);
 for(const [code,role] of [['CUT-SA','super_admin'],['CUT-ST','cashier'],['CUT-MG','inventory_admin'],['CUT-AC','accountant']]){
  const id=(await c.query('insert into public.staff_profiles(employee_code,display_name,role) values($1,$1,$2) returning auth_user_id',[code,role])).rows[0].auth_user_id;
  await c.query("insert into private.staff_credentials(staff_user_id,pin_hash) values($1,extensions.crypt($2,extensions.gen_salt('bf',4)))",[id,proof]);
 }
 assert.equal((await c.query('select * from api.create_staff_session($1,$2,$3,$4)',['CUT-SA',proof,'a'.repeat(64),'b'.repeat(64)])).rows.length,1);
 assert.equal((await c.query('select * from api.create_staff_session($1,$2,$3,$4)',['CUT-ST',proof,'c'.repeat(64),'d'.repeat(64)])).rows.length,1);
 await c.query("update private.staff_sessions set revoked_at='2026-01-01T00:00:00Z' where employee_code_snapshot='CUT-ST'");
 await c.query("insert into private.audit_events(event_type,reference_number,safe_payload) values('SYNTHETIC_PRESERVATION','SYNTHETIC-OLD-AUDIT','{\"amount\":1000}')");
 const student=(await c.query("insert into private.students(student_code,display_name) values('CUT-ONLY-SYNTHETIC','Synthetic student') returning id")).rows[0].id;
 await c.query('insert into private.wallets(student_id,balance_won) values($1,12345)',[student]);
 await c.query("insert into private.funding_intents(request_key,actor_id,terminal_id,action,request_proof,wallet_delta_won,cash_delta_won,student_id,source_reference,notes,state,expires_at) select $1,auth_user_id,terminal_id,'NONCASH_CREDIT','synthetic-proof',1000,0,$2,'SYNTHETIC-REFERENCE','Synthetic preserved closed funding request','CLOSED',clock_timestamp() from private.staff_sessions where employee_code_snapshot='CUT-SA'",[randomUUID(),student]);
 const metadata={database:dbName,tables:await inventory(c)};await c.end();c=null;
 process.env.DATABASE_URL_UNPOOLED=url;process.env.EXPECTED_DATABASE_HOST='localhost';
 let lockHeldBefore=false,lockHeldAfter=false,postSnapshot;
 const held=async c=>(await c.query("select exists(select 1 from pg_locks where pid=pg_backend_pid() and locktype='advisory' and classid=0 and objid=84632291 and granted) as held")).rows[0].held;
 const attemptDir='/work/.cutover/attempt-'+randomUUID();fs.mkdirSync(attemptDir);
 const attemptRecord={candidate:CONTRACT.candidate,backupRun:'synthetic-only',applyRun:dbName};
 let attemptReservedAtFirstDDL=false;const result=await invokeQualifiedRunner({pg,root:'/work',before:async c=>{lockHeldBefore=await held(c);assert.equal(lockHeldBefore,true);return beforeMigration(c,metadata);},beforeFirstDDL:async()=>{reserveAttempt(attemptDir,attemptRecord);attemptReservedAtFirstDDL=true;},after:async(c,b)=>{lockHeldAfter=await held(c);assert.equal(lockHeldAfter,true);postSnapshot=b;return afterMigration(c,b);}});
 assert.throws(()=>reserveAttempt(attemptDir,attemptRecord),/BACKUP_ALREADY_USED_FOR_APPLY_REVIEW_REQUIRED/);
 assert.equal(result.status,'DATABASE_37_VERIFIED_PROMOTION_PENDING');assert.equal(lockHeldBefore&&lockHeldAfter,true);
 assert.equal(result.existingStaffSessionsVerifiedRevoked,2);
 assert.equal(result.previouslyActiveStaffSessionsRevoked,1);
 assert.equal(pg.Client.name,'Client');
 c=new pg.Client({connectionString:url});await c.connect();
 assert.equal((await c.query('select balance_won::text b from private.wallets where student_id=$1',[student])).rows[0].b,'12345');
 const history=(await c.query('select count(*)::int n from private.schema_migrations')).rows[0].n;assert.equal(history,37);
 assert.equal((await c.query('select count(*)::int n from private.staff_sessions where revoked_at is null')).rows[0].n,0);
 await c.query('grant select on private.wallets to pg_monitor');
 await assert.rejects(afterMigration(c,postSnapshot),/EXISTING_OBJECT_SECURITY_CHANGED/);
 await c.query('revoke select on private.wallets from pg_monitor');
 await c.query('grant execute on function private.authorize_session_access_legacy(text,text,text) to public');
 await assert.rejects(afterMigration(c,postSnapshot),/PRIVATE_AUTHENTICATION_GRANT/);
 await c.query('revoke execute on function private.authorize_session_access_legacy(text,text,text) from public');
 await c.query('alter table private.funding_intents drop constraint funding_intents_expected_student_id_fkey');
 await c.query('alter table private.funding_intents add constraint funding_intents_expected_student_id_fkey foreign key (expected_student_id) references private.students(id) on delete cascade');
 await assert.rejects(afterMigration(c,postSnapshot),/FUNDING_IDENTITY_FOREIGN_KEY/);
 await c.query('alter table private.funding_intents drop constraint funding_intents_expected_student_id_fkey');
 await c.query('alter table private.funding_intents add constraint funding_intents_expected_student_id_fkey foreign key (expected_student_id) references private.students(id) on delete restrict');
 await c.query('drop trigger immutable_access_event on private.staff_access_events');
 await c.query('create trigger immutable_access_event before insert on private.staff_access_events for each row execute function private.reject_journal_mutation()');
 await assert.rejects(afterMigration(c,postSnapshot),/ACCESS_TRIGGER_CONTRACT/);
 await c.query('drop trigger immutable_access_event on private.staff_access_events');
 await c.query('create trigger immutable_access_event before update or delete on private.staff_access_events for each row execute function private.reject_journal_mutation()');
 assert.equal((await afterMigration(c,postSnapshot)).status,'DATABASE_37_VERIFIED_PROMOTION_PENDING');
 await c.query('update private.wallets set balance_won=balance_won+1 where student_id=$1',[student]);
 await assert.rejects(afterMigration(c,postSnapshot),/FINANCIAL_OR_OPERATIONAL_DATA_CHANGED/);
 const output={syntheticOnly:true,database:dbName,databaseRole:'campuspay_owner',databaseOwner:'campuspay_owner',ownerFixtureVerified:true,ownerRoleAttributesVerified:true,ownerDefaultPrivilegesVerified:true,runnerUnmodified:true,expectedCaseCount:1,passed:1,failed:0,skipped:0,cancelled:0,lockHeldBefore,lockHeldAfter,history,result,financialDriftRejected:true,existingObjectGrantDriftRejected:true,publicHelperGrantRejected:true,cascadeFundingForeignKeyRejected:true,wrongTriggerEventsRejected:true,backupScopedAttemptReserved:true,attemptReservedAtFirstDDL,backupReuseBlocked:true,productionAccessed:false};
 fs.writeFileSync('/work/.cutover/native-results.json',JSON.stringify(output,null,2));console.log(JSON.stringify(output,null,2));
}catch(e){console.error('SYNTHETIC_ONLY_FAILURE',e.message);if(e.message==='APPLICATION_RPC_CONTRACT'){const diagnostic=new pg.Client({connectionString:url});await diagnostic.connect();console.log(JSON.stringify((await diagnostic.query("select s as signature,to_regprocedure(s)::oid as oid,coalesce(has_function_privilege('campuspay_runtime',to_regprocedure(s),'EXECUTE'),false) as executable from unnest($1::text[]) s where to_regprocedure(s) is null or not coalesce(has_function_privilege('campuspay_runtime',to_regprocedure(s),'EXECUTE'),false)",[CONTRACT.runtimeApiSignatures])).rows));await diagnostic.end();}process.exitCode=1;}
finally{if(c)await c.end();if(created)await control.query('drop database "'+dbName+'" with (force)');await control.end();}
