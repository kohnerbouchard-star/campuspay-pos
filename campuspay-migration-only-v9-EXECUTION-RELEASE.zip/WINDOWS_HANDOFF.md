# CampusPay v9 — five-migration operator release

This successor enables the existing reviewed migration-only launcher. The independently reviewed base archive is SHA256 `414833d5afab11165bbbbed035634a4bb57af2fb68d88d2c41cf4a00656313fc`. Review identity and limitations are recorded in `INDEPENDENT_BASE_REVIEW.json`. Release enablement was explicitly requested after that review; `RELEASE_STATUS.json` records the narrow delta. A separate release-delta reviewer must confirm this archive's final checksum before delivery.

Only candidate `4e55ece88cb0afcc3e85c8f0436f8d346f5c40a1`, tree `25041b33225b68a95b8f54d8e59e23b0cd624e3e`, and the original five access/funding migrations are permitted. Stock migration 050 is excluded. This package performs no promotion, merge, maintenance change, restore, or credential change.

## Before running on the same Windows work PC

1. Obtain this complete execution-release ZIP through an authorized delivery route, confirm the independently reported SHA256, and extract into a new folder. Do not combine files with the older v7/v8/v9 review packages. A local cloud workspace path alone is not delivery.
2. Use Git Bash with the existing Node/npm, Git, curl, cygpath and Linux Docker setup. Preserve checkout `C:/Users/user/campuspay-stage.p1RrSnsE/source` and volume `campuspay-tools-91ead009-8c77-49a7-9995-653bae46984e`. The launcher checks exact clean source, project identity, pinned tools and images.
3. Locate the existing original backup and its separately downloaded retained copy. Original backup directory: `C:/Users/user/campuspay-encrypted-backup.rH0ltFuP`. Archive name: `campuspay-pre-cutover-c56dfa33-ad2f-4372-9ce0-79cfac21613d.cpbackup`; bytes 687389; SHA256 `da91ab3c6e02d4bdecfbe1e0e0db23755135bb0d36c990a2bfb0455905f35b5d`. The second copy's exact path must be supplied from the PC; it is not known here. Both copies must be separate files in separate directories. Do not repeat the completed backup or overwrite its proof.
4. Keep full maintenance in force. Stop every other writer, resolve unknown financial outcomes on the original register, and close affected drawers through their normal verified workflow. Current state has not been checked from the cloud. Existing historical retention evidence is not a fresh source comparison or live provider proof.

## Local commands after authorized delivery and release-delta confirmation

Open Git Bash in the newly extracted release folder. Enter the actual paths at the prompts without surrounding quotation marks; quoted variable expansions below preserve spaces.

```bash
export CAMPUSPAY_VERCEL_CONFIG_DIR='C:/Users/user/campuspay-vercel-auth.CJua4cxw'
read -r -p 'Full path of existing original .cpbackup: ' original_backup
read -r -p 'Full path of existing independently downloaded .cpbackup: ' downloaded_backup
bash ./campuspay-migrate-only.sh --check-only "$original_backup" "$downloaded_backup"
```

Proceed only if the launcher reports `OFFLINE_EVIDENCE_AND_HOLD_PASSED_DB_UNCHECKED`. This verifies local evidence and live hold observations, not database equality. If access is denied or any check fails, stop and retain the evidence; do not bypass protection, alter credentials/settings, or remove guards.

When every operational prerequisite above is currently true, use the same Git Bash window:

```bash
bash ./campuspay-migrate-only.sh --apply "$original_backup" "$downloaded_backup"
```

The script asks for the exact phrase `APPLY ONLY THE FIVE CAMPUSPAY MIGRATIONS`, then the retained backup key and `campuspay_owner` password through hidden local prompts. Never paste secrets into chat, command arguments, or exported environment variables. Re-entering the phrase attests current prerequisites; it is not a replacement for the recorded migration authorization.

The driver authenticates the encrypted backup, verifies fixed database/owner/direct-host identity and TLS, compares current source contents to backup metadata, checks baseline history/security and drained operations, and holds the existing runner's advisory lock. A fresh maintenance proof and durable attempt marker are required immediately before DDL. Each migration is transactional, but a failure can leave an already committed prefix.

## Afterward — maintenance must remain closed

Success is `DATABASE_37_VERIFIED_PROMOTION_PENDING`. Preserve all printed host evidence and retained volume records. The staged application's configuration is still unqualified: do not reopen the old application, promote a deployment, or include stock 050. A matching qualified application release is a separate operation before reopening.

On failure, interruption, partial application, lost maintenance or missing evidence: keep maintenance closed, preserve all attempt markers and data, and inspect exact migration history before any fix-forward decision. Never delete a marker or blindly retry; no automatic restore is provided. The advisory lock protects cooperating migration runners, not arbitrary application writers, so stopped writers remain essential.

## Evidence and limits

`FINAL_QUALIFICATION.json`, `CHECKPOINT.json`, and the historical handoff describe the reviewed disabled base. Its 92 guard tests, 31 offline shell cases and 1+6 native PostgreSQL scenarios were completed before this release-record change. They were not rerun or represented as native Windows/live production proof. The original test sources include assertions about the disabled base and are historical evidence, not an all-pass enabled-release test command. `release-delta-check-results.json` verifies the real reviewed release record and rejection of eight invalid records using pinned Node with no network; no driver or database was invoked.
