import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {createRequire} from 'node:module';
import {isDeepStrictEqual} from 'node:util';
export const CONTRACT=JSON.parse(fs.readFileSync(new URL('./contract.json',import.meta.url)));
export const stop=code=>{throw new Error(code)};
export const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const eq=(a,b,code)=>{if(!isDeepStrictEqual(a,b))stop(code);};
const ordered=x=>[...x].sort();
const quote=s=>'"'+s.replaceAll('"','""')+'"';
const oldNames=CONTRACT.baselineMigrations.map(x=>x.version);
const allNames=[...oldNames,...CONTRACT.pendingMigrations.map(x=>x.version)];
const changed=new Set(['private.schema_migrations','private.staff_sessions','private.audit_events','private.funding_intents']);
const added=['private.capability_catalog','private.access_preset_defaults','private.staff_access','private.staff_access_events','private.staff_access_closures'];
const aclKey=a=>[a.grantor,a.grantee,a.privilege,a.grantable?'1':'0'].join('\0');
const normalizeAcl=a=>[...(a||[])].sort((x,y)=>aclKey(x).localeCompare(aclKey(y)));
const normalizeSecurity=s=>({
 schemas:s.schemas.map(r=>({...r,acl:normalizeAcl(r.acl)})),
 relations:s.relations.map(r=>({...r,acl:normalizeAcl(r.acl)})),
 functions:s.functions.map(r=>({...r,acl:normalizeAcl(r.acl),config:r.config??null}))
});
export function validateMigration045Definitions(definitions){
 for(const spec of CONTRACT.migration045ReplacementAnchors){
  const definition=definitions?.[spec.signature];
  if(typeof definition!=='string')stop('MIGRATION_045_FUNCTION_MISSING');
  const occurrences=definition.split(spec.anchor).length-1;
  if(occurrences!==spec.occurrences)stop('MIGRATION_045_REPLACEMENT_ANCHOR_DRIFT');
 }
}
export async function validateMigration045Anchors(c){
 const signatures=[...new Set(CONTRACT.migration045ReplacementAnchors.map(x=>x.signature))];
 const rows=(await c.query("select s.signature,case when to_regprocedure(s.signature) is null then null else pg_get_functiondef(to_regprocedure(s.signature)) end as definition from unnest($1::text[]) s(signature)",[signatures])).rows;
 const definitions=Object.fromEntries(rows.map(x=>[x.signature,x.definition]));
 if(rows.length!==signatures.length)stop('MIGRATION_045_FUNCTION_MISSING');
 validateMigration045Definitions(definitions);return definitions;
}
export function validateOwnerDefaultPrivilegeRows(rows){
 const actual=(rows||[]).map(r=>({...r,acl:normalizeAcl(r.acl)})).sort((a,b)=>(a.schema+'\0'+a.object_type).localeCompare(b.schema+'\0'+b.object_type));
 const expected=CONTRACT.ownerDefaultPrivileges.map(r=>({...r,acl:normalizeAcl(r.acl)})).sort((a,b)=>(a.schema+'\0'+a.object_type).localeCompare(b.schema+'\0'+b.object_type));
 eq(actual,expected,'OWNER_DEFAULT_PRIVILEGES_CHANGED');return actual;
}
export async function validateOwnerDefaultPrivileges(c){
 const rows=(await c.query("select d.defaclrole::regrole::text as owner,coalesce(n.nspname,'*') as schema,d.defaclobjtype as object_type,(select coalesce(jsonb_agg(jsonb_build_object('grantor',pg_get_userbyid(a.grantor),'grantee',case when a.grantee=0 then 'PUBLIC' else pg_get_userbyid(a.grantee) end,'privilege',a.privilege_type,'grantable',a.is_grantable) order by a.grantor,a.grantee,a.privilege_type),'[]'::jsonb) from aclexplode(d.defaclacl) a) as acl from pg_default_acl d left join pg_namespace n on n.oid=d.defaclnamespace where d.defaclrole='campuspay_owner'::regrole order by coalesce(n.nspname,'*'),d.defaclobjtype")).rows;
 return validateOwnerDefaultPrivilegeRows(rows);
}
export function validateNewSecuritySnapshots(before,after,resolvedFunctions){
 const priorSchemas=new Set(before.schemas.map(x=>String(x.oid))),priorRelations=new Set(before.relations.map(x=>String(x.oid))),priorFunctions=new Set(before.functions.map(x=>String(x.oid)));
 if(after.schemas.some(x=>!priorSchemas.has(String(x.oid))))stop('UNREVIEWED_NEW_SCHEMA');
 const newRelations=after.relations.filter(x=>!priorRelations.has(String(x.oid)));
 const expectedRelations=new Map(CONTRACT.newSecurityObjects.relations.map(x=>[x.schema+'.'+x.name,{...x,acl:normalizeAcl(x.acl)}]));
 if(newRelations.length!==expectedRelations.size)stop('NEW_RELATION_SECURITY_SET_CHANGED');
 for(const row of newRelations){
  const key=row.schema+'.'+row.name,expected=expectedRelations.get(key);if(!expected)stop('UNREVIEWED_NEW_RELATION');
  eq({schema:row.schema,name:row.name,relkind:row.relkind,owner:row.owner,row_security:row.relrowsecurity,force_row_security:row.relforcerowsecurity,acl:normalizeAcl(row.acl)},expected,'NEW_RELATION_SECURITY_CHANGED');
 }
 const resolved=new Map((resolvedFunctions||[]).map(x=>[String(x.oid),x.signature]));
 if(resolved.size!==CONTRACT.newSecurityObjects.functions.length||[...resolvedFunctions||[]].some(x=>!x.oid))stop('NEW_FUNCTION_CONTRACT_UNRESOLVED');
 const expectedFunctions=new Map(CONTRACT.newSecurityObjects.functions.map(x=>[x.signature,{...x,acl:normalizeAcl(x.acl)}]));
 const newFunctions=after.functions.filter(x=>!priorFunctions.has(String(x.oid)));
 if(newFunctions.length!==expectedFunctions.size)stop('NEW_FUNCTION_SECURITY_SET_CHANGED');
 for(const row of newFunctions){
  const signature=resolved.get(String(row.oid)),expected=expectedFunctions.get(signature);if(!expected)stop('UNREVIEWED_NEW_FUNCTION');
  eq({signature,owner:row.owner,security_definer:row.security_definer,leakproof:row.leakproof,config:row.config??null,acl:normalizeAcl(row.acl)},expected,'NEW_FUNCTION_SECURITY_CHANGED');
 }
}
export function verifyDependencyIntegrity(root){
 const realRoot=fs.realpathSync(root),nodeModules=fs.realpathSync(path.join(root,'node_modules')),runner=fs.realpathSync(path.join(root,'scripts/migrate.mjs'));
 const insideNodeModules=p=>p.startsWith(nodeModules+path.sep);
 const resolved=new Map();
 const resolveFrom=(importer,name,expectedRelative)=>{
  if(importer!=='$runner'&&!resolved.has(importer))stop('DEPENDENCY_IMPORTER_UNRESOLVED');
  const importerFile=importer==='$runner'?runner:resolved.get(importer).entry;
  // Resolve the public entry from the actual importing package, never an
  // unexported metadata subpath. Bind metadata to that resolved entry's nearest
  // package boundary before comparing with the contracted real directory.
  const req=createRequire(importerFile),entry=fs.realpathSync(req.resolve(name));
  if(!fs.statSync(entry).isFile()||!insideNodeModules(entry))stop('DEPENDENCY_PATH_UNSAFE');
  let dir=path.dirname(entry),packageFile;
  while(insideNodeModules(dir)){
   const candidate=path.join(dir,'package.json');
   if(fs.existsSync(candidate)){packageFile=candidate;break;}
   dir=path.dirname(dir);
  }
  if(!packageFile)stop('DEPENDENCY_METADATA_MISSING');
  const stat=fs.lstatSync(packageFile),realPackageFile=fs.realpathSync(packageFile);
  if(stat.isSymbolicLink()||!stat.isFile()||path.dirname(realPackageFile)!==dir)stop('DEPENDENCY_PATH_UNSAFE');
  const expectedDir=fs.realpathSync(path.join(realRoot,expectedRelative));
  if(dir!==expectedDir)stop('DEPENDENCY_RESOLUTION_CHANGED');
  const pkg=JSON.parse(fs.readFileSync(realPackageFile,'utf8')),version=CONTRACT.criticalDependencies[name];
  if(!version||pkg.name!==name||pkg.version!==version)stop('DEPENDENCY_VERSION_MISMATCH');
  resolved.set(name,{dir,entry});return {req,dir,pkg};
 };
 for(const [importer,deps] of Object.entries(CONTRACT.criticalDependencyImports||{})){
  for(const [name,expectedRelative] of Object.entries(deps))resolveFrom(importer,name,expectedRelative);
 }
 const runnerReq=createRequire(runner),expectedIndex=fs.realpathSync(path.join(root,'node_modules/pg/lib/index.js'));
 if(fs.realpathSync(runnerReq.resolve('pg'))!==expectedIndex)stop('PG_MODULE_RESOLUTION_CHANGED');
 const covered=new Set(resolved.keys());
 for(const name of Object.keys(CONTRACT.criticalDependencies))if(!covered.has(name))stop('DEPENDENCY_CONTRACT_INCOMPLETE');
}
export function verifySource(root){
 if(sha(fs.readFileSync(path.join(root,'scripts/migrate.mjs')))!==CONTRACT.sourceFiles.runnerSha256)stop('RUNNER_HASH_MISMATCH');
 const names=fs.readdirSync(path.join(root,'database/migrations')).filter(x=>x.endsWith('.sql')).sort();
 eq(names,allNames.map(x=>x+'.sql'),'MIGRATION_FILES_CHANGED');
 for(const m of [...CONTRACT.baselineMigrations,...CONTRACT.pendingMigrations])if(sha(fs.readFileSync(path.join(root,'database/migrations',m.version+'.sql')))!==m.sha256)stop('MIGRATION_HASH_MISMATCH');
}
export function validateRetention(p,b,now=Date.now()){
 if(p?.schema!=='campuspay-retention-v1'||p.candidate!==CONTRACT.candidate||p.backupRun!==b.run||p.archive!==b.file||p.bytes!==b.bytes||p.sha256!==b.sha256||
 p.driveAccount!=='kohnerbouchard@gmail.com'||p.driveFolderId!=='13JPQ-J6eEmzqRBrHoaqQpm4Xk80rsFI6'||!/^[-_a-zA-Z0-9]{10,150}$/.test(p.driveFileId||'')||
 p.independentDownloadConfirmed!==true||p.downloadedSHA256!==b.sha256||p.downloadedBytes!==b.bytes||
 !Number.isFinite(Date.parse(p.verifiedAt))||Date.parse(p.verifiedAt)>now)stop('RETENTION_PROOF_INVALID');
 const k=p.keyRetrieval;if(k?.schema!=='campuspay-key-retrieval-v1'||k.backupRun!==b.run||k.purpose!=='ISOLATED_RESTORE'||k.source!=='APPLE_PASSWORDS'||k.separatelyReentered!==true||!Number.isFinite(Date.parse(k.recordedAt))||Date.parse(k.recordedAt)>now||typeof k.evidenceReference!=='string'||!k.evidenceReference.trim())stop('SAVED_KEY_RETRIEVAL_RECORD_INVALID');
 if(b.candidate!==CONTRACT.candidate||b.stage!=='LOCAL_BACKUP_RESTORE_VERIFIED_RETENTION_PENDING'||b.sourceStillMatchesBackup!==true||b.restore?.integrity!=='matched'||b.restore.runtime_direct_table_grants!==0)stop('BACKUP_PROOF_INCOMPLETE');
}
export async function history(c,expected){
 const rows=(await c.query('select version from private.schema_migrations order by version')).rows.map(x=>x.version);
 eq(rows,expected,'HISTORY_MISMATCH');return rows;
}
export async function inventory(c){
 const tables=(await c.query('select schemaname,tablename from pg_tables where schemaname in (\'public\',\'private\') order by schemaname collate "C",tablename collate "C"')).rows;
 const result=[];
 for(const t of tables){
  const q='select count(*)::text as count,md5(coalesce(string_agg(to_jsonb(t)::text,E\'\\n\' order by to_jsonb(t)::text collate "C"),\'\')) as digest from '+quote(t.schemaname)+'.'+quote(t.tablename)+' t';
  result.push({...t,...(await c.query(q)).rows[0]});
 }return result;
}
export async function drained(c){
 const rows=(await c.query("select usename,application_name,state,(xact_start is not null) as transaction_open from pg_stat_activity where datname=current_database() and pid<>pg_backend_pid() and backend_type='client backend'")).rows;
 if(rows.some(x=>x.usename!=='campuspay_runtime_login'||x.application_name!=='campuspay'||x.state!=='idle'||x.transaction_open!==false))stop('DATABASE_NOT_DRAINED');
}
export async function objectSecurity(c){
 const acl="(select coalesce(jsonb_agg(jsonb_build_object('grantor',pg_get_userbyid(a.grantor),'grantee',case when a.grantee=0 then 'PUBLIC' else pg_get_userbyid(a.grantee) end,'privilege',a.privilege_type,'grantable',a.is_grantable) order by a.grantor,a.grantee,a.privilege_type),'[]'::jsonb) from aclexplode(%ACL%) a) as acl";
 const schemas=(await c.query("select n.oid,n.nspname as name,n.nspowner::regrole::text as owner,"+acl.replace('%ACL%',"coalesce(n.nspacl,acldefault('n',n.nspowner))")+" from pg_namespace n where n.nspname in ('public','private','api','extensions') order by n.oid")).rows;
 const relations=(await c.query("select c.oid,n.nspname as schema,c.relname as name,c.relkind,c.relowner::regrole::text as owner,c.relrowsecurity,c.relforcerowsecurity,"+acl.replace('%ACL%',"coalesce(c.relacl,case when c.relkind='S' then acldefault('S',c.relowner) else acldefault('r',c.relowner) end)")+" from pg_class c join pg_namespace n on n.oid=c.relnamespace where n.nspname in ('public','private','api','extensions') and c.relkind in ('r','p','S','v','m','f') order by c.oid")).rows;
 const functions=(await c.query("select p.oid,n.nspname as schema,p.proname as name,p.proowner::regrole::text as owner,p.prosecdef as security_definer,p.proleakproof as leakproof,p.proconfig as config,"+acl.replace('%ACL%',"coalesce(p.proacl,acldefault('f',p.proowner))")+" from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname in ('public','private','api','extensions') order by p.oid")).rows;
 return normalizeSecurity({schemas,relations,functions});
}
export async function grants(c,post=false){
 const roles=(await c.query("select rolname,rolcanlogin,rolsuper,rolcreatedb,rolcreaterole,rolreplication,rolbypassrls from pg_roles where rolname in ('campuspay_runtime','campuspay_runtime_login') order by rolname")).rows;
 if(roles.length!==2||roles.some(r=>r.rolcanlogin!==(r.rolname==='campuspay_runtime_login')||['rolsuper','rolcreatedb','rolcreaterole','rolreplication','rolbypassrls'].some(k=>r[k]!==false)))stop('RUNTIME_ROLE_UNSAFE');
 const member=(await c.query("select pg_has_role('campuspay_runtime_login','campuspay_runtime','member') as ok")).rows[0];if(member.ok!==true)stop('RUNTIME_MEMBERSHIP_MISSING');
 const memberships=(await c.query("select member::regrole::text as member,roleid::regrole::text as role,admin_option,inherit_option,set_option from pg_auth_members where member in ('campuspay_runtime'::regrole,'campuspay_runtime_login'::regrole) order by 1,2")).rows;
 if(memberships.length!==1||memberships[0].member!=='campuspay_runtime_login'||memberships[0].role!=='campuspay_runtime'||memberships[0].admin_option!==false||memberships[0].inherit_option!==true)stop('RUNTIME_MEMBERSHIP_UNEXPECTED');
 const exposed=(await c.query("select count(*)::int n from pg_class c join pg_namespace n on n.oid=c.relnamespace cross join (values('campuspay_runtime'),('campuspay_runtime_login')) as r(role) where n.nspname in ('public','private') and ((c.relkind in ('r','p','v','m','f') and (has_table_privilege(r.role,c.oid,'SELECT,INSERT,UPDATE,DELETE,TRUNCATE,REFERENCES,TRIGGER') or has_any_column_privilege(r.role,c.oid,'SELECT,INSERT,UPDATE,REFERENCES'))) or (c.relkind='S' and has_sequence_privilege(r.role,c.oid,'USAGE,SELECT,UPDATE')))")).rows[0].n;
 if(exposed!==0)stop('RUNTIME_DIRECT_DATA_ACCESS');
 const schemas=(await c.query("select count(*)::int n from pg_namespace n cross join (values('campuspay_runtime'),('campuspay_runtime_login')) as r(role) where n.nspname in ('public','private','api','extensions') and has_schema_privilege(r.role,n.oid,'CREATE')")).rows[0].n;
 if(schemas!==0)stop('RUNTIME_SCHEMA_CREATE');
 const api=(await c.query("select has_schema_privilege('campuspay_runtime','api','USAGE') and has_schema_privilege('campuspay_runtime_login','api','USAGE') as ok")).rows[0];if(api.ok!==true)stop('RUNTIME_API_USAGE');
 if(post){
  const signatures=(await c.query("select required.signature,to_regprocedure(required.signature)::oid as oid,coalesce(has_function_privilege('campuspay_runtime',to_regprocedure(required.signature),'EXECUTE'),false) and coalesce(has_function_privilege('campuspay_runtime_login',to_regprocedure(required.signature),'EXECUTE'),false) as ok from unnest($1::text[]) required(signature)",[CONTRACT.runtimeApiSignatures])).rows;
  if(signatures.length!==89||signatures.some(x=>!x.oid||x.ok!==true))stop('APPLICATION_RPC_CONTRACT');
  const retired=(await c.query('select count(*)::int n from unnest($1::text[]) s where to_regprocedure(s) is not null',[CONTRACT.retiredPublicRpcSignatures])).rows[0].n;
  if(retired!==0)stop('RETIRED_PUBLIC_RPC_RESTORED');
  const wrappers=['api.create_staff_session(text,text,text,text)','api.authorize_session(text,text,text)'];
  const definitions=(await c.query("select pg_get_function_result(to_regprocedure(s)) as result from unnest($1::text[]) s",[wrappers])).rows;
  if(definitions.some(d=>!d.result.includes('preset text')||!d.result.includes('access_revision bigint')))stop('AUTHENTICATION_RESULT_CONTRACT');
  const secretHelpers=['private.create_staff_session_access_legacy(text,text,text,text)','private.authorize_session_access_legacy(text,text,text)','private.create_product_legacy(uuid,text,text,text,bigint,integer)','private.change_product_price_legacy(uuid,uuid,bigint,text)'];
  const helperLeak=(await c.query("select count(*)::int n from unnest($1::text[]) s left join pg_proc p on p.oid=to_regprocedure(s) where p.oid is null or has_function_privilege('campuspay_runtime',p.oid,'EXECUTE') or has_function_privilege('campuspay_runtime_login',p.oid,'EXECUTE') or exists(select 1 from aclexplode(coalesce(p.proacl,acldefault('f',p.proowner))) a where a.grantee=0 and a.privilege_type='EXECUTE')",[secretHelpers])).rows[0].n;
  if(helperLeak!==0)stop('PRIVATE_AUTHENTICATION_GRANT');
  const newApis=[...wrappers,'api.employee_access(uuid,uuid)','api.access_defaults(uuid)','api.change_employee_access(uuid,uuid,uuid,bigint,text,text[],text,text[],text,text,boolean)','api.recover_employee_access(uuid,uuid)','api.student_funding_readiness(uuid,uuid)','api.prepare_student_funding(uuid,uuid,uuid,jsonb)'];
  const bad=(await c.query("select count(*)::int n from pg_proc p where p.oid=any(array(select to_regprocedure(s)::oid from unnest($1::text[]) s)) and (not p.prosecdef or not coalesce(p.proconfig @> array['search_path=\"\"'],false) or exists(select 1 from aclexplode(coalesce(p.proacl,acldefault('f',p.proowner))) a where a.grantee=0 and a.privilege_type='EXECUTE'))",[newApis])).rows[0].n;
  if(bad!==0)stop('NEW_API_SECURITY_CONTRACT');
 }
 return {roles,memberships};
}
export async function beforeMigration(c,backupMetadata,{requireDrained=true}={}){
 await c.query('begin isolation level repeatable read read only');
 try{
  await c.query("set local timezone='UTC'");await history(c,oldNames);
  await validateMigration045Anchors(c);const defaultPrivileges=await validateOwnerDefaultPrivileges(c);
  const actual=await inventory(c);eq(actual,backupMetadata.tables,'SOURCE_CHANGED_SINCE_BACKUP');
  const acl=await grants(c);if(requireDrained)await drained(c);
  const sessions=(await c.query('select to_jsonb(s) as row from private.staff_sessions s order by id')).rows.map(x=>x.row);
  const audits=(await c.query('select id,md5(to_jsonb(a)::text) as digest from private.audit_events a order by id')).rows;
  const profiles=(await c.query('select auth_user_id,role,private.permissions_for_role(role) as previous_permissions from public.staff_profiles order by auth_user_id')).rows;
  const oldHistory=(await c.query('select to_jsonb(h) as row from private.schema_migrations h order by version')).rows.map(x=>x.row);
  const state={actual,acl,sessions,audits,profiles,oldHistory,defaultPrivileges,security:await objectSecurity(c)};
  await c.query('commit');return state;
 }catch(e){await c.query('rollback');throw e;}
}
export async function afterMigration(c,before,{requireDrained=true}={}){
 await c.query('begin isolation level repeatable read read only');
 try{
  await c.query("set local timezone='UTC'");await history(c,allNames);
  const acl=await grants(c,true);eq(acl,before.acl,'RUNTIME_ROLE_OR_MEMBERSHIP_CHANGED');
  const defaultPrivileges=await validateOwnerDefaultPrivileges(c);eq(defaultPrivileges,before.defaultPrivileges,'OWNER_DEFAULT_PRIVILEGES_CHANGED');
  const security=await objectSecurity(c);
  for(const kind of ['schemas','relations','functions']){
   const current=new Map(security[kind].map(x=>[x.oid,x]));
   for(const row of before.security[kind]){
    let expected=row;
    if(kind==='functions'&&row.schema==='api'&&['create_staff_session','authorize_session'].includes(row.name))expected={...row,schema:'private',name:row.name+'_access_legacy',acl:row.acl.filter(a=>!['PUBLIC','campuspay_runtime'].includes(a.grantee))};
    eq(current.get(row.oid),expected,'EXISTING_OBJECT_SECURITY_CHANGED');
   }
  }
  const signatures=CONTRACT.newSecurityObjects.functions.map(x=>x.signature);
  const resolvedFunctions=(await c.query("select s.signature,to_regprocedure(s.signature)::oid as oid from unnest($1::text[]) s(signature)",[signatures])).rows;
  validateNewSecuritySnapshots(before.security,security,resolvedFunctions);
  const actual=await inventory(c),byName=new Map(actual.map(x=>[x.schemaname+'.'+x.tablename,x]));
  eq(ordered([...byName.keys()]),ordered([...before.actual.map(x=>x.schemaname+'.'+x.tablename),...added]),'TABLE_SET_CHANGED');
  for(const row of before.actual){const name=row.schemaname+'.'+row.tablename;if(!changed.has(name))eq(byName.get(name),row,'FINANCIAL_OR_OPERATIONAL_DATA_CHANGED');}
  const normalizedFunding=(await c.query("select count(*)::text as count,md5(coalesce(string_agg((to_jsonb(t)-'expected_student_id')::text,E'\\n' order by (to_jsonb(t)-'expected_student_id')::text collate \"C\"),'')) as digest,count(expected_student_id)::int as bound from private.funding_intents t")).rows[0];
  const priorFunding=before.actual.find(x=>x.schemaname==='private'&&x.tablename==='funding_intents');
  if(normalizedFunding.count!==priorFunding.count||normalizedFunding.digest!==priorFunding.digest||normalizedFunding.bound!==0)stop('EXISTING_FUNDING_CHANGED');
  const fundingColumn=(await c.query("select atttypid='uuid'::regtype as uuid,attnotnull,atthasdef,attgenerated from pg_attribute where attrelid='private.funding_intents'::regclass and attname='expected_student_id' and not attisdropped")).rows;
  eq(fundingColumn,[{uuid:true,attnotnull:false,atthasdef:false,attgenerated:''}],'FUNDING_IDENTITY_COLUMN');
  const fundingFK=(await c.query("select convalidated,condeferrable,condeferred,confdeltype,confupdtype,confmatchtype,confrelid='private.students'::regclass as student_target,confkey=array[(select attnum from pg_attribute where attrelid='private.students'::regclass and attname='id')]::smallint[] as student_id from pg_constraint where conrelid='private.funding_intents'::regclass and contype='f' and conkey=array[(select attnum from pg_attribute where attrelid='private.funding_intents'::regclass and attname='expected_student_id')]::smallint[]")).rows;
  eq(fundingFK,[{convalidated:true,condeferrable:false,condeferred:false,confdeltype:'r',confupdtype:'a',confmatchtype:'s',student_target:true,student_id:true}],'FUNDING_IDENTITY_FOREIGN_KEY');
  const nowSessions=(await c.query('select to_jsonb(s) as row from private.staff_sessions s order by id')).rows.map(x=>x.row);
  if(nowSessions.length!==before.sessions.length)stop('STAFF_SESSION_COUNT_CHANGED');
  nowSessions.forEach((s,i)=>{const old=before.sessions[i];if(s.id!==old.id||s.access_revision!==0||s.revoked_at===null||old.revoked_at!==null&&old.revoked_at!==s.revoked_at)stop('STAFF_SESSION_REVOCATION');const stable={...s};delete stable.access_revision;stable.revoked_at=old.revoked_at;eq(stable,old,'STAFF_SESSION_UNEXPECTED_CHANGE');});
  const nowAudit=(await c.query('select id,md5(to_jsonb(a)::text) as digest,to_jsonb(a) as row from private.audit_events a order by id')).rows;
  const oldAudits=new Map(before.audits.map(x=>[x.id,x.digest]));const newAudits=[];
  for(const a of nowAudit){if(oldAudits.has(a.id)){if(oldAudits.get(a.id)!==a.digest)stop('EXISTING_AUDIT_CHANGED');oldAudits.delete(a.id);}else newAudits.push(a.row);}
  if(oldAudits.size||newAudits.length!==before.profiles.length)stop('AUDIT_SET_CHANGED');
  const mapped=(await c.query('select user_id,preset,permissions,revision::text from private.staff_access order by user_id')).rows;
  if(mapped.length!==before.profiles.length)stop('STAFF_ACCESS_COUNT');
  for(let i=0;i<mapped.length;i++){
   const a=mapped[i],p=before.profiles[i],preset=p.role==='cashier'?'staff':p.role==='inventory_admin'?'manager':p.role;
   if(a.user_id!==p.auth_user_id||a.preset!==preset||a.revision!=='1')stop('LEGACY_ACCESS_MAPPING');
   eq(a.permissions,CONTRACT.legacyMapping[p.role],'LEGACY_ACCESS_PERMISSIONS');
   const event=newAudits.find(e=>e.subject_id===a.user_id);
   if(!event||event.event_type!=='STAFF_ACCESS_MIGRATED'||event.subject_type!=='STAFF'||event.reference_number!=='AUD-ACCESS-MIGRATION-'+a.user_id||event.actor_user_id!==null||event.approver_user_id!==null||event.staff_session_id!==null)stop('ACCESS_MIGRATION_AUDIT');
   eq(event.safe_payload,{reason:'Explicit equivalent legacy capabilities; legacy unclassified wallet adjustment retired',new_preset:preset,previous_role:p.role,previous_permissions:p.previous_permissions,effective_permissions:a.permissions},'ACCESS_MIGRATION_AUDIT_PAYLOAD');
  }
  const catalog=(await c.query('select name,workspace,area,access_column,label,prerequisites from private.capability_catalog order by name')).rows;
  const expectedCatalog=CONTRACT.capabilityCatalog.map(x=>({name:x.name,workspace:x.workspace,area:x.area,access_column:x.column,label:x.label,prerequisites:x.requires})).sort((a,b)=>a.name<b.name?-1:1);
  // Compare each field to avoid relying on JSON object's key order.
  if(catalog.length!==47)stop('CAPABILITY_CATALOG_COUNT');catalog.forEach((x,i)=>Object.keys(expectedCatalog[i]).forEach(k=>eq(x[k],expectedCatalog[i][k],'CAPABILITY_CATALOG_CHANGED')));
  const presets=(await c.query('select preset,permissions from private.access_preset_defaults order by preset')).rows;
  eq(presets,Object.entries(CONTRACT.presetDefaults).sort(([a],[b])=>a<b?-1:1).map(([preset,permissions])=>({preset,permissions})),'PRESET_DEFAULTS_CHANGED');
  const checks=(await c.query("select (select count(*)::int from private.staff_access where not private.valid_access(permissions)) as invalid_access,(select count(*)::int from private.staff_access_events) as access_events,(select count(*)::int from private.staff_access_closures) as access_closures,(select count(*)::int from public.staff_profiles p where private.is_access_administrator(p.auth_user_id)) as usable_admins,(select count(*)::int from pg_trigger where not tgisinternal and tgenabled='O' and ((tgname='seed_effective_access' and tgrelid='public.staff_profiles'::regclass) or (tgname='immutable_access_event' and tgrelid='private.staff_access_events'::regclass) or (tgname='immutable_access_closure' and tgrelid='private.staff_access_closures'::regclass))) as triggers")).rows[0];
  if(checks.invalid_access||checks.access_events||checks.access_closures||checks.usable_admins<1||checks.triggers!==3)stop('ACCESS_POSTFLIGHT_INVARIANT');
  const triggers=(await c.query("select tgname,n.nspname||'.'||c.relname as relation,tgfoid::regprocedure::text as function,tgtype,tgenabled,tgnargs,tgqual is null as unconditional,tgattr::text as columns from pg_trigger t join pg_class c on c.oid=t.tgrelid join pg_namespace n on n.oid=c.relnamespace where not tgisinternal and ((tgname='seed_effective_access' and tgrelid='public.staff_profiles'::regclass) or (tgname='immutable_access_event' and tgrelid='private.staff_access_events'::regclass) or (tgname='immutable_access_closure' and tgrelid='private.staff_access_closures'::regclass)) order by tgname")).rows;
  eq(triggers,[['immutable_access_closure','private.staff_access_closures','private.reject_journal_mutation()',27],['immutable_access_event','private.staff_access_events','private.reject_journal_mutation()',27],['seed_effective_access','public.staff_profiles','private.seed_staff_access()',5]].map(([tgname,relation,fn,tgtype])=>({tgname,relation,function:fn,tgtype,tgenabled:'O',tgnargs:0,unconditional:true,columns:''})),'ACCESS_TRIGGER_CONTRACT');
  const oldHistory=(await c.query('select to_jsonb(h) as row from private.schema_migrations h where version=any($1::text[]) order by version',[oldNames])).rows.map(x=>x.row);eq(oldHistory,before.oldHistory,'HISTORICAL_MIGRATION_ROWS_CHANGED');
  if(requireDrained)await drained(c);await c.query('commit');
  return {status:'DATABASE_37_VERIFIED_PROMOTION_PENDING',migrationCount:37,appliedCount:5,runtimeRpcCount:89,retiredPublicRpcsAbsent:2,capabilityCount:47,presetCount:4,staffMappings:mapped.length,existingStaffSessionsVerifiedRevoked:nowSessions.length,previouslyActiveStaffSessionsRevoked:before.sessions.filter(s=>s.revoked_at===null).length,newMigrationAuditEvents:newAudits.length,existingFinancialAndOperationalTablesUnchanged:true,runtimeDirectDataGrants:0};
 }catch(e){await c.query('rollback');throw e;}
}
export async function invokeQualifiedRunner({pg,root,before,beforeFirstDDL=async()=>{},after}){
 if(fs.realpathSync(process.cwd())!==fs.realpathSync(root))stop('RUNNER_WORKING_DIRECTORY_MISMATCH');
 verifySource(root);verifyDependencyIntegrity(root);const Original=pg.Client,originalArgv=process.argv;const state={before:false,firstDDL:false,after:false,error:null,result:null};
 class GuardedClient extends Original{
  async query(...args){
   if(args[0]==='select pg_advisory_lock(84632291)'){
    if(state.before)stop('RUNNER_LOCK_REPEATED');
    const result=await super.query(...args);
    try{state.snapshot=await before(this);state.before=true;}catch(e){state.error=e;throw e;}
    return result;
   }
   if(args[0]==='create schema if not exists private'){
    if(!state.before||state.firstDDL)stop('RUNNER_FIRST_DDL_ORDER_CHANGED');
    try{await beforeFirstDDL(this,state.snapshot);state.firstDDL=true;}catch(e){state.error=e;throw e;}
   }
   return super.query(...args);
  }
  async end(...args){
   try{
    if(state.before&&!process.exitCode){try{state.result=await after(this,state.snapshot);state.after=true;}catch(e){state.error=e;throw e;}}
   }finally{await super.end(...args);}
  }
 }
 pg.Client=GuardedClient;
 process.argv=[process.execPath,path.join(root,'scripts/migrate.mjs'),'--check-runtime'];
 try{await import(pathToFileURL(path.join(root,'scripts/migrate.mjs')).href+'?cutover='+crypto.randomUUID());}
 finally{pg.Client=Original;process.argv=originalArgv;}
 if(state.error)throw state.error;
 if(process.exitCode||!state.before||!state.firstDDL||!state.after)stop('RUNNER_OR_POSTFLIGHT_INCOMPLETE');
 return state.result;
}
