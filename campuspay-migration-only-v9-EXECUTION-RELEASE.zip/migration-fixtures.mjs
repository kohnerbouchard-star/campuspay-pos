// Synthetic fixtures only; never update the real package policy from these outputs.
import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';
import {POLICY,evidenceHash} from './migration-evidence.mjs';
export function fixture(dir){
 fs.mkdirSync(dir,{recursive:true});for(const d of ['original','download','evidence'])fs.mkdirSync(path.join(dir,d));
 const bytes=Buffer.concat([Buffer.from('CPBKP01\n'),crypto.randomBytes(64)]);
 const policy=structuredClone(POLICY);policy.backup.bytes=bytes.length;policy.backup.sha256=crypto.createHash('sha256').update(bytes).digest('hex');
 const backup=structuredClone(policy.backup),original=path.join(dir,'original',backup.file),download=path.join(dir,'download',backup.file),evidence=path.join(dir,'evidence');
 fs.writeFileSync(original,bytes);fs.writeFileSync(download,bytes);fs.writeFileSync(path.join(evidence,'verified-backup.json'),JSON.stringify(backup)+'\n');
 return {policy,original,download,evidence,e:{backup,policySHA256:evidenceHash(policy),retentionReview:policy.retentionReview,scope:'DATABASE_ONLY_KEEP_FULL_MAINTENANCE'}};
}
if(process.argv[2]==='--make-fixture'){const f=fixture(process.argv[3]);fs.writeFileSync(path.join(process.argv[3],'fixture.json'),JSON.stringify(f));}
