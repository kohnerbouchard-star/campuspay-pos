# CampusPay v9 migration-only review handoff — execution disabled

This package prepares only the original five access/funding migrations for candidate `4e55ece88cb0afcc3e85c8f0436f8d346f5c40a1`, tree `25041b33225b68a95b8f54d8e59e23b0cd624e3e`. It does not include stock-recovery migration 050, application promotion, a merge, maintenance changes, or credential changes. No production execution has occurred during this qualification.

## Current blocker

`execution-release.json` remains `PENDING_INDEPENDENT_REVIEW`. Both the Windows launcher and driver reject execution before credentials or provider access. Even `--check-only` is intentionally blocked until review. This document is not an apply command. An independent review must assess this exact package and its migration-only separation before a separately rebuilt, checksum-pinned executable package can be issued. The author's passing tests are not independent approval.

The application and schema still require a coordinated release. The five migrations can be staged separately from stock 050 only while verified full maintenance remains in force and every other writer is stopped. Success leaves the database at `DATABASE_37_VERIFIED_PROMOTION_PENDING`; no old application may resume normal operation against it. Matching application qualification and promotion remain separate gates. Migration 050 requires a separately scoped package and review; do not add it to this five-migration run.

## Existing Windows assets — preserve and recheck

Use the same Windows work PC with Git Bash and Linux Docker, not a new Mac setup.

- Checkout: `C:/Users/user/campuspay-stage.p1RrSnsE/source`
- Tools/backup volume: `campuspay-tools-91ead009-8c77-49a7-9995-653bae46984e`
- Backup directory: `C:/Users/user/campuspay-encrypted-backup.rH0ltFuP`
- Isolated CLI login directory: `C:/Users/user/campuspay-vercel-auth.CJua4cxw`
- Original backup run: `c56dfa33-ad2f-4372-9ce0-79cfac21613d`
- Archive: `campuspay-pre-cutover-c56dfa33-ad2f-4372-9ce0-79cfac21613d.cpbackup`
- Archive SHA256: `da91ab3c6e02d4bdecfbe1e0e0e0db23755135bb0d36c990a2bfb0455905f35b5d`; size 687389 bytes.

The original ciphertext and the previously downloaded second copy must both still exist in distinct locations. The second copy's exact Windows path is not recorded in this package; locate that existing file rather than guess. The launcher rehashes both copies and reads the original `verified-backup.json` from the retained volume. Do not repeat the completed backup or overwrite its proof. Prior retention/restore evidence is explicitly historical, not a new Drive download or fresh source comparison.

The operator launcher requires the existing isolated login directory through `CAMPUSPAY_VERCEL_CONFIG_DIR`. It uses read-only provider checks and unauthenticated HEAD probes. If that access is denied, stop; do not change accounts, protection settings, or bypass the denial. Secrets are entered through hidden local prompts and stdin, never into chat, command arguments, or exported environment variables.

## Fresh apply-time gates after independent review

Recheck exact clean source/tree, project identity, pinned images and tools, both ciphertext hashes, existing backup proof and absence of a prior attempt marker. Verify full maintenance, unchanged deployment/domain inventory, no concurrent deployment or rollout, and all other writers stopped. Recover uncertain financial operations on their original register and close affected drawers through their normal workflow before confirming prerequisites.

The driver checks the fixed database/owner/direct-host identity and verified TLS, authenticates the retained encrypted backup, compares current data with its snapshot, validates exact baseline history and security contracts, and holds the existing runner's migration lock. It reserves the durable backup-scoped attempt marker immediately before first DDL under fresh maintenance evidence. Only the five contracted migrations may run. Postflight verifies history, financial/operational preservation, audit, session revocation, grants, and effective-access contracts.

On failure, interruption, partial migration, missing evidence, or lost maintenance: keep maintenance closed; preserve the volume and all attempt/evidence files; inspect exact history before deciding a fix-forward action. No automatic retry, marker deletion, restore, promotion, or reopening is permitted by this package.

## Qualification provenance

Final guard tests use the pinned Node 22 image with read-only sources and no network. Shell cases run actual Bash/Node code against offline provider/Docker fixtures on Linux; they do not constitute native Windows execution or live provider validation. The native rehearsal uses a new synthetic database in a network-none, unpublished-port PostgreSQL container with tmpfs database storage, then removes only its own labeled resources. See FINAL_QUALIFICATION.json for completed results and limits.

The older `campuspay-review-tests-gitbash.sh` in the working directory has outdated count/dependency assumptions and is not included as a supported v9 launcher. The uploaded v7 archive is preserved separately as historical evidence; none of its embedded instructions supersede the user's scope or these release locks.
