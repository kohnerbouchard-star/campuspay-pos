// Offline release-record checks only. Never invokes driver.main or any provider.
import assert from 'node:assert/strict';
import {RELEASE,validateExecutionRelease} from './execution-release.mjs';
validateExecutionRelease();
assert.equal(RELEASE.status,'REVIEWED_FOR_EXECUTION');
assert.equal(RELEASE.reviewReference,'campuspay-v9-local-review-414833d5-v9_independent_review');
const bad=[{status:'PENDING_INDEPENDENT_REVIEW'},{candidate:'other'},{tree:'other'},{scope:'PROMOTE'},{reviewReference:null},{reviewReference:''},{reviewedAt:null},{reviewedAt:'2999-01-01T00:00:00Z'}];
for(const patch of bad)assert.throws(()=>validateExecutionRelease({...RELEASE,...patch}),/INDEPENDENT_PACKAGE_REVIEW_NOT_COMPLETED/);
console.log(JSON.stringify({scope:'OFFLINE_RELEASE_RECORD_ONLY',validReviewedRecordAccepted:true,invalidRecordsRejected:bad.length,productionAccessed:false,driverInvoked:false}));
