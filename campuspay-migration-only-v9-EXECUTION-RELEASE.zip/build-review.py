from pathlib import Path
import hashlib,json,subprocess
root=Path(__file__).resolve().parent
names=['execution-release.json','execution-release.mjs','migration-evidence.mjs','migration-policy.json','contract.json','core.mjs','driver.mjs','evidence.mjs','hold-guard.mjs','pack-input.mjs','package-payload.mjs','release-policy.json','tools.mjs']
manifest={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in sorted(names)}
data=(json.dumps(manifest,indent=2)+'\n').encode();(root/'bundle-sha256.json').write_bytes(data)
s=(root/'wrapper.template.sh').read_text().replace('@@MANIFEST_SHA@@',hashlib.sha256(data).hexdigest())
(root/'campuspay-migrate-only.sh').write_text(s)
subprocess.run(['bash','-n',str(root/'campuspay-migrate-only.sh')],check=True)
for n in names:
 if n.endswith('.mjs'):subprocess.run(['node','--check',str(root/n)],check=True)
