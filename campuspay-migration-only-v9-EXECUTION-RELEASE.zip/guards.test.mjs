import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';import {spawnSync} from 'node:child_process';
import {CONTRACT,validateRetention,history,verifySource,verifyDependencyIntegrity,invokeQualifiedRunner,validateMigration045Definitions,validateOwnerDefaultPrivilegeRows,validateNewSecuritySnapshots} from './core.mjs';
import {validateHold,sourceURL,validateKey,validateBackupProof,readRegularFile,reserveAttempt,reserveAttemptUnderFreshHold} from './driver.mjs';
const now=Date.now(),stamp=new Date(now).toISOString();
const QUALIFIED_REPO=process.env.CAMPUSPAY_QUALIFIED_REPO||'/workspace/campuspay-pos';
const backup={candidate:CONTRACT.candidate,run:'a'.repeat(36),file:'synthetic.cpbackup',bytes:100,sha256:'b'.repeat(64),stage:'LOCAL_BACKUP_RESTORE_VERIFIED_RETENTION_PENDING',sourceStillMatchesBackup:true,restore:{integrity:'matched',runtime_direct_table_grants:0}};
const retained=()=>({schema:'campuspay-retention-v1',candidate:CONTRACT.candidate,backupRun:backup.run,archive:backup.file,bytes:100,sha256:backup.sha256,driveAccount:'kohnerbouchard@gmail.com',driveFolderId:'13JPQ-J6eEmzqRBrHoaqQpm4Xk80rsFI6',driveFileId:'synthetic-file-id-only',independentDownloadConfirmed:true,downloadedSHA256:backup.sha256,downloadedBytes:100,keyRetrieval:{schema:'campuspay-key-retrieval-v1',backupRun:backup.run,purpose:'ISOLATED_RESTORE',source:'APPLE_PASSWORDS',separatelyReentered:true,recordedAt:stamp,evidenceReference:'SYNTHETIC ONLY'},verifiedAt:stamp});
test('valid independent retention proof and verified backup are required together',()=>validateRetention(retained(),backup,now));
for(const [name,patch] of Object.entries({wrongCandidate:{candidate:'wrong'},wrongBackup:{backupRun:'wrong'},wrongFolder:{driveFolderId:'wrong'},wrongAccount:{driveAccount:'wrong'},missingDriveObject:{driveFileId:''},noIndependentDownload:{independentDownloadConfirmed:false},downloadCorrupted:{downloadedSHA256:'c'.repeat(64)},downloadTruncated:{downloadedBytes:99},savedKeyUnverified:{keyRetrieval:{schema:'campuspay-key-retrieval-v1',backupRun:backup.run,purpose:'ISOLATED_RESTORE',source:'UNRECORDED',separatelyReentered:false,recordedAt:stamp,evidenceReference:'SYNTHETIC ONLY'}},futureProof:{verifiedAt:new Date(now+1000).toISOString()}}))test('retention rejects '+name,()=>assert.throws(()=>validateRetention({...retained(),...patch},backup,now)));
test('backup proof alone cannot satisfy restore/source preservation',()=>{for(const patch of [{sourceStillMatchesBackup:false},{restore:{integrity:'unknown',runtime_direct_table_grants:0}},{restore:{integrity:'matched',runtime_direct_table_grants:1}}])assert.throws(()=>validateRetention(retained(),{...backup,...patch},now));});
const hold=()=>({projectId:'prj_wXkpTGGYjL6emMhAX6RSwxkafkME',teamId:'team_PRsNkw4DHrGsUHl6ikKw2XyJ',candidate:CONTRACT.candidate,deploymentId:'dpl_TUjLdvRW2DTuBAyoAmqUKQSoyWzy',liveDeploymentId:'dpl_3brN53nacbuaDiT1JMLtYzAKGhKQ',ruleName:'CampusPay maintenance',ruleId:'rule_campus_pay_maintenance_9bJUPi',configVersion:3,firstActiveUnrestrictedDeny:true,unreviewedDraftCount:0,otherWritersStopped:true,protectionScope:'all_except_custom_domains',publicMicaDenied:4,generatedDenied:0,generatedSsoBeforeWaf:8,authenticatedCandidateDeniedEvidence:'User confirmation Sentinel_ec948eadb46c81918c0420e562244bae, relayed by parent on 2026-10-06',redirectsFollowed:false,authenticationOrBypassUsed:false,approvedDomainInventoryVerified:true,noRollingRelease:true,noPendingPromotion:true,noConcurrentDeployment:true,checkedAt:stamp});
test('current full hold evidence is accepted',()=>validateHold(hold(),now));
for(const [name,patch] of Object.entries({wrongProject:{projectId:'wrong'},wrongCandidate:{candidate:'wrong'},liveMoved:{liveDeploymentId:'wrong'},exceptionOrLog:{firstActiveUnrestrictedDeny:false},draft:{unreviewedDraftCount:1},incompleteProbes:{generatedSsoBeforeWaf:7},writersUnknown:{otherWritersStopped:false},stale:{checkedAt:new Date(now-301000).toISOString()}}))test('hold rejects '+name,()=>assert.throws(()=>validateHold({...hold(),...patch},now)));
test('exact migration history rejects missing, extra, and reordered versions',async()=>{const expected=CONTRACT.baselineMigrations.map(x=>x.version);const c=rows=>({query:async()=>({rows:rows.map(version=>({version}))})});await history(c(expected),expected);for(const bad of [expected.slice(1),[...expected,'unknown'],[...expected].reverse()])await assert.rejects(history(c(bad),expected),/HISTORY_MISMATCH/);});
test('runner/migrations remain exact qualified source',()=>verifySource(QUALIFIED_REPO));
test('fixed owner URL safely encodes special password bytes',()=>{const p='synthetic%#/ @';const u=new URL(sourceURL(p));assert.equal(decodeURIComponent(u.password),p);assert.equal(u.searchParams.get('sslmode'),'verify-full');assert.equal(u.username,'campuspay_owner');assert.match(u.hostname,/^ep-broad-tooth-/);});
test('invalid keys and multiline passwords fail before connection',()=>{for(const p of ['','x\ny','x\ry'])assert.throws(()=>sourceURL(p));for(const key of ['', 'invalid', 'A'.repeat(44)])assert.throws(()=>validateKey(key));validateKey(Buffer.alloc(32).toString('base64'));});
const backupRun='01234567-89ab-cdef-0123-456789abcdef';
const archiveProof=()=>({...backup,run:backupRun,host:'ep-broad-tooth-az9zz1z8.c-3.ap-southeast-1.aws.neon.tech',database:'campuspay',file:'campuspay-pre-cutover-'+backupRun+'.cpbackup'});
test('only canonical backup archive name, run and target accepted',()=>validateBackupProof(archiveProof(),backupRun));
for(const [name,patch] of Object.entries({traversal:{file:'../foreign.cpbackup'},absolute:{file:'/foreign.cpbackup'},wrongRun:{run:'wrong'},wrongHost:{host:'localhost'},wrongDatabase:{database:'postgres'},oversized:{bytes:64*1024*1024+1},empty:{bytes:0},invalidSize:{bytes:'100'},invalidHash:{sha256:'hash'}}))test('backup identity rejects '+name,()=>assert.throws(()=>validateBackupProof({...archiveProof(),...patch},backupRun)));
test('evidence reads reject symlink, hardlink, directory and oversized files',()=>{const dir=fs.mkdtempSync(path.join(os.tmpdir(),'campuspay-evidence-test-'));try{fs.writeFileSync(dir+'/plain','abc');assert.equal(readRegularFile(dir+'/plain',3).toString(),'abc');assert.throws(()=>readRegularFile(dir+'/plain',2));fs.symlinkSync(dir+'/plain',dir+'/link');assert.throws(()=>readRegularFile(dir+'/link',3));fs.linkSync(dir+'/plain',dir+'/hard');assert.throws(()=>readRegularFile(dir+'/hard',3));assert.throws(()=>readRegularFile(dir,10000));}finally{fs.rmSync(dir,{recursive:true});}});
test('review candidate rejects execution before reading credentials or database',()=>{const r=spawnSync(process.execPath,[new URL('./driver.mjs',import.meta.url).pathname],{encoding:'utf8',input:'not-json',env:{PATH:process.env.PATH}});assert.equal(r.status,1);assert.match(r.stderr,/INDEPENDENT_PACKAGE_REVIEW_NOT_COMPLETED/);assert.equal(r.stdout,'');});
test('runner refuses a different current directory before creating a database client',async()=>{await assert.rejects(invokeQualifiedRunner({pg:{},root:'/tmp'}),/RUNNER_WORKING_DIRECTORY_MISMATCH/);});
test('durable backup-scoped apply marker cannot be overwritten or reused',()=>{const dir=fs.mkdtempSync(path.join(os.tmpdir(),'campuspay-attempt-test-'));try{const r={candidate:CONTRACT.candidate,backupRun,applyRun:'synthetic-only',stage:'APPROVED_APPLY_STARTED_UNDER_HOLD'};reserveAttempt(dir,r);assert.deepEqual(JSON.parse(fs.readFileSync(dir+'/cutover-attempt.json')),r);assert.throws(()=>reserveAttempt(dir,{...r,applyRun:'retry'}),/BACKUP_ALREADY_USED_FOR_APPLY_REVIEW_REQUIRED/);assert.deepEqual(JSON.parse(fs.readFileSync(dir+'/cutover-attempt.json')),r);}finally{fs.rmSync(dir,{recursive:true});}});


test('migration 045 exact replacement anchors accept the baseline definitions and fail on whitespace drift',()=>{
 const defs={
  'api.create_staff_session(text,text,text,text)':`x private.permissions_for_role(v_profile.role) y session_token_hash, expires_at z p_session_token_hash, now() + private.session_timeout(v_profile.role)`,
  'api.authorize_session(text,text,text)':`x private.permissions_for_role(v_profile.role) y`
 };
 validateMigration045Definitions(defs);
 assert.throws(()=>validateMigration045Definitions({...defs,'api.create_staff_session(text,text,text,text)':defs['api.create_staff_session(text,text,text,text)'].replace('session_token_hash, expires_at','session_token_hash,   expires_at')}),/MIGRATION_045_REPLACEMENT_ANCHOR_DRIFT/);
 assert.throws(()=>validateMigration045Definitions({...defs,'api.authorize_session(text,text,text)':defs['api.authorize_session(text,text,text)'].replace('private.permissions_for_role(v_profile.role)','private.permissions_for_role( v_profile.role )')}),/MIGRATION_045_REPLACEMENT_ANCHOR_DRIFT/);
});
test('owner default privileges fail closed on any inherited grant or grant option drift',()=>{
 validateOwnerDefaultPrivilegeRows(CONTRACT.ownerDefaultPrivileges);
 const extra=JSON.parse(JSON.stringify(CONTRACT.ownerDefaultPrivileges));extra[0].acl.push({grantor:'campuspay_owner',grantee:'PUBLIC',privilege:'EXECUTE',grantable:false});
 assert.throws(()=>validateOwnerDefaultPrivilegeRows(extra),/OWNER_DEFAULT_PRIVILEGES_CHANGED/);
 const grantable=JSON.parse(JSON.stringify(CONTRACT.ownerDefaultPrivileges));grantable[0].acl[0].grantable=true;
 assert.throws(()=>validateOwnerDefaultPrivilegeRows(grantable),/OWNER_DEFAULT_PRIVILEGES_CHANGED/);
});
test('every new security-bearing relation/function is exact and unexpected grants fail closed',()=>{
 const before={schemas:[{oid:1}],relations:[{oid:2}],functions:[{oid:3}]};
 const relationRows=CONTRACT.newSecurityObjects.relations.map((x,i)=>({oid:100+i,schema:x.schema,name:x.name,relkind:x.relkind,owner:x.owner,relrowsecurity:x.row_security,relforcerowsecurity:x.force_row_security,acl:x.acl}));
 const functionRows=CONTRACT.newSecurityObjects.functions.map((x,i)=>({oid:200+i,owner:x.owner,security_definer:x.security_definer,leakproof:x.leakproof,config:x.config,acl:x.acl}));
 const after={schemas:[{oid:1}],relations:[{oid:2},...relationRows],functions:[{oid:3},...functionRows]};
 const resolved=CONTRACT.newSecurityObjects.functions.map((x,i)=>({signature:x.signature,oid:200+i}));
 validateNewSecuritySnapshots(before,after,resolved);
 const bad=JSON.parse(JSON.stringify(after));bad.functions[1].acl.push({grantor:'campuspay_owner',grantee:'PUBLIC',privilege:'EXECUTE',grantable:false});
 assert.throws(()=>validateNewSecuritySnapshots(before,bad,resolved),/NEW_FUNCTION_SECURITY_CHANGED/);
 const rogue=JSON.parse(JSON.stringify(after));rogue.relations.push({...relationRows[0],oid:999,name:'unreviewed_table'});
 assert.throws(()=>validateNewSecuritySnapshots(before,rogue,resolved),/NEW_RELATION_SECURITY_SET_CHANGED/);
});
test('fresh hold is rechecked immediately before attempt reservation and stale evidence creates no marker',()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'campuspay-fresh-hold-'));try{
  const record={candidate:CONTRACT.candidate,backupRun,applyRun:'freshness-test'};
  const fresh=hold();reserveAttemptUnderFreshHold(dir,record,fresh,now);assert.ok(fs.existsSync(dir+'/cutover-attempt.json'));
  const staleDir=fs.mkdtempSync(path.join(os.tmpdir(),'campuspay-stale-hold-'));try{assert.throws(()=>reserveAttemptUnderFreshHold(staleDir,record,{...fresh,checkedAt:new Date(now-301000).toISOString()},now),/FULL_HOLD_PROOF_INVALID_OR_STALE/);assert.equal(fs.existsSync(staleDir+'/cutover-attempt.json'),false);}finally{fs.rmSync(staleDir,{recursive:true});}
 }finally{fs.rmSync(dir,{recursive:true});}
});


function writeDependencyPackage(dir,name,version=CONTRACT.criticalDependencies[name]){
 fs.mkdirSync(dir,{recursive:true});
 const main=name==='pg'?'lib/index.js':'index.js';
 fs.writeFileSync(path.join(dir,'package.json'),JSON.stringify({name,version,main,exports:{'.':{require:'./'+main,default:'./'+main}}}));
 fs.mkdirSync(path.dirname(path.join(dir,main)),{recursive:true});fs.writeFileSync(path.join(dir,main),'module.exports={}\n');
}
function makeDependencyRoot(){
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'campuspay-deps-'));
 fs.mkdirSync(path.join(root,'scripts'),{recursive:true});fs.writeFileSync(path.join(root,'scripts/migrate.mjs'),'// synthetic only\n');
 for(const [name,version] of Object.entries(CONTRACT.criticalDependencies))writeDependencyPackage(path.join(root,'node_modules',name),name,version);
 return root;
}
test('dependency integrity resolves from each actual importing package and rejects version/path/nested-shadow drift',()=>{
 const makeRoot=makeDependencyRoot;
 const good=makeRoot();try{verifyDependencyIntegrity(good);const file=path.join(good,'node_modules/pg-protocol/package.json'),p=JSON.parse(fs.readFileSync(file));p.version='0.0.0';fs.writeFileSync(file,JSON.stringify(p));assert.throws(()=>verifyDependencyIntegrity(good),/DEPENDENCY_VERSION_MISMATCH/);}finally{fs.rmSync(good,{recursive:true});}
 const shadowed=makeRoot();try{const nested=path.join(shadowed,'node_modules/pg/node_modules/pg-protocol');fs.mkdirSync(nested,{recursive:true});writeDependencyPackage(nested,'pg-protocol');assert.throws(()=>verifyDependencyIntegrity(shadowed),/DEPENDENCY_RESOLUTION_CHANGED/);}finally{fs.rmSync(shadowed,{recursive:true});}
 const escaped=makeRoot();try{const outside=fs.mkdtempSync(path.join(os.tmpdir(),'campuspay-deps-outside-'));try{fs.rmSync(path.join(escaped,'node_modules/pgpass'),{recursive:true});fs.mkdirSync(path.join(outside,'pgpass'));writeDependencyPackage(path.join(outside,'pgpass'),'pgpass');fs.symlinkSync(path.join(outside,'pgpass'),path.join(escaped,'node_modules/pgpass'),'dir');assert.throws(()=>verifyDependencyIntegrity(escaped),/DEPENDENCY_PATH_UNSAFE/);}finally{fs.rmSync(outside,{recursive:true});}}finally{fs.rmSync(escaped,{recursive:true});}
});
test('dependency contract matches the qualified package-lock closure used by pg',()=>{
 const lock=JSON.parse(fs.readFileSync(new URL('./qualified-reference/package-lock.json',import.meta.url),'utf8'));
 for(const [name,version] of Object.entries(CONTRACT.criticalDependencies))assert.equal(lock.packages?.['node_modules/'+name]?.version,version,name);
 for(const [importer,deps] of Object.entries(CONTRACT.criticalDependencyImports)){
  if(importer==='$runner')continue;const entry=lock.packages?.['node_modules/'+importer];assert.ok(entry,importer);
  const declared={...(entry.dependencies||{}),...(entry.optionalDependencies||{})};for(const name of Object.keys(deps))assert.ok(Object.hasOwn(declared,name),importer+' -> '+name);
 }
});




test('security-object contract covers every permanent CREATE TABLE/FUNCTION in the five qualified migrations',()=>{
 const sql=CONTRACT.pendingMigrations.map(m=>fs.readFileSync(QUALIFIED_REPO+'/database/migrations/'+m.version+'.sql','utf8')).join('\n');
 const tables=[...sql.matchAll(/^\s*create\s+table\s+([^\s(]+)/gim)].map(m=>m[1]).sort();
 const functions=[...sql.matchAll(/^\s*create\s+function\s+([^\s(]+)/gim)].map(m=>m[1]).filter(x=>!x.startsWith('pg_temp.')).sort();
 const contractTables=CONTRACT.newSecurityObjects.relations.map(x=>x.schema+'.'+x.name).sort();
 const contractFunctions=CONTRACT.newSecurityObjects.functions.map(x=>x.signature.slice(0,x.signature.indexOf('('))).sort();
 assert.deepEqual(tables,contractTables);assert.deepEqual(functions,contractFunctions);
});
function makeRunnerFixture(){
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'campuspay-runner-'));
 fs.mkdirSync(path.join(root,'scripts'),{recursive:true});fs.mkdirSync(path.join(root,'database/migrations'),{recursive:true});
 fs.copyFileSync(QUALIFIED_REPO+'/scripts/migrate.mjs',path.join(root,'scripts/migrate.mjs'));
 for(const m of [...CONTRACT.baselineMigrations,...CONTRACT.pendingMigrations])fs.copyFileSync(QUALIFIED_REPO+'/database/migrations/'+m.version+'.sql',path.join(root,'database/migrations',m.version+'.sql'));
 for(const [name,version] of Object.entries(CONTRACT.criticalDependencies)){
  const dir=path.join(root,'node_modules',name);writeDependencyPackage(dir,name,version);
  if(name==='pg'){
   fs.mkdirSync(path.join(dir,'lib'),{recursive:true});
   const baseline=JSON.stringify(CONTRACT.baselineMigrations.map(x=>({version:x.version})));
   const source="const BASELINE="+baseline+";\n"+
    "class Client {\n"+
    " constructor(){this.log=[];Client.instances.push(this)}\n"+
    " async connect(){this.log.push('CONNECT')}\n"+
    " async query(text,params){this.log.push(text);"+
    "if(text.includes('owner_access'))return {rows:[{owner_access:true}]};"+
    "if(text.includes(\"to_regclass('private.schema_migrations')\"))return {rows:[{relation:'private.schema_migrations'}]};"+
    "if(text==='select version from private.schema_migrations order by version')return {rows:BASELINE};"+
    "if(text.includes(\"rolname='campuspay_runtime'\"))return {rows:[{rolcanlogin:false,rolsuper:false,rolcreatedb:false,rolcreaterole:false}]};"+
    "if(text.includes(\"has_table_privilege('campuspay_runtime'\"))return {rowCount:0,rows:[]};"+
    "if(text.includes(\"has_schema_privilege('campuspay_runtime','api','USAGE')\"))return {rows:[{usage:true,execute:true}]};"+
    "if(Client.failText&&text===Client.failText)throw new Error('SYNTHETIC_MIGRATION_FAILURE');return {rows:[],rowCount:0}}\n"+
    " async end(){this.log.push('END')}\n"+
    "}\nClient.instances=[];Client.failText=null;module.exports={Client};\n";
   fs.writeFileSync(path.join(dir,'lib/index.js'),source);
  }
 }
 return root;
}
async function loadFixturePg(root){const {createRequire}=await import('node:module');return createRequire(path.join(root,'scripts/migrate.mjs'))('pg');}
test('same-connection runner keeps preflight/first-DDL/postflight ordered and preserves per-migration transactions',async()=>{
 const root=makeRunnerFixture(),oldCwd=process.cwd(),oldExit=process.exitCode,oldUrl=process.env.DATABASE_URL_UNPOOLED,oldHost=process.env.EXPECTED_DATABASE_HOST;try{
  process.chdir(root);process.exitCode=undefined;process.env.DATABASE_URL_UNPOOLED='postgresql://campuspay_owner:synthetic@localhost:5432/campuspay?sslmode=verify-full';process.env.EXPECTED_DATABASE_HOST='localhost';const pg=await loadFixturePg(root);const seen=[];let client;
  const result=await invokeQualifiedRunner({pg,root,before:async c=>{client=c;seen.push(['before',c]);return {synthetic:true};},beforeFirstDDL:async c=>seen.push(['firstDDL',c]),after:async c=>{seen.push(['after',c]);return {ok:true};}});
  assert.deepEqual(result,{ok:true});assert.equal(seen.length,3);assert.ok(seen.every(([,c])=>c===client));
  const log=client.log,firstDDL=log.indexOf('create schema if not exists private');assert.ok(log.indexOf('select pg_advisory_lock(84632291)')>=0);assert.ok(firstDDL>log.indexOf('select pg_advisory_lock(84632291)'));
  const pending=CONTRACT.pendingMigrations.map(m=>fs.readFileSync(path.join(root,'database/migrations',m.version+'.sql'),'utf8'));
  for(const sql of pending){const i=log.indexOf(sql);assert.ok(i>firstDDL);assert.equal(log[i-1],'begin');assert.equal(log[i+2],'commit');}
 }finally{process.chdir(oldCwd);process.exitCode=oldExit;if(oldUrl===undefined)delete process.env.DATABASE_URL_UNPOOLED;else process.env.DATABASE_URL_UNPOOLED=oldUrl;if(oldHost===undefined)delete process.env.EXPECTED_DATABASE_HOST;else process.env.EXPECTED_DATABASE_HOST=oldHost;fs.rmSync(root,{recursive:true});}
});
test('forced second-migration failure stops at the committed prefix with no retry and no successful postflight',async()=>{
 const root=makeRunnerFixture(),oldCwd=process.cwd(),oldExit=process.exitCode,oldUrl=process.env.DATABASE_URL_UNPOOLED,oldHost=process.env.EXPECTED_DATABASE_HOST;try{
  process.chdir(root);process.exitCode=undefined;process.env.DATABASE_URL_UNPOOLED='postgresql://campuspay_owner:synthetic@localhost:5432/campuspay?sslmode=verify-full';process.env.EXPECTED_DATABASE_HOST='localhost';const pg=await loadFixturePg(root),second=fs.readFileSync(path.join(root,'database/migrations',CONTRACT.pendingMigrations[1].version+'.sql'),'utf8');pg.Client.failText=second;let afterCalled=false;
  await assert.rejects(invokeQualifiedRunner({pg,root,before:async()=>({synthetic:true}),beforeFirstDDL:async()=>{},after:async()=>{afterCalled=true;return {ok:true};}}),/RUNNER_OR_POSTFLIGHT_INCOMPLETE/);
  const log=pg.Client.instances[0].log,first=fs.readFileSync(path.join(root,'database/migrations',CONTRACT.pendingMigrations[0].version+'.sql'),'utf8'),third=fs.readFileSync(path.join(root,'database/migrations',CONTRACT.pendingMigrations[2].version+'.sql'),'utf8');
  assert.equal(log.filter(x=>x===first).length,1);assert.equal(log.filter(x=>x===second).length,1);assert.equal(log.includes(third),false);assert.equal(log.filter(x=>x==='rollback').length,1);assert.equal(afterCalled,false);
 }finally{process.chdir(oldCwd);process.exitCode=oldExit;if(oldUrl===undefined)delete process.env.DATABASE_URL_UNPOOLED;else process.env.DATABASE_URL_UNPOOLED=oldUrl;if(oldHost===undefined)delete process.env.EXPECTED_DATABASE_HOST;else process.env.EXPECTED_DATABASE_HOST=oldHost;fs.rmSync(root,{recursive:true});}
});

test('Windows review launcher runs Node/Python test workloads only inside Linux Docker and keeps qualified tools volume read-only',()=>{
 const s=fs.readFileSync(new URL('./campuspay-review-tests-gitbash.sh',import.meta.url),'utf8');
 assert.match(s,/for binary in git docker cygpath;/);
 assert.doesNotMatch(s,/for binary in git node python3 docker/);
 assert.doesNotMatch(s,/^\s*export MSYS_NO_PATHCONV=1$/m);
 assert.match(s,/dkr\(\) \{ MSYS_NO_PATHCONV=1 docker "\$@"; \}/);
 assert.match(s,/repo_native="\$\(cygpath -m "\$repo"\)"/);
 assert.match(s,/git -C "\$repo_native" rev-parse HEAD/);
 assert.match(s,/Preflight: verifying Bash, Python and vendored pexpect inside pinned Linux image/);
 assert.match(s,/command -v bash/);assert.match(s,/command -v python3/);assert.match(s,/pexpect.__version__/);
 assert.match(s,/dkr run --rm --pull never -i --network none --log-driver none[\s\S]*--entrypoint node "\$test_image" - \/workspace\/review <<'PACKAGE_LOCKS'/);
 assert.match(s,/dkr run --rm --pull never -i --network none --log-driver none[\s\S]*--entrypoint node "\$test_image" - \/workspace\/native-results\.json \/workspace\/failure-results\.json "\$expected_failure_cases" <<'NATIVE_RESULTS'/);
 assert.match(s,/Running guard\/evidence suite inside pinned Linux Node/);
 assert.match(s,/Running complete 30-scenario shell matrix inside pinned Linux Docker/);
 assert.match(s,/expected_guard_tests=84/);assert.match(s,/expected_shell_cases=30/);assert.match(s,/expected_failure_cases=6/);
 assert.match(s,/# cancelled 0/);assert.match(s,/# skipped 0/);assert.match(s,/r\.expectedCaseCount!==expected/);
 assert.match(s,/export_available_failure_logs/);
 assert.match(s,/retaining labelled test volume/);
 assert.match(s,/failure-export/);
 assert.match(s,/--mount "type=volume,src=\$backup_volume,dst=\/qualified,readonly"/);
 assert.match(s,/--network none/);
 assert.match(s,/campuspay\.purpose=cutover-review-tests/);
 assert.match(s,/campuspay\.purpose=cutover-synthetic-validation/);
 const parallel=fs.readFileSync(new URL('./shell-suite-parallel.py',import.meta.url),'utf8');
 assert.match(parallel,/aggregate\['expectedCaseCount'\]=len\(cases\)/);
 assert.match(parallel,/aggregate\['cancelled'\]/);
 for(const name of ['shell.test.py','shell-suite-parallel.py','native-rehearsal.py'])assert.match(fs.readFileSync(new URL('./'+name,import.meta.url),'utf8'),/LINUX_CONTAINER_REQUIRED/);
});

test('privileged membership synthetic mutation uses postgres control connection while migrations remain campuspay_owner',()=>{
 const s=fs.readFileSync(new URL('./synthetic-failures.mjs',import.meta.url),'utf8');
 assert.match(s,/mutate:async\(_c,ctl\)=>ctl\.query\('grant pg_execute_server_program to campuspay_runtime_login'\)/);
 assert.match(s,/undo:async\(_c,ctl\)=>ctl\.query\('revoke pg_execute_server_program from campuspay_runtime_login'\)/);
 assert.match(s,/await scenario\.mutate\(c,control\)/);
 assert.match(s,/await scenario\.undo\(c,control\)/);
 assert.match(s,/const url='postgresql:\/\/campuspay_owner@localhost:5432\/'\+db\+'\?sslmode=disable'/);
 assert.doesNotMatch(s,/mutate:async c=>c\.query\('grant pg_execute_server_program/);
 assert.match(s,/expectedCaseCount:cases\.length,passed:results\.length,failed:0,skipped:0,cancelled:0/);
 const native=fs.readFileSync(new URL('./synthetic-native.mjs',import.meta.url),'utf8');
 assert.match(native,/expectedCaseCount:1,passed:1,failed:0,skipped:0,cancelled:0/);
});

// These fixtures expose public entries while hiding package.json, matching the
// exports boundary responsible for the real pg-connection-string failure.
test('dependency metadata need not be exported when public entry and package identity match',async()=>{
 const root=makeDependencyRoot();try{
  const {createRequire}=await import('node:module'),req=createRequire(path.join(root,'node_modules/pg/lib/index.js'));
  assert.throws(()=>req.resolve('pg-connection-string/package.json'),{code:'ERR_PACKAGE_PATH_NOT_EXPORTED'});
  verifyDependencyIntegrity(root);
 }finally{fs.rmSync(root,{recursive:true});}
});
const invalidDependencyFixtures={
 'wrong package name':(root,dir)=>{const f=path.join(dir,'package.json'),p=JSON.parse(fs.readFileSync(f));p.name='impostor';fs.writeFileSync(f,JSON.stringify(p));},
 'missing metadata':(root,dir)=>fs.unlinkSync(path.join(dir,'package.json')),
 'invalid metadata':(root,dir)=>fs.writeFileSync(path.join(dir,'package.json'),'{invalid'),
 'metadata symlink':(root,dir)=>{fs.renameSync(path.join(dir,'package.json'),path.join(dir,'identity.json'));fs.symlinkSync('identity.json',path.join(dir,'package.json'));},
 'escaping public main':(root,dir)=>{const f=path.join(dir,'package.json'),p=JSON.parse(fs.readFileSync(f));delete p.exports;p.main='../../outside.js';fs.writeFileSync(f,JSON.stringify(p));fs.writeFileSync(path.join(root,'outside.js'),'module.exports={}');},
 'escaping entry symlink':(root,dir)=>{const outside=path.join(root,'outside.js');fs.writeFileSync(outside,'module.exports={}');fs.unlinkSync(path.join(dir,'index.js'));fs.symlinkSync(outside,path.join(dir,'index.js'));},
 'missing public entry':(root,dir)=>fs.unlinkSync(path.join(dir,'index.js')),
 'shadow beside actual importer entry':root=>writeDependencyPackage(path.join(root,'node_modules/pg/lib/node_modules/pg-connection-string'),'pg-connection-string'),
 'nested metadata boundary':(root,dir)=>{const p=JSON.parse(fs.readFileSync(path.join(dir,'package.json')));p.exports={'.':'./dist/index.js'};fs.writeFileSync(path.join(dir,'package.json'),JSON.stringify(p));writeDependencyPackage(path.join(dir,'dist'),'pg-connection-string');},
 'changed pg public entry':root=>{const dir=path.join(root,'node_modules/pg'),p=JSON.parse(fs.readFileSync(path.join(dir,'package.json')));p.exports={'.':'./lib/alternate.js'};fs.writeFileSync(path.join(dir,'package.json'),JSON.stringify(p));fs.writeFileSync(path.join(dir,'lib/alternate.js'),'module.exports={}');}
};
for(const [name,mutate] of Object.entries(invalidDependencyFixtures))test('dependency public resolution rejects '+name,()=>{
 const root=makeDependencyRoot();try{mutate(root,path.join(root,'node_modules/pg-connection-string'));assert.throws(()=>verifyDependencyIntegrity(root));}
 finally{fs.rmSync(root,{recursive:true});}
});
test('all fourteen contracted import edges reject a resolvable nested shadow',()=>{
 let edges=0;
 for(const [importer,deps] of Object.entries(CONTRACT.criticalDependencyImports))for(const name of Object.keys(deps)){
  const root=makeDependencyRoot();try{
   const importerDir=importer==='$runner'?path.join(root,'scripts'):path.join(root,'node_modules',importer,importer==='pg'?'lib':'');
   writeDependencyPackage(path.join(importerDir,'node_modules',name),name);
   assert.throws(()=>verifyDependencyIntegrity(root),/DEPENDENCY_(RESOLUTION_CHANGED|PATH_UNSAFE)/,importer+' -> '+name);edges++;
  }finally{fs.rmSync(root,{recursive:true});}
 }
 assert.equal(edges,14);
});
