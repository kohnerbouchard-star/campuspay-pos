# Disposable, network-none PostgreSQL rehearsal. Never accepts a database URL.
from pathlib import Path
import json,os,subprocess,tempfile,tarfile,time,uuid,hashlib
if os.name=='nt': raise SystemExit('LINUX_CONTAINER_REQUIRED')
here=Path(__file__).resolve().parent
repo=Path(os.environ.get('CAMPUSPAY_QUALIFIED_REPO','/workspace/campuspay-pos')).resolve()
tools_volume=os.environ.get('CAMPUSPAY_TOOLS_VOLUME','campuspay-tools-91ead009-8c77-49a7-9995-653bae46984e')
node_image='node@sha256:43ac6c60b8f89723f746e8a92ce91abd5017e627ce1ddfe4238355d3a30b772c'
pg_image='postgres@sha256:639ab7ceb90e13123085b741fb31ef493fba25463002f6da665352e7b534b652'
name='campuspay-cutover-test-'+uuid.uuid4().hex[:16]
label='campuspay.purpose=cutover-synthetic-validation'
work=Path(tempfile.mkdtemp(prefix='campuspay-native-review-'))
def run(args,**kw):return subprocess.run(args,check=True,**kw)
def output(args):return subprocess.check_output(args,text=True).strip()
assert output(['git','-C',str(repo),'rev-parse','HEAD'])=='4e55ece88cb0afcc3e85c8f0436f8d346f5c40a1'
assert output(['git','-C',str(repo),'rev-parse','HEAD^{tree}'])=='25041b33225b68a95b8f54d8e59e23b0cd624e3e'
assert output(['git','-C',str(repo),'status','--porcelain'])==''
for image in [node_image,pg_image]:run(['docker','image','inspect',image],stdout=subprocess.DEVNULL)
archive=work/'source.tar'
with archive.open('wb') as out:run(['git','-C',str(repo),'-c','core.autocrlf=false','-c','core.eol=lf','archive','--format=tar','HEAD'],stdout=out)
review_archive=work/'review.tar'
with tarfile.open(review_archive,'w') as t:
 for f in ['core.mjs','contract.json','driver.mjs','synthetic-native.mjs','synthetic-failures.mjs']:
  t.add(here/f,arcname='.cutover/'+f)
container=False;volume=False;completed=False
try:
 assert output(['docker','volume','inspect','--format','{{index .Labels "campuspay.purpose"}}',tools_volume])=='manual-backup-preparation'
 run(['docker','volume','create','--label',label,name],stdout=subprocess.DEVNULL);volume=True
 with archive.open('rb') as f:run(['docker','run','--rm','--pull','never','--network','none','--log-driver','none','-i','--mount','type=volume,src='+name+',dst=/work','--entrypoint','sh',node_image,'-ceu','tar -xf - -C /work'],stdin=f)
 with review_archive.open('rb') as f:run(['docker','run','--rm','--pull','never','--network','none','--log-driver','none','-i','--mount','type=volume,src='+name+',dst=/work','--entrypoint','sh',node_image,'-ceu','tar -xf - -C /work'],stdin=f)
 run(['docker','run','--rm','--pull','never','--network','none','--log-driver','none','--mount','type=volume,src='+name+',dst=/work','--mount','type=volume,src='+tools_volume+',dst=/qualified,readonly','--entrypoint','sh',node_image,'-ceu','test -d /qualified/node_modules/pg; cp -a /qualified/node_modules /work/node_modules; mkdir -p /work/.tools; cp /usr/local/bin/node /work/.tools/node'])
 run(['docker','run','--detach','--pull','never','--network','none','--log-driver','none','--name',name,'--label',label,'--mount','type=volume,src='+name+',dst=/work','--tmpfs','/var/lib/postgresql/data:rw,nosuid,nodev,size=2147483648','--env','POSTGRES_HOST_AUTH_METHOD=trust',pg_image],stdout=subprocess.DEVNULL);container=True
 ready=False
 for _ in range(30):
  if subprocess.run(['docker','exec',name,'pg_isready','-h','localhost','-U','postgres','-d','postgres'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0:ready=True;break
  time.sleep(1)
 assert ready
 for script,log in [('synthetic-native.mjs','native.log'),('synthetic-failures.mjs','failures.log')]:
  with (here/log).open('w') as f:run(['docker','exec','--workdir','/work',name,'/work/.tools/node','/work/.cutover/'+script],stdout=f,stderr=subprocess.STDOUT)
 for f in ['native-results.json','failure-results.json']:run(['docker','cp',name+':/work/.cutover/'+f,str(here/f)])
 inspection=json.loads(output(['docker','inspect',name]))[0]
 assert inspection['HostConfig']['NetworkMode']=='none' and not inspection['HostConfig']['PortBindings']
 assert '/var/lib/postgresql/data' in inspection['HostConfig']['Tmpfs']
 completed=True
finally:
 if container:
  assert output(['docker','inspect','--format','{{index .Config.Labels "campuspay.purpose"}}',name])=='cutover-synthetic-validation'
  run(['docker','rm','-f',name],stdout=subprocess.DEVNULL)
 if volume:
  assert output(['docker','volume','inspect','--format','{{index .Labels "campuspay.purpose"}}',name])=='cutover-synthetic-validation'
  run(['docker','volume','rm',name],stdout=subprocess.DEVNULL)
 proof={'syntheticOnly':True,'productionAccessed':False,'completed':completed,'container':name,'containerRemoved':container,'volumeRemoved':volume,'network':'none','publishedPorts':[],'pgdata':'tmpfs','nodeImage':node_image,'postgresImage':pg_image,'coreSHA256':hashlib.sha256((here/'core.mjs').read_bytes()).hexdigest(),'qualifiedRunnerSHA256':hashlib.sha256((repo/'scripts/migrate.mjs').read_bytes()).hexdigest(),'qualifiedRepo':str(repo),'toolsVolume':tools_volume}
 (here/'native-environment.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(proof,indent=2))
