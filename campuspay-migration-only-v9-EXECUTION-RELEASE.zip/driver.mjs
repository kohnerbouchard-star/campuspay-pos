// Approved database-only scope. No promotion, firewall mutation, or production restore.
import {validateExecutionRelease} from './execution-release.mjs';
import fs from 'node:fs';import path from 'node:path';import tls from 'node:tls';import {fileURLToPath} from 'node:url';
import {CONTRACT,stop,sha,verifySource,beforeMigration,afterMigration,invokeQualifiedRunner} from './core.mjs';
const HOST='ep-broad-tooth-az9zz1z8.c-3.ap-southeast-1.aws.neon.tech';
const STAGED='dpl_TUjLdvRW2DTuBAyoAmqUKQSoyWzy';
const LIVE='dpl_3brN53nacbuaDiT1JMLtYzAKGhKQ';
const AUTH_DENIAL_REF='User confirmation Sentinel_ec948eadb46c81918c0420e562244bae, relayed by parent on 2026-10-06';
export function validateHold(e,now=Date.now()){
 if(e?.projectId!=='prj_wXkpTGGYjL6emMhAX6RSwxkafkME'||e.teamId!=='team_PRsNkw4DHrGsUHl6ikKw2XyJ'||e.candidate!==CONTRACT.candidate||e.deploymentId!==STAGED||e.liveDeploymentId!==LIVE||e.ruleName!=='CampusPay maintenance'||e.ruleId!=='rule_campus_pay_maintenance_9bJUPi'||e.configVersion!==3||e.firstActiveUnrestrictedDeny!==true||e.unreviewedDraftCount!==0||e.otherWritersStopped!==true||e.approvedDomainInventoryVerified!==true||e.noRollingRelease!==true||e.noPendingPromotion!==true||e.noConcurrentDeployment!==true||e.protectionScope!=='all_except_custom_domains'||e.publicMicaDenied!==4||!Number.isInteger(e.generatedDenied)||!Number.isInteger(e.generatedSsoBeforeWaf)||e.generatedDenied+e.generatedSsoBeforeWaf!==8||e.redirectsFollowed!==false||e.authenticationOrBypassUsed!==false||e.authenticatedCandidateDeniedEvidence!==AUTH_DENIAL_REF||!Number.isFinite(Date.parse(e.checkedAt))||Date.parse(e.checkedAt)>now||now-Date.parse(e.checkedAt)>5*60*1000)stop('FULL_HOLD_PROOF_INVALID_OR_STALE');
}
export function reserveAttemptUnderFreshHold(backupDir,record,hold,now=Date.now()){
 validateHold(hold,now);reserveAttempt(backupDir,record);
}
export function sourceURL(password){
 if(typeof password!=='string'||!password||/[\r\n\0]/.test(password))stop('OWNER_PASSWORD_FORMAT');
 const u=new URL('postgresql://'+HOST+':5432/campuspay?sslmode=verify-full');u.username='campuspay_owner';u.password=encodeURIComponent(password);return u.href;
}
export function validateKey(key){if(typeof key!=='string'||!/^[A-Za-z0-9+/]{43}=$/.test(key)||Buffer.from(key,'base64').length!==32||Buffer.from(key,'base64').toString('base64')!==key)stop('BACKUP_KEY_FORMAT');}
export function validateBackupProof(proof,backupRun){
 if(!/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/.test(backupRun||''))stop('RUN_IDENTIFIER_INVALID');
 if(proof?.run!==backupRun||proof.host!==HOST||proof.database!=='campuspay')stop('BACKUP_TARGET_MISMATCH');
 if(proof.file!=='campuspay-pre-cutover-'+backupRun+'.cpbackup'||!Number.isSafeInteger(proof.bytes)||proof.bytes<1||proof.bytes>64*1024*1024||!/^[a-f0-9]{64}$/.test(proof.sha256||''))stop('BACKUP_ARCHIVE_IDENTITY_INVALID');
}
export function readRegularFile(file,limit){
 const fd=fs.openSync(file,fs.constants.O_RDONLY|fs.constants.O_NOFOLLOW);
 try{
  const s=fs.fstatSync(fd);
  if(!s.isFile()||s.nlink!==1||s.size>limit)stop('EVIDENCE_FILE_NOT_REGULAR_OR_TOO_LARGE');
  return fs.readFileSync(fd);
 }finally{fs.closeSync(fd);}
}
export function reserveAttempt(backupDir,record){
 const file=backupDir+'/cutover-attempt.json';let fd;
 try{fd=fs.openSync(file,'wx',0o600);}catch(e){if(e.code==='EEXIST')stop('BACKUP_ALREADY_USED_FOR_APPLY_REVIEW_REQUIRED');throw e;}
 try{fs.writeFileSync(fd,JSON.stringify(record)+'\n');fs.fsyncSync(fd);}finally{fs.closeSync(fd);}
 const directory=fs.openSync(backupDir,'r');try{fs.fsyncSync(directory);}finally{fs.closeSync(directory);}
}
export async function main(){
 validateExecutionRelease();
 const [backupRun,applyRun]=process.argv.slice(2);
 if(![backupRun,applyRun].every(x=>/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/.test(x||'')))stop('RUN_IDENTIFIER_INVALID');
 const root='/work',backupDir=root+'/.operator-backup/'+backupRun,out=root+'/.operator-cutover/'+applyRun+'/result';
 verifySource(root);
 const input=JSON.parse(fs.readFileSync(0,'utf8'));
 if(input.approval!=='APPLY ONLY THE FIVE CAMPUSPAY MIGRATIONS')stop('EXPLICIT_APPLY_APPROVAL_MISSING');
 validateKey(input.key);validateHold(input.hold);
 const {validateReviewedMigration,validateMigrationBackup,evidenceHash}=await import('./migration-evidence.mjs');
 validateReviewedMigration(input.evidence);
 if(fs.realpathSync(backupDir)!==backupDir||fs.realpathSync(out)!==out||fs.readdirSync(out).length)stop('OPERATOR_DIRECTORY_NOT_FRESH_OR_LINKED');
 if(fs.existsSync(backupDir+'/cutover-attempt.json'))stop('BACKUP_ALREADY_USED_FOR_APPLY_REVIEW_REQUIRED');
 const proof=JSON.parse(readRegularFile(backupDir+'/verified-backup.json',1024*1024));
 validateBackupProof(proof,backupRun);
 if(evidenceHash(proof)!==evidenceHash(input.evidence.backup))stop('LINUX_BACKUP_PROOF_DIFFERS_FROM_REVIEW');
 validateMigrationBackup(proof);
 const archive=readRegularFile(backupDir+'/'+proof.file,64*1024*1024);
 if(archive.length!==proof.bytes||archive.length>64*1024*1024||sha(archive)!==proof.sha256)stop('BACKUP_BYTES_MISMATCH');
 // Pin qualified encryption logic separately; it is the only backup implementation imported here.
 if(sha(fs.readFileSync(root+'/scripts/lib/backup-envelope.mjs'))!=='eff9eb9d44a8d4f0a15b514df196971a1a5f1e8e6c2ccf9c8cdcf09f0d6f3c86')stop('BACKUP_ENVELOPE_TOOL_CHANGED');
 const {openBackup}=await import(root+'/scripts/lib/backup-envelope.mjs');
 const {metadata}=openBackup(archive,input.key);if(metadata.database!=='campuspay')stop('BACKUP_DATABASE_MISMATCH');
 const {default:pg}=await import(root+'/node_modules/pg/lib/index.js');
 process.env.DATABASE_URL_UNPOOLED=sourceURL(input.ownerPassword);process.env.EXPECTED_DATABASE_HOST=HOST;
 let starting=false;
 try{
  const result=await invokeQualifiedRunner({pg,root,before:async c=>{
   validateHold(input.hold);
   const identity=(await c.query("select current_database() as db,current_user as role")).rows[0];
   if(identity.db!=='campuspay'||identity.role!=='campuspay_owner')stop('DATABASE_IDENTITY_MISMATCH');
   const socket=c.connection?.stream,peer=socket?.getPeerCertificate?.();
   const hostnameVerified=Boolean(peer&&Object.keys(peer).length&&tls.checkServerIdentity(HOST,peer)===undefined);
   if(socket?.encrypted!==true)stop('CLIENT_TLS_NOT_ENCRYPTED');
   if(socket?.authorized!==true)stop('CLIENT_CERTIFICATE_NOT_AUTHORIZED');
   if(socket?.servername!==HOST||hostnameVerified!==true)stop('CLIENT_HOSTNAME_NOT_VERIFIED');
   return beforeMigration(c,metadata);
  },beforeFirstDDL:async()=>{
   // Re-check the same externally collected hold evidence after all lock-held preflight.
   // If it aged out, stop before reserving the attempt and before the first DDL.
   const started={candidate:CONTRACT.candidate,backupRun,applyRun,backupSHA256:proof.sha256,holdCheckedAt:input.hold.checkedAt,stage:'APPROVED_APPLY_STARTED_UNDER_FRESH_HOLD',startedAt:new Date().toISOString()};
   reserveAttemptUnderFreshHold(backupDir,started,input.hold);starting=true;
   fs.writeFileSync(out+'/apply-started.json',JSON.stringify(started)+'\n',{flag:'wx',mode:0o600});
  },after:afterMigration});
  const complete={...result,candidate:CONTRACT.candidate,tree:CONTRACT.tree,backupRun,applyRun,backupSHA256:proof.sha256,verifiedAt:new Date().toISOString(),promotionPerformed:false};
  fs.writeFileSync(out+'/database-postflight.json',JSON.stringify(complete,null,2)+'\n',{flag:'wx',mode:0o600});console.log(JSON.stringify(complete,null,2));
 }catch(e){
  if(starting)fs.writeFileSync(out+'/apply-needs-review.json',JSON.stringify({candidate:CONTRACT.candidate,backupRun,applyRun,stage:'KEEP_FULL_HOLD_INSPECT_HISTORY_BEFORE_RETRY',code:/^[A-Z_]+$/.test(e?.message||'')?e.message:'APPLY_OR_POSTFLIGHT_FAILED'})+'\n',{flag:'wx',mode:0o600});
  throw e;
 }finally{delete process.env.DATABASE_URL_UNPOOLED;delete process.env.EXPECTED_DATABASE_HOST;}
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url))main().catch(e=>{console.error('STOP: '+(/^[A-Z_]+$/.test(e?.message||'')?e.message:'CUTOVER_FAILED')+'. Keep full maintenance. No promotion was requested.');process.exitCode=1;});
