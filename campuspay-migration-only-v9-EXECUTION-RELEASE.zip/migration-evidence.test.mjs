import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import {POLICY,evidenceHash,validatePolicy,validateReviewedMigration,verifyInputDirectory,verifyRetainedCopies} from './migration-evidence.mjs';import {fixture} from './migration-fixtures.mjs';
const clone=()=>structuredClone(POLICY),good=()=>({backup:clone().backup,policySHA256:evidenceHash(POLICY),retentionReview:clone().retentionReview,scope:'DATABASE_ONLY_KEEP_FULL_MAINTENANCE'});
test('known backup and historical recovery accepted without pretending app configuration is qualified',()=>{validateReviewedMigration(good());assert.equal(POLICY.deploymentConfigurationQualified,false);assert.equal(POLICY.retentionReview.driveMD5,null);assert.equal(POLICY.retentionReview.keyRetrievalEventTime,null);});
for(const [name,edit] of Object.entries({disabled:p=>p.status='DRAFT',candidate:p=>p.candidate='other',tree:p=>p.tree='other',action:p=>p.action='PROMOTE',promotion:p=>p.promotionIncluded=true,maintenance:p=>p.maintenanceRequired=false,configClaim:p=>p.deploymentConfigurationQualified=true,missingMigration:p=>p.pendingMigrations.pop(),changedMigration:p=>p.pendingMigrations[0].sha256='a'.repeat(64),missingApproval:p=>p.approvalReferences=[],unprovedKey:p=>p.retentionReview.savedKeySeparatelyRetrievedAndRestorePassed=false,inventedTimestamp:p=>p.retentionReview.keyRetrievalEventTime='2026-10-06T00:00:00Z',inventedMD5:p=>p.retentionReview.driveMD5='a'.repeat(32),wrongDrive:p=>p.retentionReview.driveFileId='other'}))test('scope gate rejects '+name,()=>{const p=clone();edit(p);assert.throws(()=>validatePolicy(p));});
for(const [name,edit] of Object.entries({wrongHash:e=>e.backup.sha256='b'.repeat(64),wrongSize:e=>e.backup.bytes++,wrongRun:e=>e.backup.run='11111111-1111-4111-8111-111111111111',wrongHost:e=>e.backup.host='localhost',restoreFailed:e=>e.backup.restore.integrity='unknown',directGrants:e=>e.backup.restore.runtime_direct_table_grants=1,sourceChanged:e=>e.backup.sourceStillMatchesBackup=false,missingTable:e=>e.backup.tables=56,revisedStage:e=>e.backup.stage='READY',wrongPolicy:e=>e.policySHA256='c'.repeat(64),wrongScope:e=>e.scope='DEPLOY',changedHistory:e=>e.retentionReview.backupTranscript='other'}))test('evidence gate rejects '+name,()=>{const e=good();edit(e);assert.throws(()=>validateReviewedMigration(e));});
test('both retained byte copies required; links, same-file aliases, corruption and truncation fail',()=>{
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'campuspay-migration-evidence-'));
 try{const f=fixture(root+'/fixture');assert.deepEqual(verifyInputDirectory(f.evidence,f.original,f.download,f.policy),f.e);
 assert.throws(()=>verifyRetainedCopies(f.original,f.original,f.e.backup));
 const original=fs.readFileSync(f.download);fs.writeFileSync(f.download,original.subarray(0,-1));assert.throws(()=>verifyRetainedCopies(f.original,f.download,f.e.backup));
 fs.writeFileSync(f.download,original);original[10]^=1;fs.writeFileSync(f.download,original);assert.throws(()=>verifyRetainedCopies(f.original,f.download,f.e.backup));
 fs.unlinkSync(f.download);fs.symlinkSync(f.original,f.download);assert.throws(()=>verifyRetainedCopies(f.original,f.download,f.e.backup));fs.unlinkSync(f.download);
 fs.linkSync(f.original,f.download);assert.throws(()=>verifyRetainedCopies(f.original,f.download,f.e.backup));
 }finally{fs.rmSync(root,{recursive:true,force:true});}
});
const {RELEASE,validateExecutionRelease}=await import('./execution-release.mjs');
test('shipped execution release remains disabled pending independent review',()=>assert.throws(()=>validateExecutionRelease(RELEASE),/INDEPENDENT_PACKAGE_REVIEW_NOT_COMPLETED/));
test('review release is scoped, dated and attributed',()=>{
 const r={...RELEASE,status:'REVIEWED_FOR_EXECUTION',reviewReference:'SYNTHETIC TEST ONLY',reviewedAt:'2026-10-07T00:00:00Z'};validateExecutionRelease(r);
 for(const patch of [{candidate:'other'},{tree:'other'},{scope:'PROMOTE'},{reviewReference:null},{reviewedAt:null},{reviewedAt:'2999-01-01T00:00:00Z'},{status:'PENDING_INDEPENDENT_REVIEW'}])assert.throws(()=>validateExecutionRelease({...r,...patch}));
});
