// Sanitized, reviewed evidence only. No credentials, network, or database calls.
import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';
import {CONTRACT,sha,stop,validateRetention} from './core.mjs';
import {validateBackupProof} from './driver.mjs';
export const POLICY=JSON.parse(fs.readFileSync(new URL('./release-policy.json',import.meta.url)));
export const STAGED='dpl_TUjLdvRW2DTuBAyoAmqUKQSoyWzy',PROJECT='prj_wXkpTGGYjL6emMhAX6RSwxkafkME',TEAM='team_PRsNkw4DHrGsUHl6ikKw2XyJ';
export const HOST='ep-broad-tooth-az9zz1z8.c-3.ap-southeast-1.aws.neon.tech';
export const EVIDENCE_FILES={backup:'verified-backup.json',retention:'retention-proof.json',drive:'drive-object.json',config:'staged-config.json',approval:'cutover-approval.json'};
export const canonical=x=>Array.isArray(x)?'['+x.map(canonical).join(',')+']':x&&typeof x==='object'?'{'+Object.keys(x).sort().map(k=>JSON.stringify(k)+':'+canonical(x[k])).join(',')+'}':JSON.stringify(x);
export const evidenceHash=x=>sha(canonical(x));
const exact=(a,b,code)=>{if(canonical(a)!==canonical(b))stop(code);};
const timestamp=(v,now)=>Number.isFinite(Date.parse(v))&&Date.parse(v)<=now;
const keys=(obj,allowed)=>{if(!obj||typeof obj!=='object'||Array.isArray(obj)||Object.keys(obj).some(k=>!allowed.includes(k)))stop('UNREVIEWED_EVIDENCE_FIELD');};
export function readFile(file,limit=1024*1024){
 const s=fs.lstatSync(file);if(!s.isFile()||s.isSymbolicLink()||s.nlink!==1||s.size>limit)stop('EVIDENCE_NOT_REGULAR_OR_TOO_LARGE');
 return fs.readFileSync(file);
}
export function validateDrive(d,b,now=Date.now()){
 keys(d,['schema','driveFileId','folderId','ownerEmail','shared','ownerOnlyPermissionsVerified','trashed','name','bytes','md5Checksum','verifiedAt','evidenceReference']);
 if(d.schema!=='campuspay-drive-object-v1'||!/^[-_a-zA-Z0-9]{10,150}$/.test(d.driveFileId||'')||d.folderId!=='13JPQ-J6eEmzqRBrHoaqQpm4Xk80rsFI6'||d.ownerEmail!=='kohnerbouchard@gmail.com'||d.shared!==false||d.ownerOnlyPermissionsVerified!==true||d.trashed!==false||d.name!==b.file||d.bytes!==b.bytes||!/^[a-f0-9]{32}$/.test(d.md5Checksum||'')||!timestamp(d.verifiedAt,now)||typeof d.evidenceReference!=='string'||!d.evidenceReference.trim())stop('DRIVE_OBJECT_EVIDENCE_INVALID');
}
export function validateConfig(c,now=Date.now()){
 keys(c,['schema','projectId','teamId','deploymentId','candidate','tree','evidenceKind','runtimeDatabase','ownerDatabaseURLAbsent','staffOrigin','storeOrigin','secureHostOnlyCookies','existingSecretsPresentAndUnchanged','activationUnchanged','reviewedAt','evidenceReference']);
 if(c.schema!=='campuspay-staged-config-v1'||c.projectId!==PROJECT||c.teamId!==TEAM||c.deploymentId!==STAGED||c.candidate!==CONTRACT.candidate||c.tree!==CONTRACT.tree||c.evidenceKind!=='IMMUTABLE_DEPLOYMENT_CONFIGURATION_REVIEW'||c.ownerDatabaseURLAbsent!==true||c.staffOrigin!=='https://mica-pos.vercel.app'||c.storeOrigin!=='https://mica-store.vercel.app'||c.secureHostOnlyCookies!==true||c.existingSecretsPresentAndUnchanged!==true||c.activationUnchanged!==true||!timestamp(c.reviewedAt,now)||typeof c.evidenceReference!=='string'||!c.evidenceReference.trim())stop('IMMUTABLE_CONFIG_EVIDENCE_INVALID');
 exact(c.runtimeDatabase,{host:HOST,database:'campuspay',user:'campuspay_runtime_login',sslmode:'verify-full'},'IMMUTABLE_RUNTIME_DATABASE_MISMATCH');
}
export function validateApproval(a,e,now=Date.now()){
 keys(a,['schema','projectId','teamId','deploymentId','candidate','tree','action','backupRun','backupSHA256','pendingMigrations','backupRestoreReviewed','independentDriveDownloadReviewed','immutableConfigReviewed','exactCandidateCIReviewed','sameConnectionRunnerIntegrationReviewed','windowsWrapperReviewed','promotionIncluded','approvedAt','approvalReference']);
 if(a.schema!=='campuspay-cutover-approval-v1'||a.projectId!==PROJECT||a.teamId!==TEAM||a.deploymentId!==STAGED||a.candidate!==CONTRACT.candidate||a.tree!==CONTRACT.tree||a.action!=='APPLY ONLY THE FIVE CAMPUSPAY MIGRATIONS'||a.backupRun!==e.backup.run||a.backupSHA256!==e.backup.sha256||a.promotionIncluded!==false||!timestamp(a.approvedAt,now)||typeof a.approvalReference!=='string'||!a.approvalReference.trim())stop('CUTOVER_APPROVAL_EVIDENCE_INVALID');
 for(const k of ['backupRestoreReviewed','independentDriveDownloadReviewed','immutableConfigReviewed','exactCandidateCIReviewed','sameConnectionRunnerIntegrationReviewed','windowsWrapperReviewed'])if(a[k]!==true)stop('CUTOVER_REVIEW_INCOMPLETE');
 exact(a.pendingMigrations,CONTRACT.pendingMigrations.map(m=>m.version),'APPROVED_MIGRATIONS_MISMATCH');
}
export function validateReviewedRelease(e,policy=POLICY,now=Date.now()){
 if(policy.status!=='REVIEWED_FOR_APPROVED_FIVE_MIGRATIONS'||policy.candidate!==CONTRACT.candidate||policy.tree!==CONTRACT.tree)stop('RELEASE_POLICY_DISABLED_OR_MISMATCH');
 for(const key of Object.keys(EVIDENCE_FILES))if(!/^[a-f0-9]{64}$/.test(policy.evidenceHashes?.[key]||'')||evidenceHash(e[key])!==policy.evidenceHashes[key])stop('REVIEWED_EVIDENCE_HASH_MISMATCH');
 validateBackupProof(e.backup,e.backup.run);validateRetention(e.retention,e.backup,now);validateDrive(e.drive,e.backup,now);validateConfig(e.config,now);validateApproval(e.approval,e,now);
 if(e.retention.driveFileId!==e.drive.driveFileId)stop('RETAINED_DRIVE_OBJECT_MISMATCH');
 return e;
}
export async function verifyCiphertextCopies(original,download,b,drive){
 const a=fs.realpathSync(original),d=fs.realpathSync(download),as=fs.statSync(a),ds=fs.statSync(d);
 if(a===d||path.dirname(a)===path.dirname(d)||(as.dev===ds.dev&&as.ino===ds.ino))stop('DOWNLOAD_MUST_BE_DISTINCT_INDEPENDENT_FILE');
 const bytes=readFile(original,64*1024*1024),downloaded=readFile(download,64*1024*1024);
 for(const x of [bytes,downloaded])if(x.length!==b.bytes||sha(x)!==b.sha256||!x.subarray(0,8).equals(Buffer.from('CPBKP01\n')))stop('CIPHERTEXT_COPY_MISMATCH');
 // SHA-256 is the release invariant; Drive's actual binary-object MD5 also binds its metadata.
 return import('node:crypto').then(({createHash})=>{if(createHash('md5').update(downloaded).digest('hex')!==drive.md5Checksum)stop('DRIVE_OBJECT_CHECKSUM_MISMATCH');return {bytes:downloaded.length,sha256:sha(downloaded)};});
}
export async function collectRetention({backup,drive,original,download,independentDownloadConfirmed,keyRetrieval},now=Date.now()){
 validateBackupProof(backup,backup.run);validateDrive(drive,backup,now);
 if(independentDownloadConfirmed!==true)stop('INDEPENDENT_DRIVE_DOWNLOAD_CONFIRMATION_REQUIRED');
 const result=await verifyCiphertextCopies(original,download,backup,drive);
 const p={schema:'campuspay-retention-v1',candidate:CONTRACT.candidate,backupRun:backup.run,archive:backup.file,bytes:result.bytes,sha256:result.sha256,driveAccount:drive.ownerEmail,driveFolderId:drive.folderId,driveFileId:drive.driveFileId,independentDownloadConfirmed:true,downloadedSHA256:result.sha256,downloadedBytes:result.bytes,keyRetrieval,verifiedAt:new Date(now).toISOString()};
 validateRetention(p,backup,now);return p;
}
export async function verifyInputDirectory(dir,original,download){
 const e=Object.fromEntries(Object.entries(EVIDENCE_FILES).map(([k,name])=>[k,JSON.parse(readFile(path.join(dir,name)))]));
 validateReviewedRelease(e);await verifyCiphertextCopies(original,download,e.backup,e.drive);return e;
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const [mode,...args]=process.argv.slice(2);
 (async()=>{
  if(mode==='verify-inputs'&&args.length===3)console.log(JSON.stringify(await verifyInputDirectory(...args)));
  else if(mode==='collect-retention'&&args.length===6){
   const [proofFile,driveFile,original,download,keyRetrievalFile,out]=args;
   const confirmation=fs.readFileSync(0,'utf8').trim();
   const p=await collectRetention({backup:JSON.parse(readFile(proofFile)),drive:JSON.parse(readFile(driveFile)),original,download,keyRetrieval:JSON.parse(readFile(keyRetrievalFile)),independentDownloadConfirmed:confirmation==='I DOWNLOADED THIS FILE FROM THE APPROVED DRIVE OBJECT'});
   fs.writeFileSync(out,JSON.stringify(p,null,2)+'\n',{flag:'wx',mode:0o600});console.log('RETENTION_BYTES_MATCH_REVIEW_PENDING');
  }else stop('EVIDENCE_MODE_OR_ARGUMENTS_INVALID');
 })().catch(e=>{console.error('STOP: '+(/^[A-Z_]+$/.test(e?.message||'')?e.message:'EVIDENCE_CHECK_FAILED'));process.exitCode=1;});
}
