# Offline shell-matrix orchestrator. Runs the unchanged scenario logic in parallel shards.
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import json, os, subprocess, sys, tempfile
if os.name=='nt': raise SystemExit('LINUX_CONTAINER_REQUIRED')
root=Path(__file__).resolve().parent
cases=['release-disabled','check-only','success','inherited-export','inherited-allexport','inherited-both','source-changed','source-changed-late','tools-changed','policy-disabled','evidence-substituted','download-changed-late','log-only','hold-not-blocked','live-moved','pending-promotion','extra-domain','rolling-read-denied','rolling-active','concurrent-deployment','rule-changed-late','sso-bad-target','sso-bad-host','curl-exit23','decline','wrong-key','linux-draft-lock','migration-prefix-failure','evidence-export-failure','hold-lost-after','interrupted-apply']
work=Path(tempfile.mkdtemp(prefix='campuspay-shell-matrix-'))
workers=max(1,min(int(os.environ.get('CAMPUSPAY_SHELL_WORKERS','10')),len(cases)))
def run_case(name):
 out=work/(name+'.json')
 env={**os.environ,'CAMPUSPAY_SHELL_CASES':name,'CAMPUSPAY_SHELL_RESULTS_FILE':str(out)}
 p=subprocess.run([sys.executable,str(root/'shell.test.py')],env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=240)
 if p.returncode!=0:raise RuntimeError(json.dumps({'case':name,'exit':p.returncode,'stdoutTail':p.stdout[-2000:],'stderrTail':p.stderr[-2000:]}))
 data=json.loads(out.read_text());assert len(data['cases'])==1 and data['cases'][0]['scenario']==name and data['cases'][0]['passed'] is True
 return data
results={}
with ThreadPoolExecutor(max_workers=workers) as pool:
 futs={pool.submit(run_case,name):name for name in cases}
 for fut in as_completed(futs):
  name=futs[fut];results[name]=fut.result();print('PASS',name,flush=True)
base=results[cases[0]]
aggregate={k:v for k,v in base.items() if k!='cases'}
aggregate['scope']='CURRENT_COMPLETE_WRAPPER_MATRIX'
aggregate['parallelShards']=True
aggregate['workerCount']=workers
aggregate['cases']=[results[name]['cases'][0] for name in cases]
aggregate['expectedCaseCount']=len(cases)
aggregate['passed']=sum(1 for x in aggregate['cases'] if x.get('passed') is True)
aggregate['failed']=sum(1 for x in aggregate['cases'] if x.get('passed') is not True)
aggregate['skipped']=sum(1 for x in aggregate['cases'] if x.get('skipped') is True)
aggregate['cancelled']=sum(1 for x in aggregate['cases'] if x.get('cancelled') is True)
assert aggregate['expectedCaseCount']==31 and aggregate['passed']==31 and aggregate['failed']==0 and aggregate['skipped']==0 and aggregate['cancelled']==0
(root/'shell-results.json').write_text(json.dumps(aggregate,indent=2)+'\n')
print(json.dumps(aggregate,indent=2))
