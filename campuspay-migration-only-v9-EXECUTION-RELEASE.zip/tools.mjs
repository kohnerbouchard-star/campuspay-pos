import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import {fileURLToPath} from 'node:url';import {verifyDependencyIntegrity} from './core.mjs';
const HASHES = {
 'scripts/backup-database.mjs':'3da970bc01579d9ea3b86fc72a7aba4cd9915c5f516228fd179bc8baf72fba06',
 'scripts/lib/backup-envelope.mjs':'eff9eb9d44a8d4f0a15b514df196971a1a5f1e8e6c2ccf9c8cdcf09f0d6f3c86',
 'scripts/lib/atomic-backup-file.mjs':'311cc9b41e9ddc76a8b1e822263feff0c1b1083d16652bd361d8e510add1829d',
 'scripts/migrate.mjs':'3afa140679f99707c55558a4d4fe824bbe218db709a2400b84a77ddd172c07c1',
 'package.json':'2d5daf96fa8c28ebfbd3f6f6c7f285c13850bd33bbc27a055a082c9d4f7bfa8a',
 'package-lock.json':'da216298ab1bc018cd508b4ba5e6b4bd365f1c0a02c05ddb872975a1371f00c4'
};
const sha = value => crypto.createHash('sha256').update(value).digest('hex');
const stop = code => { throw new Error(code); };

export function verifyTools(root='/work') {
 verifyDependencyIntegrity(root);
 for(const [name,digest] of Object.entries(HASHES))if(sha(fs.readFileSync(path.join(root,name)))!==digest)stop('QUALIFIED_TOOL_MISMATCH');
 const h=crypto.createHash('sha256');
 for(const name of fs.readdirSync(path.join(root,'database/migrations')).filter(n=>n.endsWith('.sql')).sort()){
  h.update(name+'\0');h.update(fs.readFileSync(path.join(root,'database/migrations',name)));h.update('\0');
 }
 if(h.digest('hex')!=='37ef7e6ce150c5619649248472ce1c2301da0b138cdb42a847c4c10657488b92')stop('MIGRATION_SET_MISMATCH');
}

if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){try{verifyTools();console.log('QUALIFIED_TOOLS_VERIFIED');}catch{console.error('STOP: QUALIFIED_TOOLS_CHANGED');process.exitCode=1;}}
