#!/usr/bin/env bash
# Single 050 attempt. Full maintenance and stopped writers must already hold.
(
  set +x
  set +a
  set -euo pipefail
  umask 077
  unset DATABASE_URL_UNPOOLED EXPECTED_DATABASE_HOST VERCEL_TOKEN NODE_OPTIONS
  [ "$#" -eq 1 ] || { printf 'Usage: bash run.sh CLEAN_MERGED_CHECKOUT\n' >&2; exit 2; }
  for binary in node git cygpath; do command -v "$binary" >/dev/null || { printf 'STOP: missing %s\n' "$binary" >&2; exit 1; }; done
  [ "$(node -p 'process.versions.node.split(".")[0]')" = 22 ] || { printf 'STOP: Node 22 required\n' >&2; exit 1; }
  bundle="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
  source_native="$(cygpath -m "$1")"
  evidence="$(mktemp -d "$HOME/campuspay-stock050-direct.XXXXXXXX")"
  evidence_native="$(cygpath -m "$evidence")"
  printf 'Sanitized attempt evidence: %s\n' "$evidence_native"
  printf 'Full maintenance and stopped writers are required. This runs only stock 050, without a new backup.\n'
  printf 'campuspay_owner password (hidden): ' > /dev/tty
  IFS= read -r -s owner_password < /dev/tty
  export -n owner_password
  printf '\n' > /dev/tty
  printf '%s\n' "$owner_password" | node "$bundle/run-050.mjs" "$source_native" "$evidence_native"
  unset owner_password
)
