# CampusPay direct stock 050 operator command

This is a single migration attempt on merged commit `4e75bf8883df592fee52e9521ab18a0f0c706f5a`, tree `68adb211f5a71cf513eb34dde726244288e6cb13`. It performs **no new backup** as the operator requested. The retained older backup predates the five access migrations. Keep full maintenance and other writers stopped; this command does not change those controls.

The helper checks the exact clean source, all 37 historic migration hashes and only one pending 050 SQL hash (`8ea9acc62643a5945266ffb8b83e4a0b35b6ea00720a07b9f42bfe29c955220e`). It builds only the direct `campuspay_owner` connection to `campuspay` on the fixed Neon host with `sslmode=verify-full`. Before applying it checks exact database history 37, roles, grants, prior stock function and drained connections. It then invokes the repository's unchanged `scripts/migrate.mjs --check-runtime`, which holds advisory lock `84632291` and applies pending SQL within a transaction. It writes a durable attempt record before invoking the runner. Its read-only postflight requires history 38, only 050 added, unchanged existing data and audit rows, stock costing function preservation, new empty immutable closure table and correct API/private grants. Any failure leaves maintenance in force for exact-history review; do not blindly retry. It does not deploy, promote, or reopen.

Download the exact ZIP from the GitHub release link supplied with this handoff. In Windows Git Bash, verify its SHA256 against the handoff before extracting. Extract into a new folder. Use Node 22 and a **separate new clean checkout** of `kohnerbouchard-star/campuspay-pos` at the exact merge commit; keep the old v9 checkout and its backup unchanged. Prepare the new checkout:

```bash
source_root="$(mktemp -d "$HOME/campuspay-stock050-source.XXXXXXXX")"
git clone --no-checkout https://github.com/kohnerbouchard-star/campuspay-pos.git "$source_root"
git -C "$source_root" checkout --detach 4e75bf8883df592fee52e9521ab18a0f0c706f5a
(cd "$source_root" && npm ci)
```

With the current full hold and stopped writers still in force, run from the extracted folder:

```bash
bash ./run.sh "$source_root"
```

The launcher prints a new evidence directory, prompts for the owner password through hidden terminal input, and sends it to the local Node process via stdin. Do not put the password, URL, backup key, or evidence contents in chat. Success is exactly `DATABASE_38_VERIFIED_PROMOTION_PENDING`; preserve `apply-started.json`, `preflight.json`, and `database-postflight.json` locally and share only their sanitized status and run ID. Failure may mean the transaction did or did not commit; keep maintenance and inspect live migration history before any further attempt. The old five migrations are never rerun.
