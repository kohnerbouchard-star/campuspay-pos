#!/usr/bin/env node
// Operator-only: one stock migration on the exact reviewed source. No backup or deployment.
import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import { createHash, randomUUID } from 'node:crypto'
import { execFileSync, spawnSync } from 'node:child_process'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { inventory } from './reference-v9/core.mjs'
import { captureBefore050, verifyAfter050 } from './postflight.mjs'

const sha = bytes => createHash('sha256').update(bytes).digest('hex')
const root = path.dirname(fileURLToPath(import.meta.url))
const manifest = JSON.parse(fs.readFileSync(path.join(root, 'manifest.json')))
const stop = code => { throw new Error(code) }
const readRegular = file => {
  const st = fs.lstatSync(file)
  if (!st.isFile() || st.isSymbolicLink() || st.size > 1024 * 1024) stop('SOURCE_FILE_INVALID')
  return fs.readFileSync(file)
}
const git = (source, ...args) => execFileSync('git', ['-C', source, ...args], { encoding: 'utf8' }).trim()
const durableNew = (file, value) => {
  const fd = fs.openSync(file, 'wx', 0o600)
  try { fs.writeFileSync(fd, JSON.stringify(value, null, 2) + '\n'); fs.fsyncSync(fd) }
  finally { fs.closeSync(fd) }
}
const checkSource = source => {
  assert.equal(manifest.schema, 'campuspay-stock050-direct-v1')
  assert.equal(manifest.status, 'DIRECT_SINGLE_050_NO_BACKUP')
  assert.equal(manifest.candidate.head, '4e75bf8883df592fee52e9521ab18a0f0c706f5a')
  assert.equal(manifest.candidate.tree, '68adb211f5a71cf513eb34dde726244288e6cb13')
  assert.equal(git(source, 'rev-parse', 'HEAD'), manifest.candidate.head)
  assert.equal(git(source, 'rev-parse', 'HEAD^{tree}'), manifest.candidate.tree)
  assert.equal(git(source, 'status', '--porcelain'), '')
  const versions = [...manifest.originalHistory.map(x => x.version), manifest.migration050.version]
  assert.equal(manifest.originalHistory.length, 37)
  const dir = path.join(source, 'database', 'migrations')
  assert.deepEqual(fs.readdirSync(dir).filter(x => x.endsWith('.sql')).sort(), versions.map(x => x + '.sql'))
  for (const row of manifest.originalHistory)
    assert.equal(sha(readRegular(path.join(dir, row.version + '.sql'))), row.sha256)
  assert.equal(sha(readRegular(path.join(dir, manifest.migration050.file))), manifest.migration050.sha256)
  assert.equal(sha(readRegular(path.join(source, 'database/schema/050_stock_adjustment_recovery.sql'))), manifest.migration050.schemaMirrorSha256)
  const vercel = JSON.parse(readRegular(path.join(source, 'vercel.json')))
  assert.equal(vercel.git.deploymentEnabled['feat/effective-access-workspaces-20261005'], false)
  assert.equal(vercel.git.deploymentEnabled['release/campuspay-app-integration-20261008'], false)
  return { versions, dir }
}
let marker = false
try {
  const [sourceArg, evidenceArg] = process.argv.slice(2)
  if (!sourceArg || !evidenceArg || process.argv.length !== 4) stop('USAGE')
  const source = fs.realpathSync(sourceArg)
  const evidence = fs.realpathSync(evidenceArg)
  if (!fs.statSync(evidence).isDirectory() || fs.readdirSync(evidence).length) stop('EVIDENCE_DIRECTORY_NOT_EMPTY')
  checkSource(source)
  const secret = fs.readFileSync(0, 'utf8')
  if (!secret.endsWith('\n') || secret.slice(0, -1).includes('\n')) stop('OWNER_PASSWORD_INPUT_INVALID')
  const password = secret.slice(0, -1)
  if (!password || password.length > 1024 || password.includes('\0')) stop('OWNER_PASSWORD_INPUT_INVALID')
  const host = manifest.productionBaseline.target.host
  const url = new URL(`postgresql://${host}:5432/campuspay?sslmode=verify-full`)
  url.username = 'campuspay_owner'
  url.password = encodeURIComponent(password)
  for (const key of Object.keys(process.env)) if (key.startsWith('PG')) delete process.env[key]
  const require = createRequire(path.join(source, 'package.json'))
  const pg = require('pg')
  const connect = async () => {
    const client = new pg.Client({ connectionString: url.href, connectionTimeoutMillis: 15000 })
    await client.connect()
    const identity = (await client.query('select current_user as role,current_database() as database')).rows[0]
    if (identity.role !== 'campuspay_owner' || identity.database !== 'campuspay') stop('DATABASE_IDENTITY_MISMATCH')
    return client
  }
  let client = await connect()
  let before
  try {
    await client.query('select pg_advisory_lock(84632291)')
    const baseline = await inventory(client)
    before = await captureBefore050(client, baseline)
  } finally { await client.end() }
  const run = randomUUID()
  durableNew(path.join(evidence, 'preflight.json'), { status: 'SCHEMA_37_SINGLE_050_READY_NO_BACKUP', candidate: manifest.candidate.head,
    migration: manifest.migration050.version, sqlSha256: manifest.migration050.sha256, historyRows: 37, tableCount: before.tables.length,
    host, database: 'campuspay', owner: 'campuspay_owner', sslmode: 'verify-full', checkedAt: new Date().toISOString() })
  durableNew(path.join(evidence, 'apply-started.json'), { status: 'SINGLE_050_ATTEMPT_STARTED', run, candidate: manifest.candidate.head,
    migration: manifest.migration050.version, sqlSha256: manifest.migration050.sha256, backupPerformed: false,
    startedAt: new Date().toISOString() })
  marker = true
  const env = { ...process.env, DATABASE_URL_UNPOOLED: url.href, EXPECTED_DATABASE_HOST: host }
  for (const key of Object.keys(env)) if (key.startsWith('PG')) delete env[key]
  const result = spawnSync(process.execPath, [path.join(source, 'scripts/migrate.mjs'), '--check-runtime'],
    { cwd: source, env, stdio: ['ignore', 'pipe', 'pipe'], encoding: 'utf8', maxBuffer: 1024 * 1024, timeout: 600000 })
  if (result.error || result.status !== 0 || result.signal) {
    if (result.stderr) process.stderr.write(result.stderr)
    stop('QUALIFIED_RUNNER_FAILED_INSPECT_HISTORY')
  }
  const applied = (result.stdout || '').split(/\r?\n/).filter(x => x.startsWith('Applied '))
  if (applied.length !== 1 || applied[0] !== `Applied ${manifest.migration050.version}`) stop('EXACT_050_APPLY_NOT_CONFIRMED')
  client = await connect()
  let after
  try {
    await client.query('select pg_advisory_lock(84632291)')
    after = await verifyAfter050(client, before)
  }
  finally { await client.end() }
  durableNew(path.join(evidence, 'database-postflight.json'), { ...after, candidate: manifest.candidate.head,
    tree: manifest.candidate.tree, run, backupPerformed: false, verifiedAt: new Date().toISOString() })
  console.log('DATABASE_38_VERIFIED_PROMOTION_PENDING')
} catch (error) {
  const code = /^[A-Z_]+$/.test(error?.message || '') ? error.message : 'SOURCE_OR_DATABASE_CHECK_FAILED'
  console.error(`STOP: ${code}. ${marker ? 'Keep maintenance closed; inspect exact history before any retry.' : 'No migration attempt started.'}`)
  process.exitCode = 1
}
