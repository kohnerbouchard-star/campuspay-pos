// Read-only 37 -> 38 assertions under the qualified runner's advisory lock.
// The caller must keep full maintenance and stopped writers throughout.
import assert from 'node:assert/strict'
import fs from 'node:fs'
import { createHash } from 'node:crypto'
import { fileURLToPath } from 'node:url'
import path from 'node:path'
import { inventory, drained, grants, history, objectSecurity, validateOwnerDefaultPrivileges } from './reference-v9/core.mjs'

const manifest = JSON.parse(fs.readFileSync(path.join(path.dirname(fileURLToPath(import.meta.url)), 'manifest.json')))
const versions = manifest.originalHistory.map(row => row.version)
const finalVersion = manifest.migration050.version
const sha = value => createHash('sha256').update(value).digest('hex')
const assertEqual = (actual, expected, code) => {
  try { assert.deepStrictEqual(actual, expected) }
  catch { throw new Error(code) }
}
const check = (condition, code) => { if (!condition) throw new Error(code) }
const rowsFor = (state, kind) => new Map(state[kind].map(row => [String(row.oid), row]))
const single = async (client, sql) => (await client.query(sql)).rows[0]

export async function captureBefore050(client, backupTables) {
  await client.query('begin isolation level repeatable read read only')
  try {
    await client.query("set local timezone='UTC'")
    await history(client, versions)
    const objects = await single(client, "select to_regprocedure('api.remove_stock(uuid,uuid,uuid,integer,text,text,uuid)')::oid as old_oid,to_regprocedure('private.remove_stock_costed(uuid,uuid,uuid,integer,text,text,uuid)') as private_costed,to_regprocedure('api.recover_stock_adjustment(uuid,uuid)') as recovery,to_regclass('private.stock_adjustment_closures') as closure")
    check(objects.old_oid && !objects.private_costed && !objects.recovery && !objects.closure, 'STOCK050_ALREADY_PRESENT_OR_BASE_MISSING')
    const tables = await inventory(client)
    assertEqual(tables, backupTables, 'SOURCE_CHANGED_SINCE_FRESH_BACKUP')
    const role = await grants(client, true)
    const defaults = await validateOwnerDefaultPrivileges(client)
    await drained(client)
    const historyRows = (await client.query('select to_jsonb(h) as row from private.schema_migrations h order by version')).rows.map(x => x.row)
    const costingBody = (await single(client, "select prosrc from pg_proc where oid='api.remove_stock(uuid,uuid,uuid,integer,text,text,uuid)'::regprocedure")).prosrc
    const security = await objectSecurity(client)
    await client.query('commit')
    const oldFunction = security.functions.find(row => String(row.oid) === String(objects.old_oid))
    check(oldFunction?.owner, 'STOCK_COSTING_OWNER_MISSING')
    return { tables, role, defaults, historyRows, oldOid: String(objects.old_oid), oldOwner: oldFunction.owner,
      costingBodySha256: sha(costingBody), security }
  } catch (error) { await client.query('rollback'); throw error }
}

export async function verifyAfter050(client, before) {
  await client.query('begin isolation level repeatable read read only')
  try {
    await client.query("set local timezone='UTC'")
    await history(client, [...versions, finalVersion])
    const oldRows = (await client.query('select to_jsonb(h) as row from private.schema_migrations h where version=any($1::text[]) order by version', [versions])).rows.map(x => x.row)
    assertEqual(oldRows, before.historyRows, 'HISTORICAL_MIGRATION_ROWS_CHANGED')
    assertEqual(await grants(client, true), before.role, 'RUNTIME_ROLE_OR_MEMBERSHIP_CHANGED')
    assertEqual(await validateOwnerDefaultPrivileges(client), before.defaults, 'OWNER_DEFAULT_PRIVILEGES_CHANGED')
    const tables = await inventory(client)
    const names = tables.map(row => row.schemaname + '.' + row.tablename).sort()
    assertEqual(names, [...before.tables.map(row => row.schemaname + '.' + row.tablename), 'private.stock_adjustment_closures'].sort(), 'TABLE_SET_CHANGED')
    for (const row of before.tables) {
      const current = tables.find(x => x.schemaname === row.schemaname && x.tablename === row.tablename)
      if (row.schemaname === 'private' && row.tablename === 'schema_migrations') {
        check(Number(current?.count) === Number(row.count) + 1, 'HISTORY_COUNT_CHANGED')
        continue
      }
      assertEqual(current, row, 'EXISTING_DATA_CHANGED')
    }
    const closure = tables.find(row => row.schemaname === 'private' && row.tablename === 'stock_adjustment_closures')
    check(closure?.count === '0', 'CLOSURE_NOT_EMPTY_AFTER_DDL')
    const costing = await single(client, "select p.oid::text as oid,p.prosrc,p.prosecdef,p.proowner::regrole::text as owner from pg_proc p where p.oid='private.remove_stock_costed(uuid,uuid,uuid,integer,text,text,uuid)'::regprocedure")
    check(costing?.oid === before.oldOid && sha(costing.prosrc) === before.costingBodySha256, 'COSTING_BODY_OR_IDENTITY_CHANGED')
    const funcs = await single(client, "select to_regprocedure('api.remove_stock(uuid,uuid,uuid,integer,text,text,uuid)')::oid as wrapper,to_regprocedure('api.recover_stock_adjustment(uuid,uuid)')::oid as recovery")
    check(funcs.wrapper && funcs.recovery, 'STOCK_API_MISSING')
    const security = await objectSecurity(client)
    assertEqual(security.schemas, before.security.schemas, 'SCHEMA_SECURITY_CHANGED')
    const priorRelations = rowsFor(before.security, 'relations')
    const afterRelations = rowsFor(security, 'relations')
    check(afterRelations.size === priorRelations.size + 1, 'NEW_RELATION_SET_CHANGED')
    for (const [oid, row] of priorRelations) assertEqual(afterRelations.get(oid), row, 'EXISTING_RELATION_SECURITY_CHANGED')
    const newRelation = [...afterRelations].filter(([oid]) => !priorRelations.has(oid)).map(([, row]) => row)
    check(newRelation.length === 1 && newRelation[0].schema === 'private' && newRelation[0].name === 'stock_adjustment_closures' && newRelation[0].relkind === 'r' && newRelation[0].owner === before.oldOwner, 'CLOSURE_RELATION_SECURITY_CHANGED')
    const priorFunctions = rowsFor(before.security, 'functions')
    const afterFunctions = rowsFor(security, 'functions')
    check(afterFunctions.size === priorFunctions.size + 2, 'NEW_FUNCTION_SET_CHANGED')
    for (const [oid, row] of priorFunctions) {
      const current = afterFunctions.get(oid)
      if (oid === before.oldOid) {
        check(current?.schema === 'private' && current.name === 'remove_stock_costed' && current.owner === row.owner && current.security_definer === row.security_definer && current.leakproof === row.leakproof, 'COSTING_SECURITY_CHANGED')
        assertEqual(current.config, row.config, 'COSTING_CONFIG_CHANGED')
        assertEqual(current.acl, row.acl.filter(grant => !['PUBLIC', 'campuspay_runtime'].includes(grant.grantee)), 'COSTING_ACL_CHANGED')
      } else assertEqual(current, row, 'EXISTING_FUNCTION_SECURITY_CHANGED')
    }
    assertEqual([...afterFunctions.keys()].filter(oid => !priorFunctions.has(oid)).sort(), [String(funcs.wrapper), String(funcs.recovery)].sort(), 'NEW_FUNCTION_IDENTITY_CHANGED')
    const privileges = await single(client, "select not has_function_privilege('campuspay_runtime','private.remove_stock_costed(uuid,uuid,uuid,integer,text,text,uuid)','EXECUTE') and not has_function_privilege('campuspay_runtime_login','private.remove_stock_costed(uuid,uuid,uuid,integer,text,text,uuid)','EXECUTE') as private_denied,has_function_privilege('campuspay_runtime','api.remove_stock(uuid,uuid,uuid,integer,text,text,uuid)','EXECUTE') and has_function_privilege('campuspay_runtime','api.recover_stock_adjustment(uuid,uuid)','EXECUTE') as api_runtime,(select count(*)=0 from pg_proc p cross join lateral aclexplode(coalesce(p.proacl,acldefault('f',p.proowner))) a where p.oid in ('private.remove_stock_costed(uuid,uuid,uuid,integer,text,text,uuid)'::regprocedure,'api.remove_stock(uuid,uuid,uuid,integer,text,text,uuid)'::regprocedure,'api.recover_stock_adjustment(uuid,uuid)'::regprocedure) and a.grantee=0 and a.privilege_type='EXECUTE') as public_denied")
    check(privileges.private_denied && privileges.api_runtime && privileges.public_denied, 'STOCK_FUNCTION_GRANTS_UNSAFE')
    const apiSecurity = (await client.query("select p.oid::text as oid,p.prosecdef,p.proowner::regrole::text as owner,p.proconfig from pg_proc p where p.oid in ('api.remove_stock(uuid,uuid,uuid,integer,text,text,uuid)'::regprocedure,'api.recover_stock_adjustment(uuid,uuid)'::regprocedure) order by p.oid")).rows
    check(apiSecurity.length === 2 && apiSecurity.every(x => x.prosecdef && x.owner === before.oldOwner && x.proconfig?.includes('search_path=""')), 'STOCK_API_SECURITY_UNSAFE')
    const trigger = await single(client, "select tgname,tgenabled,tgtype,tgfoid::regprocedure::text as fn from pg_trigger where tgrelid='private.stock_adjustment_closures'::regclass and not tgisinternal")
    check(trigger?.tgname === 'immutable_stock_adjustment_closures' && trigger.tgenabled === 'O' && trigger.tgtype === 27 && trigger.fn === 'private.reject_journal_mutation()', 'CLOSURE_IMMUTABILITY_MISSING')
    await drained(client)
    await client.query('commit')
    return { status: 'DATABASE_38_VERIFIED_PROMOTION_PENDING', migrationCount: 38, appliedCount: 1,
      historicalRowsUnchanged: true, existingDataUnchanged: true, costingBodySha256: before.costingBodySha256,
      stockApiAndPrivateGrantsVerified: true, closureEmptyAndImmutable: true, runtimeDirectDataGrants: 0,
      promotionPerformed: false }
  } catch (error) { await client.query('rollback'); throw error }
}
